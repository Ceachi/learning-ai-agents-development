# === PROBLEMA: LLM-urile sunt stateless ===
llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash")

llm.invoke("Ma cheama Andrei.")
raspuns = llm.invoke("Cum ma cheama?")
print(raspuns.content)
# "Nu stiu cum te cheama..." - apelurile sunt INDEPENDENTE


history = []

# Primul tur
history.append(HumanMessage("Ma cheama Andrei."))
raspuns = llm.invoke(history)
history.append(raspuns)  # AIMessage adaugat in istoric

# Al doilea tur - trimitem TOATA conversatia
history.append(HumanMessage("Cum ma cheama?"))
raspuns = llm.invoke(history)
print(raspuns.content)
# "Te cheama Andrei." - LLM-ul vede contextul!
