# Request (ce trimiti):
{
  "model": "claude-sonnet-4-5",
  "max_tokens": 1024,
  "temperature": 0.7,
  "system": "Esti un asistent.",
  "messages": [
    {"role": "user", "content": "Salut!"}
  ]
}

# Response (ce primesti):
{
  "id": "msg_abc123",
  "role": "assistant",
  "content": [
    {"type": "text", "text": "Salut! Cu ce te pot ajuta?"}
  ],
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 25,
    "output_tokens": 15
  }
}
