import asyncio, os
from google import genai

client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))

async def stream_response():
    # generate_content_stream - async iterator de chunks
    async for chunk in await client.aio.models.generate_content_stream(
        model="gemini-2.0-flash",
        contents=[{"role": "user", "parts": [{"text": "Scrie un haiku."}]}],
        config={"temperature": 0},
    ):
        if chunk.text:
            print(chunk.text, end="", flush=True)

asyncio.run(stream_response())
