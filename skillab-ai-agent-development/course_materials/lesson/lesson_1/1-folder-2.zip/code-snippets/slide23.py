import anthropic

# Client conectat automat prin ANTHROPIC_API_KEY din env
client = anthropic.Anthropic()
