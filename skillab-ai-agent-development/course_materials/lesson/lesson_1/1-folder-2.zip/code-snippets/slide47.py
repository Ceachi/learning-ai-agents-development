from abc import ABC, abstractmethod
from typing import AsyncIterator

class LLMProvider(ABC):
    """Contract comun pentru orice provider - uniformizeaza diferentele."""

    @abstractmethod
    async def stream(self, messages: list[Message]) -> AsyncIterator[str]:
        """Stream de chunks - yield text, indiferent de provider."""


# Folosire - acelasi cod pentru ORICE provider concret
async for chunk in provider.stream(messages):
    print(chunk, end="", flush=True)
