class QAAgent:
    """Agent conversational cu istoric si provider switching."""

    def __init__(self, provider: str, system_prompt: str):
        self.provider: str = provider
        self.llm = self._create_llm(provider)            # factory
        self.system_prompt: str = system_prompt
        self.history: list[BaseMessage] = []             # lista goala la start

    def _create_llm(self, provider: str):
        """Factory: returneaza LLM-ul potrivit. Adaugi un provider nou
        adaugand un entry in dict - fara if/elif crescator."""
        providers = {
            "anthropic": lambda: ChatAnthropic(model="claude-sonnet-4-5"),
            "gemini":    lambda: ChatGoogleGenerativeAI(model="gemini-2.5-flash"),
            "ollama":    lambda: ChatOllama(model="llama3.2"),
        }
        if provider not in providers:
            raise ValueError(f"Provider necunoscut: {provider}")
        return providers[provider]()  # apelam lambda - instantiere lazy
