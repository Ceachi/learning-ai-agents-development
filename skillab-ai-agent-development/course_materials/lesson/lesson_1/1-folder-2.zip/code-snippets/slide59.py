from langchain_core.messages import SystemMessage, HumanMessage
# Apel simplu: string in, AIMessage out
messages = [
    SystemMessage(content="Esti expert Python."),
    HumanMessage(content="Ce este o lista?"),
]

raspuns = llm.invoke(messages)


messages.append(raspuns)  # AIMessage adaugat automat
messages.append(HumanMessage(content="Da-mi un exemplu"))

raspuns = llm.invoke(messages)  # LLM vede tot contextul!
print(raspuns.content)
