import requests

# Apel raw HTTP catre Ollama local - fara SDK, fara API key
response = requests.post(
    "http://localhost:11434/api/chat",
    json={
        "model": "llama3.2",
        "messages": [
            {"role": "user", "content": "Salut! Cine esti?"}
        ],
        "stream": False,
    },
)

data = response.json()
print(data["message"]["content"])  # textul raspunsului
