"messages": [

  {"role": "system", "content": "Esti un asistent..."},

  {"role": "user", "content": "Ce este o lista?"},

  {"role": "assistant", "content": "O lista este..."},

  {"role": "user", "content": "Da-mi un exemplu"}

]
