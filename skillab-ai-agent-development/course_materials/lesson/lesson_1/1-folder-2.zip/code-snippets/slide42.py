# === FARA ABSTRACTIE: cod duplicat pt. fiecare provider ===

# Ollama
import requests
r = requests.post("http://localhost:11434/api/chat", json={...})
text = r.json()["message"]["content"]

# Gemini
url = f"...{MODEL}:generateContent?key={KEY}"
r = requests.post(url, json={"contents": [...]})
text = r.json()["candidates"][0]["content"]["parts"][0]["text"]

# Anthropic
r = requests.post("https://api.anthropic.com/v1/messages",
    headers={"x-api-key": KEY, "anthropic-version": "2023-06-01"},
    json={"model": "...", "max_tokens": 1024, "messages": [...]})
text = r.json()["content"][0]["text"]


# === CU LANGCHAIN: acelasi cod, o linie se schimba ===
from langchain_ollama import ChatOllama
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_anthropic import ChatAnthropic

# Doar linia asta difera intre provideri
llm = ChatOllama(model="llama3.2")
# llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash")
# llm = ChatAnthropic(model="claude-sonnet-4-5")

# Restul codului e IDENTIC pentru orice provider
text = llm.invoke("Salut!").content
