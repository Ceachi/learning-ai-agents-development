from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import (
    BaseMessage, SystemMessage, HumanMessage,
)

class QAAgent:
    """Agent conversational cu istoric - un wrapper peste un ChatModel."""

    def __init__(self, llm: BaseChatModel, system_prompt: str):
        self.llm: BaseChatModel = llm
        self.system_prompt: str = system_prompt
        self.history: list[BaseMessage] = []

    def chat(self, message: str) -> str:
        """Trimite mesaj, primeste raspuns complet, actualizeaza istoricul."""
        ...

    def stream(self, message: str):
        """Yield chunks pe masura ce vin de la LLM."""
        ...

    def get_history(self) -> list[dict]:
        """Returneaza istoricul serializabil."""
        ...

    def clear_history(self) -> None:
        """Reset complet al conversatiei."""
        self.history = []
