chat(self, message):
    # 1. Construieste lista completa de mesaje
    messages = [system_prompt] + history + [user_message]

    # 2. Apel sincron - primesti raspunsul intreg
    response = llm.invoke(messages)

    # 3. Salveaza tura in history (user + assistant)
    history.append(user_message)
    history.append(response)

    # 4. Returneaza textul (string, nu obiectul)
    return response.content

stream(self, message):
    # 1. Construieste lista la fel ca la chat()
    messages = [system_prompt] + history + [user_message]

    # 2. Apel streaming - primesti chunks pe rand
    full_response = ""
    for chunk in llm.stream(messages):
        full_response += chunk.content
        yield chunk.content   # afisare imediata

    # 3. Salveaza in history DUPA ce streamul s-a terminat
    history.append(user_message)
    history.append(full_response)
