import os, requests

response = requests.post(
    "https://api.anthropic.com/v1/messages",
    headers={
        "x-api-key": os.getenv("ANTHROPIC_API_KEY"),
        "anthropic-version": "2023-06-01",  # header obligatoriu
        "content-type": "application/json",
    },
    json={
        "model": "claude-sonnet-4-5",
        "max_tokens": 1024,                 # obligatoriu la Anthropic
        "system": "Esti un asistent.",      # camp separat (nu in messages)
        "messages": [
            {"role": "user", "content": "Salut!"}
        ],
    },
)

data = response.json()
print(data["content"][0]["text"])
print(data["usage"])  # input_tokens / output_tokens
