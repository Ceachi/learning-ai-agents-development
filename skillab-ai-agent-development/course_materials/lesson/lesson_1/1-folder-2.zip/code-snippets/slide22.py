from google import genai
# Client conectat automat prin GOOGLE_API_KEY din env
client = genai.Client(api_key=os.getenv("GOOGLE_API_KEY"))
