# GRESIT - hardcoded in cod
api_key = "sk-ant-abc123..."

# CORECT - environment variable
import os

api_key = os.environ.get("ANTHROPIC_API_KEY")

# CORECT - fisier .env
from dotenv import load_dotenv

load_dotenv()

api_key = os.environ.get("ANTHROPIC_API_KEY")
