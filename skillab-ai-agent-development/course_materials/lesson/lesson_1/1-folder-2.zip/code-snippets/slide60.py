# Comentezi/decomentezi o singura linie:
llm = ChatOllama(model="llama3.2")
# llm = ChatAnthropic(model="claude-sonnet-4-5")
# llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash")

# Restul codului: IDENTIC pentru orice provider
print(llm.invoke("Salut!").content)


def get_llm(provider: str):
    """Factory: returneaza un LLM in functie de provider."""
    if provider == "anthropic":
        return ChatAnthropic(model="claude-sonnet-4-5")
    elif provider == "gemini":
        return ChatGoogleGenerativeAI(model="gemini-2.5-flash")
    elif provider == "ollama":
        return ChatOllama(model="llama3.2")
    raise ValueError(f"Provider necunoscut: {provider}")

# Schimbi providerul printr-un singur string
llm = get_llm("anthropic")
print(llm.invoke("Salut!").content)
