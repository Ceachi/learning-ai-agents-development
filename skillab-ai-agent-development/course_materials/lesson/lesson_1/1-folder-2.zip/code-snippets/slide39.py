import os, requests

API_KEY = os.getenv("GOOGLE_API_KEY")
MODEL = "gemini-2.5-flash"

# API key in URL params (specific Gemini)
url = (
    f"https://generativelanguage.googleapis.com"
    f"/v1beta/models/{MODEL}:generateContent?key={API_KEY}"
)

response = requests.post(url, json={
    # systemInstruction separat de mesaje
    "systemInstruction": {"parts": [{"text": "Esti un asistent."}]},
    # contents -> parts (nu "messages -> content" ca la OpenAI)
    "contents": [
        {"role": "user", "parts": [{"text": "Salut!"}]},
        # NB: rolul e "model", nu "assistant"
    ],
})

data = response.json()
print(data["candidates"][0]["content"]["parts"][0]["text"])
