import os
from langchain_google_genai import ChatGoogleGenerativeAI

# Parametrii comuni la construire
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key="key",  # cheia din .env
    temperature=0.7,
    max_output_tokens=1024,
)

# Apel simplu: string in, AIMessage out
raspuns = llm.invoke("Explica ce e un LLM in 2 fraze.")

print(type(raspuns).__name__)      # AIMessage
print(raspuns.content)              # textul raspunsului (string)
print(raspuns.response_metadata)    # usage, model, finish_reas


# Parametrii comuni la construire
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.7,
    max_output_tokens=1024,
)
