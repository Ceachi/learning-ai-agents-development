"""
Slide 7 — OutputGuard: implementare completă

Toate verificările de output într-o singură clasă reutilizabilă:

    1. PII redaction      → DetectPII (on_fail="fix")
    2. Schema validation  → model Pydantic opțional
    3. Hallucination check → detect_hallucinations față de sursă

Sync, consistent cu lecția. Se adaugă ca ULTIMUL pas înainte de a returna
răspunsul user-ului.

Setup:
    pip install guardrails-ai pydantic
    guardrails hub install hub://guardrails/detect_pii

Rulare:
    python sectiunea4_slide7.py
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from guardrails import Guard
from guardrails.hub import DetectPII
from pydantic import BaseModel, ValidationError

from sectiunea4_slide6b import detect_hallucinations


@dataclass
class OutputGuardResult:
    passed: bool
    sanitized_output: Any
    pii_found: list = field(default_factory=list)
    schema_errors: list = field(default_factory=list)
    hallucinations: list = field(default_factory=list)


class OutputGuard:
    def __init__(self, schema: type[BaseModel] | None = None):
        self.pii_guard = Guard().use(DetectPII(on_fail="fix"))
        self.schema = schema

    def validate(self, output: str, source_doc: str | None = None) -> OutputGuardResult:
        schema_errors: list = []
        hallucinations: list = []

        # 1. PII redaction
        sanitized: Any = self.pii_guard.validate(output).validated_output

        # 2. Schema validation
        if self.schema:
            try:
                sanitized = self.schema.model_validate_json(sanitized).model_dump()
            except ValidationError as e:
                schema_errors = e.errors()

        # 3. Hallucination check — verifică datele față de sursă.
        #    Dacă nu avem schema, sanitized e încă string JSON: îl parsăm aici.                                                                 
        if source_doc:
            data = sanitized
            if isinstance(data, str):
                try:
                    data = json.loads(data)
                except json.JSONDecodeError:
                    data = None
            if isinstance(data, dict):
                result = detect_hallucinations(data, source_doc)
                hallucinations = result["suspicious"]

        passed = not schema_errors and not hallucinations
        return OutputGuardResult(
            passed=passed,
            sanitized_output=sanitized,
            schema_errors=schema_errors,
            hallucinations=hallucinations,
        )


if __name__ == "__main__":
    guard = OutputGuard()
    source = "Furnizor ABC SRL, total 1500 RON. Contact: ion@email.com"
    out = json.dumps({"furnizor": "ABC SRL", "suma": "1500"})
    result = guard.validate(out, source_doc=source)
    print(f"passed: {result.passed}")
    print(f"output: {result.sanitized_output}")
    print(f"hallucinations: {result.hallucinations}")
