"""
Slide 6 (Opțiunea 2) — Hallucination Detection: custom

Pentru Document Analyst, verificare custom câmp-cu-câmp. Cheia e FUZZY
MATCH pe numere: "1500" vs "1.500" vs "1500.00" sunt aceeași valoare, dar
string match simplu le-ar marca greșit ca hallucination.

Rulare:
    python sectiunea4_slide6b.py
"""

import re


def normalize_number(value: str) -> str | None:
    """Normalizează un număr (scoate separatori). None dacă nu e numeric."""
    digits = re.sub(r"[^\d]", "", value)        # păstrează doar cifrele
    if not digits:                               # "EUR" -> nu e număr
        return None
    return digits.lstrip("0") or "0"


def detect_hallucinations(extraction: dict, doc: str) -> dict:
    results = {"valid": [], "suspicious": []}
    doc_lower = doc.lower()
    # Numerele din document, normalizate (ignorăm token-urile ne-numerice).
    doc_numbers = {n for n in (normalize_number(t) for t in re.findall(r"[\d.,]+", doc)) if n}

    for field, value in extraction.items():
        v = str(value).lower()
        v_num = normalize_number(v)
        if v in doc_lower:                        # match exact pe text
            results["valid"].append(field)
        elif v_num is not None and v_num in doc_numbers:  # fuzzy match DOAR numeric
            results["valid"].append(field)
        else:
            results["suspicious"].append({"field": field, "value": value})
    return results


if __name__ == "__main__":
    doc = "Furnizor: ABC SRL. Total: 1.500 RON. Data: 2024-03-17."

    extraction = {"furnizor": "ABC SRL", "suma": "1500", "moneda": "EUR"}
    result = detect_hallucinations(extraction, doc)
    print("valid:     ", result["valid"])         # furnizor + suma (1500 ~ 1.500)
    print("suspicious:", result["suspicious"])    # moneda EUR (în doc e RON)
