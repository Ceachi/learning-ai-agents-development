"""
Slide 2 — File Validation & Bomb Protection

Înainte să citim conținutul, validăm FIȘIERUL: mărime, tip real (magic
bytes, nu doar extensia), și limite la extracție (anti-bomb). Un .exe
redenumit .pdf trece de un check pe extensie, dar nu de magic bytes.

Dependențe:
    pip install python-magic pymupdf
    # Linux: sudo apt install libmagic1

Rulare:
    python sectiunea3_slide2.py cale/catre/fisier.pdf
"""

import os

import magic
import fitz  # pymupdf

MAX_FILE_SIZE = 10 * 1024 * 1024   # 10 MB
MAX_PAGES = 500
MAX_TEXT_LENGTH = 1_000_000        # 1M caractere

ALLOWED_TYPES = {
    "application/pdf": [".pdf"],
    "text/plain": [".txt", ".csv"],
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
}


def validate_file(filepath: str) -> tuple[bool, str]:
    # 1. Size check — prima barieră, cea mai ieftină.
    if os.path.getsize(filepath) > MAX_FILE_SIZE:
        return False, f"Fișier prea mare (>{MAX_FILE_SIZE // 1024 // 1024}MB)"                           

    # 2. Magic bytes — tipul REAL al fișierului, nu ce zice extensia.
    mime = magic.from_file(filepath, mime=True)
    if mime not in ALLOWED_TYPES:
        return False, f"Tip neacceptat: {mime}"

    # 3. Extension match — extensia trebuie să corespundă tipului real.
    ext = os.path.splitext(filepath)[1].lower()
    if ext not in ALLOWED_TYPES[mime]:
        return False, f"Extensie {ext} nu se potrivește cu {mime}"

    return True, "OK"


def safe_extract_pdf(filepath: str) -> str:
    """Extrage text cu limite — oprește bombele de decompresie."""
    doc = fitz.open(filepath)
    if doc.page_count > MAX_PAGES:
        raise ValueError(f"Prea multe pagini: {doc.page_count} > {MAX_PAGES}")

    text = ""
    for page in doc:
        text += page.get_text()
        if len(text) > MAX_TEXT_LENGTH:    # un PDF mic poate exploda în text
            raise ValueError(f"Text prea lung (>{MAX_TEXT_LENGTH} chars) — posibil bombă")
    return text


if __name__ == "__main__":
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "tests/valid_invoice.pdf"
    ok, msg = validate_file(path)
    print(f"validate_file: {'✅' if ok else '❌'} {msg}")
    if ok and path.endswith(".pdf"):
        print(f"extras {len(safe_extract_pdf(path))} caractere")
