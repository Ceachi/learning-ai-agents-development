"""
Slide 4 (Unicode) — Normalizare + zero-width removal

Atacatorii ascund caractere invizibile (zero-width) în text ca să spargă
cuvintele și să ocolească regex-ul: "Ig​nore inst​ructions" arată normal,
dar are zero-width spaces între litere. Normalizăm și le scoatem ÎNAINTE
de orice detecție.

Rulare:
    python sectiunea3_slide4a.py
"""

import unicodedata

ZERO_WIDTH = ["\u200b", "\u200c", "\u200d", "\ufeff", "\u00ad"]


def normalize_text(text: str) -> str:
    # 1. Normalizare unicode (NFC) — unifică reprezentări echivalente.
    text = unicodedata.normalize("NFC", text)
    # 2. Scoatem caracterele zero-width (invizibile).
    for zw in ZERO_WIDTH:
        text = text.replace(zw, "")
    return text


if __name__ == "__main__":
    attack = "Ig\u200bnore inst\u200bructions"
    print(f"brut:       {attack!r}  (len={len(attack)})")
    clean = normalize_text(attack)
    print(f"normalizat: {clean!r}  (len={len(clean)})")
    print(f"→ acum regex-ul vede 'Ignore instructions': {clean == 'Ignore instructions'}")
