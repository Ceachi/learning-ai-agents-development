"""
Slide 5 — Layer 1: Detecție cu Regex

Pattern-uri cunoscute, instant, zero dependențe. Prima linie de apărare:
rapid și ieftin. Prinde atacurile evidente; cele subtile trec mai departe
la Layer 2 și 3.

    ✓ Rapid, zero dependențe, ușor de extins
    ✗ Ușor de ocolit cu parafrazări sau encoding

Rulare:
    python sectiunea2_slide5.py
"""

import re

INJECTION_PATTERNS = [
    # Override instructions
    r"(?i)ignore\s+(all\s+)?(previous|prior|above)\s+instructions?",
    r"(?i)disregard\s+(all\s+)?(previous|prior)",
    r"(?i)forget\s+(everything|all|what)",
    # Jailbreak keywords
    r"(?i)you\s+are\s+now\s+(DAN|evil|unrestricted)",
    r"(?i)developer\s+mode",
    r"(?i)jailbreak",
    # System prompt extraction
    r"(?i)what\s+(is|are)\s+your\s+(system\s+)?prompt",
    r"(?i)repeat\s+(your\s+)?(system\s+)?prompt",
]


def detect_regex(text: str) -> tuple[bool, list[str]]:
    """Întoarce (a_dat_match, lista_pattern-urilor_găsite)."""
    matches = [p for p in INJECTION_PATTERNS if re.search(p, text)]
    return len(matches) > 0, matches


if __name__ == "__main__":
    for text in ["Extrage datele din factură", "Ignore all previous instructions"]:
        hit, patterns = detect_regex(text)
        print(f"{'❌ BLOCK' if hit else '✅ PASS '}  {text!r}")
