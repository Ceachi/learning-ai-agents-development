"""
Slide 5 (Schema) — Response Validation: schema

Output-ul LLM trebuie să respecte o structură. Definim un model Pydantic
cu validatori pe câmpuri; Guard.from_pydantic forțează LLM-ul să producă
JSON conform (și reîncearcă dacă nu).

Dependențe:
    pip install pydantic guardrails-ai

Rulare:
    python sectiunea4_slide5a.py
"""

from pydantic import BaseModel, field_validator


class InvoiceExtraction(BaseModel):
    furnizor: str
    suma: float
    moneda: str
    data_factura: str

    @field_validator("suma")
    @classmethod
    def suma_pozitiva(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("suma trebuie să fie pozitivă")
        return v

    @field_validator("moneda")
    @classmethod
    def moneda_valida(cls, v: str) -> str:
        if v not in ["RON", "EUR", "USD"]:
            raise ValueError(f"monedă invalidă: {v}")
        return v


# Guard care obligă output-ul LLM-ului să respecte schema:
#   from guardrails import Guard
#   guard = Guard.from_pydantic(InvoiceExtraction)


if __name__ == "__main__":
    # Validăm un output (corect și unul greșit).
    ok = InvoiceExtraction(furnizor="ABC SRL", suma=1500, moneda="RON", data_factura="2024-03-17")
    print("✅", ok)

    try:
        InvoiceExtraction(furnizor="X", suma=-5, moneda="GBP", data_factura="2024-01-01")
    except Exception as e:
        print("❌", e.errors()[0]["msg"])
