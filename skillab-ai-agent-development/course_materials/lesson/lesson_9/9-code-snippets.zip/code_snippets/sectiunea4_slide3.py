"""
Slide 3 — PII Detection cu Guardrails AI

DetectPII din Guardrails Hub detectează automat entități sensibile,
inclusiv cele specifice României (CNP, CUI). Backend-ul e Microsoft
Presidio — același folosit de Azure și AWS.

on_fail="fix" → redactează automat PII-ul găsit.

Setup:
    pip install guardrails-ai
    guardrails hub install hub://guardrails/detect_pii

Rulare:
    python sectiunea4_slide3.py
"""

from guardrails import Guard
from guardrails.hub import DetectPII

from llm import chat

guard = Guard().use(
    DetectPII(
        pii_entities=[
            "EMAIL_ADDRESS",
            "PHONE_NUMBER",
            "PERSON",
            "CREDIT_CARD",
            "IBAN_CODE",
            # Pentru România:
            "RO_CNP",   # Cod Numeric Personal
            "RO_CUI",   # Cod Unic de Înregistrare
        ],
        on_fail="fix",   # redactează automat
    )
)


def extract_safe(document_text: str) -> str:
    """Extrage datele, apoi redactează PII-ul din răspuns."""
    outcome = guard(
        llm_api=lambda *, prompt, **_: chat(prompt),
        prompt=f"Extrage datele din:\n{document_text}",
    )
    return outcome.validated_output


if __name__ == "__main__":
    doc = "Beneficiar: Ion Popescu, email ion.popescu@email.com, tel 0722-123-456."
    print(extract_safe(doc))
