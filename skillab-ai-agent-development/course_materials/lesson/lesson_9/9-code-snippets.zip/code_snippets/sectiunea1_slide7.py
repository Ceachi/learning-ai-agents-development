"""
Slide 7 — Tool-ul nostru: Guardrails AI

Framework declarativ pentru validare input/output LLM.
Configurezi validatoarele o dată, apoi treci fiecare apel prin `guard`.

Setup (o singură dată):
    pip install guardrails-ai
    guardrails hub install hub://guardrails/detect_pii
    guardrails hub install hub://guardrails/toxic_language

Rulează:
    python sectiunea1_slide7.py
"""

from guardrails import Guard
from guardrails.hub import DetectPII, ToxicLanguage

from llm import chat

# Configurăm validatoarele — declarativ, nu programatic.
guard = Guard().use_many(
    DetectPII(pii_entities=["EMAIL_ADDRESS", "PHONE_NUMBER"], on_fail="fix"),
    ToxicLanguage(threshold=0.8, on_fail="exception"),
)


def ask(prompt: str) -> str:
    """Apelăm LLM-ul prin guard: output-ul e validat înainte să-l vedem."""
    outcome = guard(
        llm_api=lambda *, prompt, **_: chat(prompt),
        prompt=prompt,
    )
    return outcome.validated_output


if __name__ == "__main__":
    print(ask("Analizează această factură și rezumă datele de contact."))
