"""
Slide 5 — ContentFilter: pipeline complet

Toate verificările într-o singură clasă orchestrată, cu logică FAIL-FAST:
fiecare pas poate bloca pipeline-ul, economisind timp și cost LLM.

    1. File validation   → mărime, magic bytes, extensie
    2. Safe extraction   → limite pagini/text (anti-bomb)
    3. Normalize + injection → unicode clean + InputValidator
    4. Toxic check       → ToxicLanguage / NSFW
    5. Sanitize metadata → redactare câmpuri suspecte → PASSED

Sync, consistent cu lecția. Reutilizează componentele din slide-urile 2-4
și InputValidator din Secțiunea 2.

Rulare:
    python sectiunea3_slide5.py cale/catre/fisier.pdf
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from sectiunea3_slide2 import validate_file, safe_extract_pdf
from sectiunea3_slide4a import normalize_text
from sectiunea3_slide4b import sanitize_metadata
from sectiunea3_slide3 import check_content_safety
from sectiunea2_slide8 import InputValidator


class FilterResult(Enum):
    PASSED = "passed"
    BLOCKED_FILE = "blocked_file"
    BLOCKED_CONTENT = "blocked_content"


@dataclass
class Output:
    status: FilterResult
    text: str = ""
    metadata: dict | None = None
    reason: str = ""


class ContentFilter:
    def __init__(self, use_llm: bool = False):
        self.input_validator = InputValidator(use_llm=use_llm)

    def filter(self, filepath: str) -> Output:
        # 1. File validation
        ok, msg = validate_file(filepath)
        if not ok:
            return Output(FilterResult.BLOCKED_FILE, reason=msg)

        # 2. Safe extraction
        try:
            text = safe_extract_pdf(filepath)
        except ValueError as e:
            return Output(FilterResult.BLOCKED_FILE, reason=str(e))

        # 3. Normalize & check injection
        text = normalize_text(text)
        inj = self.input_validator.validate(text)
        if not inj.passed:
            return Output(FilterResult.BLOCKED_CONTENT, reason=f"injection: {inj.method}")

        # 4. Toxic check
        safe, reason = check_content_safety(text)
        if not safe:
            return Output(FilterResult.BLOCKED_CONTENT, reason=reason)

        # 5. Sanitize metadata & return PASSED
        return Output(FilterResult.PASSED, text=text, metadata=sanitize_metadata(filepath))


if __name__ == "__main__":
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "tests/valid_invoice.pdf"
    result = ContentFilter().filter(path)
    print(f"status: {result.status.value}")
    print(f"reason: {result.reason or '—'}")
