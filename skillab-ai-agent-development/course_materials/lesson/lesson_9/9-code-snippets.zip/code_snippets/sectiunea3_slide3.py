"""
Slide 3 — Toxic Content Detection

Validatori ML pre-built din Guardrails Hub: ToxicLanguage + NSFWText.
Filtrăm INPUT-ul (nu doar output-ul) din 3 motive: context poisoning,
compliance (GDPR/DSA), și audit trail curat.

Setup:
    pip install guardrails-ai
    guardrails hub install hub://guardrails/toxic_language
    guardrails hub install hub://guardrails/nsfw_text

Tip: threshold-ul e tunable — pornește cu 0.8 și ajustează pe false positives.

Rulare:
    python sectiunea3_slide3.py
"""

from guardrails import Guard
from guardrails.hub import ToxicLanguage, NSFWText

guard = Guard().use_many(
    ToxicLanguage(threshold=0.8, on_fail="exception"),
    NSFWText(threshold=0.8, on_fail="exception"),
)


def check_content_safety(text: str) -> tuple[bool, str | None]:
    """Întoarce (e_sigur, motiv_dacă_nu)."""
    try:
        guard.validate(text)
        return True, None
    except Exception as e:
        return False, str(e)


if __name__ == "__main__":
    safe, reason = check_content_safety("Factură pentru servicii de consultanță.")
    print(f"{'✅ SAFE' if safe else '❌ BLOCKED'} — {reason or 'OK'}")
