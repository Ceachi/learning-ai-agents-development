"""
Slide 5 (Facts) — Response Validation: facts

Schema validează FORMA output-ului. Facts validează CONȚINUTUL: fiecare
valoare extrasă trebuie să existe efectiv în documentul sursă. Dacă o
valoare nu apare → posibil hallucination.

Folosește-le împreună: schema + facts.

Rulare:
    python sectiunea4_slide5b.py
"""


def validate_facts(extraction: dict, source_text: str) -> list[str]:
    """Întoarce lista de valori care NU apar în sursă (suspecte)."""
    errors = []
    for key, value in extraction.items():
        if str(value) not in source_text:
            errors.append(f"'{value}' not in source")
    return errors


if __name__ == "__main__":
    source = "Furnizor: ABC SRL. Sumă: 1500 RON. Data: 2024-03-17."

    extraction = {"furnizor": "ABC SRL", "suma": "1500", "moneda": "RON"}
    print("corect:", validate_facts(extraction, source) or "✅ totul în sursă")

    halucinat = {"furnizor": "ABC SRL", "suma": "9999"}   # 9999 nu există în sursă
    print("suspect:", validate_facts(halucinat, source))
