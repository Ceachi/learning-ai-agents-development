"""
Slide 4 (Metadata) — Sanitizare metadata

Atacatorii pun payload în câmpurile de metadata (Author, Title, Subject),
pentru că deseori ne uităm doar la textul vizibil. Verificăm fiecare câmp
cu detectorul de injection și redactăm ce e suspect.

Folosim detect_regex din Secțiunea 2 (Layer 1) ca detector de injection.

Dependențe:
    pip install PyPDF2

Rulare:
    python sectiunea3_slide4b.py cale/catre/fisier.pdf
"""

from PyPDF2 import PdfReader

from sectiunea2_slide8 import INJECTION_PATTERNS
import re


def detect_injection_regex(text: str) -> tuple[bool, list[str]]:
    matches = [p for p in INJECTION_PATTERNS if re.search(p, text)]
    return len(matches) > 0, matches


def sanitize_metadata(filepath: str) -> dict:
    meta = PdfReader(filepath).metadata or {}
    sanitized = {}
    for key, value in meta.items():
        clean_key = key.replace("/", "")          # PyPDF2 prefixează cu "/"
        if isinstance(value, str):
            if detect_injection_regex(value)[0]:   # câmp suspect → redactăm
                sanitized[clean_key] = "[REDACTED]"
            else:
                sanitized[clean_key] = value[:200]  # +trunchiem ca limită
    return sanitized


if __name__ == "__main__":
    import sys

    path = sys.argv[1] if len(sys.argv) > 1 else "tests/valid_invoice.pdf"
    print(sanitize_metadata(path))
