"""
Slide 6 (Opțiunea 1) — Hallucination Detection: ProvenanceCheck

Validator gata făcut din Guardrails Hub. Verifică automat dacă output-ul
e susținut de sursele date, peste un prag de similaritate.

Setup:
    pip install guardrails-ai
    guardrails hub install hub://guardrails/provenance_llm

Rulare:
    python sectiunea4_slide6a.py
"""

from guardrails import Guard
from guardrails.hub import ProvenanceCheck

guard = Guard().use(
    ProvenanceCheck(
        sources=["source_document.txt"],
        threshold=0.7,
        on_fail="exception",
    )
)


def check_provenance(llm_output: str) -> bool:
    """True dacă output-ul e susținut de surse; altfel aruncă excepție."""
    guard.validate(llm_output)
    return True


if __name__ == "__main__":
    try:
        check_provenance("Suma facturii este 1500 RON.")
        print("✅ susținut de surse")
    except Exception as e:
        print(f"❌ posibil hallucination: {e}")
