"""
Slide 7 — Testing Content Filters

Suite de test cu fișiere mock: un happy-path + câte un caz pentru fiecare
path de blocare (sweet spot). Fiecare caz e (fișier, ar_trebui_să_treacă,
descriere). Verificăm că verdictul filtrului se potrivește cu așteptarea.

Rulare (necesită fișierele mock în tests/):
    python sectiunea3_slide7.py
"""

from sectiunea3_slide5 import ContentFilter, FilterResult

TEST_CASES = [
    # (fișier, should_pass, descriere)
    ("valid_invoice.pdf", True, "Normal PDF"),
    ("huge_file.pdf", False, "Exceeds 10MB"),
    ("fake.pdf", False, "EXE mascat ca PDF"),
    ("bomb.pdf", False, "Decompression bomb"),
    ("hidden_inj.pdf", False, "Hidden injection"),
    ("toxic.docx", False, "Hate speech"),
]


def test_filter() -> None:
    cf = ContentFilter()
    passed = 0
    for path, expected, desc in TEST_CASES:
        result = cf.filter(f"tests/{path}")
        is_pass = result.status == FilterResult.PASSED
        ok = is_pass == expected
        passed += ok
        print(f"{'✅' if ok else '❌'} {desc:20} [{result.status.value}]")
    print(f"\n{passed}/{len(TEST_CASES)} teste corecte")


if __name__ == "__main__":
    test_filter()
