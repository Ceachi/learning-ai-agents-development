"""
demo_sectiunea4.py — Output Guardrails în acțiune

Arată ce descriu slide-urile 4, 5, 6: ce iese din LLM poate conține PII
sau date inventate. Demo-ul trece un output „de la LLM" prin:

    1. PII redaction — cele 4 strategii (redact / mask / hash / tokenize)
    2. Facts check    — valorile extrase există în sursă?
    3. Hallucination  — fuzzy match numeric ("1500" == "1.500")

Părțile fără dependențe externe (redactare custom, facts, hallucination)
rulează direct. PII via Guardrails și schema Pydantic cer setup-ul din README.

Rulare:
    python demo_sectiunea4.py
"""

from __future__ import annotations

from sectiunea4_slide4 import Entity, RedactionStrategy, redact_pii
from sectiunea4_slide5b import validate_facts
from sectiunea4_slide6b import detect_hallucinations

# Document sursă (ce a procesat agentul).
SOURCE = (
    "Factură #2024-0317. Furnizor: ABC SRL, CUI 12345678. "
    "Beneficiar: Ion Popescu, email ion.popescu@email.com, tel 0722-123-456. "
    "Total: 1.500 RON."
)

# Răspuns „de la LLM" — conține PII și o valoare inventată (9999).
LLM_RESPONSE = (
    "Furnizor ABC SRL. Contact: ion.popescu@email.com, 0722-123-456. Total: 9999 RON."
)


def demo_redaction() -> None:
    print("=" * 70)
    print("1. PII REDACTION — aceeași dată, 4 strategii")
    print("=" * 70)
    entities = [Entity("ion.popescu@email.com", "EMAIL"), Entity("0722-123-456", "PHONE")]
    for strat in RedactionStrategy:
        print(f"\n{strat.value:9} → {redact_pii(LLM_RESPONSE, entities, strat)}")


def demo_facts() -> None:
    print(f"\n{'=' * 70}")
    print("2. FACTS CHECK — valorile extrase există în sursă?")
    print("=" * 70)
    extraction = {"furnizor": "ABC SRL", "suma": "9999", "cui": "12345678"}
    errors = validate_facts(extraction, SOURCE)
    print(f"\nextras: {extraction}")
    print(f"erori:  {errors or '✅ tot în sursă'}")


def demo_hallucination() -> None:
    print(f"\n{'=' * 70}")
    print("3. HALLUCINATION — fuzzy match numeric ('1500' == '1.500')")
    print("=" * 70)
    # suma corectă scrisă fără separator; moneda corectă; total inventat
    extraction = {"furnizor": "ABC SRL", "suma": "1500", "total": "9999"}
    result = detect_hallucinations(extraction, SOURCE)
    print(f"\nvalid:      {result['valid']}        ← 1500 prins ca 1.500")
    print(f"suspicious: {result['suspicious']}  ← 9999 nu există în document")


if __name__ == "__main__":
    demo_redaction()
    demo_facts()
    demo_hallucination()

    print(f"\n{'=' * 70}")
    print("Concluzie: validăm și ce IESE — PII redactat, fapte verificate,")
    print("halucinații semnalate. Ultimul strat înainte de user.")
