"""
Slide 4 — PII Redaction: strategii

Detectarea e doar primul pas — CE faci cu PII-ul depinde de use case:

    REDACT   → [REDACTED]        default, cel mai sigur
    MASK     → ion.***@***.com   pentru debugging (păstrează forma)
    HASH     → a1b2c3d4          pentru analytics/linking (determinist)
    TOKENIZE → PII_a1b2c3d4       reversibil cu o cheie/mapare

Tip pragmatic: începe cu Redact, treci la Hash/Tokenize când ai nevoie.

Rulare:
    python sectiunea4_slide4.py
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from enum import Enum
from uuid import uuid4


class RedactionStrategy(Enum):
    REDACT = "redact"        # [REDACTED]
    MASK = "mask"            # ***
    HASH = "hash"            # sha256[:8]
    TOKENIZE = "tokenize"    # reversibil


@dataclass
class Entity:
    """O entitate PII detectată (ce ar întoarce Presidio)."""
    value: str
    type: str = "PII"


def redact_pii(text: str, entities: list[Entity], strategy: RedactionStrategy) -> str:
    for ent in entities:
        if strategy == RedactionStrategy.REDACT:
            repl = "[REDACTED]"
        elif strategy == RedactionStrategy.MASK:
            repl = "*" * len(ent.value)
        elif strategy == RedactionStrategy.HASH:
            repl = hashlib.sha256(ent.value.encode()).hexdigest()[:8]
        elif strategy == RedactionStrategy.TOKENIZE:
            repl = f"PII_{uuid4().hex[:8]}"
        else:
            repl = "[REDACTED]"
        text = text.replace(ent.value, repl)
    return text


if __name__ == "__main__":
    text = "Contact: ion.popescu@email.com, tel 0722-123-456"
    found = [Entity("ion.popescu@email.com", "EMAIL"), Entity("0722-123-456", "PHONE")]

    for strat in RedactionStrategy:
        print(f"{strat.value:9} → {redact_pii(text, found, strat)}")
