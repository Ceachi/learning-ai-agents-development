"""
Slide 6 — Integrare în Document Analyst

Pe slide, ContentFilter intră ca node în graful LangGraph cu conditional
routing. Aici păstrăm exact aceeași IDEE — node + routing condiționat —
dar fără dependența LangGraph: un node e o funcție care primește state și
întoarce state actualizat; routing-ul e o funcție care alege următorul pas.

    filter_documents → (all_passed?) → extractor   ✓ pass
                                     → error_handler ✗ blocked

Rulare:
    python sectiunea3_slide6.py
"""

from __future__ import annotations

from sectiunea3_slide5 import ContentFilter, FilterResult

# "State"-ul = un dict simplu care curge prin graf.
AnalystState = dict


def filter_documents_node(state: AnalystState) -> AnalystState:
    """Node: filtrează toate documentele, separă pass-urile de erori."""
    cf = ContentFilter()
    processed, errors = [], []

    for path in state["document_paths"]:
        result = cf.filter(path)
        if result.status == FilterResult.PASSED:
            processed.append({"path": path, "text": result.text, "meta": result.metadata})
        else:
            errors.append({"path": path, "reason": result.reason})

    return {**state, "filtered_documents": processed,
            "all_passed": len(errors) == 0, "errors": errors}


def route_after_filter(state: AnalystState) -> str:
    """Conditional edge: unde mergem după filtrare?"""
    return "extractor" if state["all_passed"] else "error_handler"


if __name__ == "__main__":
    state = {"document_paths": ["tests/valid_invoice.pdf", "tests/fake.pdf"]}
    state = filter_documents_node(state)
    print(f"passed:  {len(state['filtered_documents'])}")
    print(f"errors:  {state['errors']}")
    print(f"→ next node: {route_after_filter(state)}")
