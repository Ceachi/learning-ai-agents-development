class DataReaderAgent:
    # __init__, check_result, retry, output, build_graph, ...

    def route_after_check(self, state: DataReaderState) -> str:
        # Returnează NUMELE ramurii (nu nodul direct)
        if state["error"]:
            return "handle_error"
        return "continue"

    def _wire_check_routing(self, graph: StateGraph) -> None:
        graph.add_conditional_edges(
            "check",                  # din ce nod
            self.route_after_check,   # funcția de routing
            {
                "handle_error": "retry",
                "continue": "output",
            },
        )
