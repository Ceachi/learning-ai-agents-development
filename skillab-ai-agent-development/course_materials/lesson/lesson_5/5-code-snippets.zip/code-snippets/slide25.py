agent = DataReaderAgent(llm=..., tools=...)
app = agent.build_graph()

# Exemplu 1 — succes direct
result = app.invoke({
    "query": "Clienți în martie?",
    "max_retries": 2,
})
# selected_source: "sql"
# result:          {"count": 1247}
# sources_tried:   ["sql"]


# Exemplu 2 — retry + fallback
result = app.invoke({
    "query": "Contract X docs",
    "max_retries": 1,
})
# selected_source: "rag"          ← fallback după ce SQL a eșuat
# retry_count:     1
# sources_tried:   ["sql", "rag"]
# result:          {"documents": [...]}
