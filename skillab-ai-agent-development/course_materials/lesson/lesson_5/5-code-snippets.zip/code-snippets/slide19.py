from langgraph.graph import END, START, StateGraph


class DataReaderAgent:
    # __init__, noduri, routere ...

    def build_graph(self):
        # 1. Schema
        graph = StateGraph(DataReaderState)

        # 2. Noduri
        graph.add_node("parse", self.parse_query)
        graph.add_node("decide", self.decide_source)
        graph.add_node("generate", self.generate_query)
        graph.add_node("execute", self.execute_query)
        graph.add_node("check", self.check_result)

        # 3. Edge de start
        graph.add_edge(START, "parse")

        # 4. Edges simple
        graph.add_edge("parse", "decide")
        graph.add_edge("generate", "execute")
        graph.add_edge("execute", "check")

        # 5. Conditional edges
        graph.add_conditional_edges("decide", self.route_to_source, ...)
        graph.add_conditional_edges("check", self.route_after_check, ...)

        # 6. Compile
        return graph.compile()
