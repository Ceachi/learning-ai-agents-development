class DataReaderAgent:
    # __init__, decide_source, gen_*_query, build_graph, ...

    def route_to_source(self, state: DataReaderState) -> str:
        return state["selected_source"]   # "rag" | "csv" | "sql"

    # În build_graph:
    graph.add_conditional_edges(
        "decide_source",
        self.route_to_source,
        {
            "rag": "gen_rag_query",
            "csv": "gen_csv_query",
            "sql": "gen_sql_query",
        },
    )
