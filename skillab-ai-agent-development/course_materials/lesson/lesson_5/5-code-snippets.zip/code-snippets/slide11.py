from operator import add
from typing import Annotated, Optional, TypedDict


class DataReaderState(TypedDict):
    # Input
    query: str
    max_retries: int

    # Decizie LLM
    selected_source: str
    generated_query: str

    # Tracking (cu reducers)
    retry_count: int
    sources_tried: Annotated[list[str], add]

    # Output
    result: Optional[dict]
    error: Optional[str]
