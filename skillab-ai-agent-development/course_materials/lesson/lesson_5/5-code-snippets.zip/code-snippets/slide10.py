from operator import add
from typing import Annotated, TypedDict


class StateWithReducer(TypedDict):
    # Ultimul câștigă (default, fără reducer)
    current_source: str

    # Lista se extinde (reducer = add → concatenare)
    sources_tried: Annotated[list[str], add]

    # Custom reducer: contor incremental
    retry_count: Annotated[int, lambda a, b: a + b]
