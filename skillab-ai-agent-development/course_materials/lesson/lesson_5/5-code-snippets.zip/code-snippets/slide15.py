from langgraph.graph import START, StateGraph


class DataReaderAgent:
    # __init__, parse_query, decide_source, ...

    def build_graph(self) -> StateGraph:
        graph = StateGraph(DataReaderState)

        # Noduri (metode bound: self.parse_query, self.decide_source)
        graph.add_node("parse", self.parse_query)
        graph.add_node("decide", self.decide_source)

        # Edges
        graph.add_edge(START, "parse")        # intrarea în graf
        graph.add_edge("parse", "decide")     # parse → decide (necondițional)

        return graph
