from langgraph.graph import END, START, StateGraph


class DataReaderAgent:
    # __init__, noduri (parse_query, decide_source, generate_query,
    # execute_query, check_result), routere (route_to_source,
    # route_after_check) ...

    def build_graph(self):
        graph = StateGraph(DataReaderState)

        # Noduri
        graph.add_node("parse", self.parse_query)
        graph.add_node("decide", self.decide_source)
        graph.add_node("generate", self.generate_query)
        graph.add_node("execute", self.execute_query)
        graph.add_node("check", self.check_result)

        # Flow principal
        graph.add_edge(START, "parse")
        graph.add_edge("parse", "decide")
        graph.add_edge("generate", "execute")
        graph.add_edge("execute", "check")

        # Routing pe sursă (toate ramurile converg la "generate")
        graph.add_conditional_edges(
            "decide",
            self.route_to_source,
            {"rag": "generate", "csv": "generate", "sql": "generate"},
        )

        # Routing după check
        graph.add_conditional_edges(
            "check",
            self.route_after_check,
            {
                "success": END,
                "retry": "generate",
                "fallback": "decide",
                "fail": END,
            },
        )

        return graph.compile()
