from typing import Optional, TypedDict


class DataReaderState(TypedDict):
    # Input
    query: str
    max_retries: int

    # Procesare
    selected_source: str  # "rag" | "csv" | "sql"
    generated_query: str

    # Tracking
    retry_count: int
    sources_tried: list[str]

    # Output
    result: Optional[dict]
    error: Optional[str]
