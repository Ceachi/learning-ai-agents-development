class DataReaderAgent:
    AVAILABLE_SOURCES = {"rag", "csv", "sql"}

    def route_after_check(self, state: DataReaderState) -> str:
        # Succes
        if state["result"] and not state["error"]:
            return "success"

        # Mai avem retry-uri pe sursa curentă?
        if state["retry_count"] < state["max_retries"]:
            return "retry"

        # Mai există surse neîncercate?
        if set(state["sources_tried"]) < self.AVAILABLE_SOURCES:
            return "fallback"

        return "fail"
