agent = DataReaderAgent(llm=..., tools=...)
app = agent.build_graph()

initial_state: DataReaderState = {
    "query": "Vânzări din Q1 2024?",
    "max_retries": 2,
    "retry_count": 0,
    "sources_tried": [],
}

result = app.invoke(initial_state)

result["selected_source"]   # "sql"
result["result"]            # {"total": 150_000}
result["sources_tried"]     # ["sql"]
