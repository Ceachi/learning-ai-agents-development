class DataReaderAgent:
    # __init__, llm, tools, build_graph(), ...

    def node_name(self, state: DataReaderState) -> dict:
        # 1. Citește din state
        query = state["query"]

        # 2. Execută logica (folosind self.llm, self.tools, etc.)
        result = self._do_something(query)

        # 3. Returnează doar ce modifici
        return {
            "generated_query": result,
            "retry_count": state["retry_count"] + 1,
        }
