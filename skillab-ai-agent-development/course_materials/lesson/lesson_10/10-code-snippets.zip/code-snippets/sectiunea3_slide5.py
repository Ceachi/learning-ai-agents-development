"""
sectiunea3_slide5.py — Tipuri de Content în răspuns

Un tool poate returna 3 tipuri de content. Un singur tool call poate
întoarce o LISTĂ cu mai multe content-uri combinate.
"""
import mcp.types as types

# Cel mai comun — text simplu / Markdown (acoperă ~90% din cazuri).
text_content = types.TextContent(
    type="text",
    text="Rezultatul căutării...",
)

# Pentru vizualizări — chart, screenshot, diagramă (base64).
image_content = types.ImageContent(
    type="image",
    data="<base64_encoded>",
    mimeType="image/png",
)

# Referință către o resursă — clientul o citește separat prin URI.
embedded_resource = types.EmbeddedResource(
    type="resource",
    resource=types.TextResourceContents(
        uri="document://invoice-123",
        mimeType="application/json",
        text="{}",
    ),
)

# Un tool poate returna oricâte, în orice combinație:
combined = [text_content, image_content, embedded_resource]


if __name__ == "__main__":
    for c in combined:
        print(c.type)
