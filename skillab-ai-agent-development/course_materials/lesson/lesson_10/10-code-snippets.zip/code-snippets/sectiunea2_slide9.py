"""
sectiunea2_slide9.py — Error handling în protocol

JSON-RPC definește coduri standard de eroare. Folosește-le — nu inventa
coduri noi. Pentru erorile tale custom ai intervalul -32000..-32099.
"""

# Exemplu de error response.
ERROR_RESPONSE = {
    "jsonrpc": "2.0",
    "id": 1,
    "error": {
        "code": -32602,                 # Invalid params (cod standard)
        "message": "Invalid params",
        # Best practice: include detalii concrete pentru debugging.
        "data": {"details": "Missing required: query"},
    },
}

# Codurile standard JSON-RPC pe care le vei întâlni.
ERROR_CODES = {
    -32700: ("Parse error", "JSON invalid"),
    -32600: ("Invalid request", "Format greșit"),
    -32601: ("Method not found", "Metodă inexistentă"),
    -32602: ("Invalid params", "Args lipsă/greșite"),
    -32603: ("Internal error", "Bug în server"),
}

# Intervalul rezervat pentru erorile tale custom (app-defined).
APP_ERROR_RANGE = range(-32099, -31999)   # -32099 .. -32000


if __name__ == "__main__":
    for code, (name, desc) in ERROR_CODES.items():
        print(f"{code:>7}  {name:<16} {desc}")
    print(f"\nCustom errors: {APP_ERROR_RANGE.start} .. {APP_ERROR_RANGE.stop - 1}")
