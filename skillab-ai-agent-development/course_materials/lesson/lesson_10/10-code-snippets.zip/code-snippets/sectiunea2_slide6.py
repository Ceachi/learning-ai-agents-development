"""
sectiunea2_slide6.py — Capabilities Negotiation

La `initialize`, ambele părți declară ce pot face. Capabilities = contract:
fiecare parte știe exact ce poate cere de la cealaltă.
"""

# Ce poate face SERVERUL — îl trimite în răspunsul la `initialize`.
SERVER_CAPABILITIES = {
    "capabilities": {
        "tools": {},                       # expune tools
        "prompts": {},                     # expune prompts
        "resources": {"subscribe": True},  # resources + subscriptions
        "logging": {},                     # poate trimite logs către client
    },
    "serverInfo": {"name": "document-analyst", "version": "1.0.0"},
}

# Ce poate face CLIENTUL — îl trimite în request-ul `initialize`.
CLIENT_CAPABILITIES = {
    "capabilities": {
        "roots": {"listChanged": True},    # root directories
        "sampling": {},                    # poate face LLM sampling pentru server
    },
    "clientInfo": {"name": "claude-desktop", "version": "0.5.0"},
}


if __name__ == "__main__":
    import json
    print("SERVER declară:", json.dumps(SERVER_CAPABILITIES["capabilities"], indent=2))
    print("CLIENT declară:", json.dumps(CLIENT_CAPABILITIES["capabilities"], indent=2))
