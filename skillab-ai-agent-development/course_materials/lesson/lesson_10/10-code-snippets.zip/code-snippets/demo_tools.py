"""
demo_tools.py — implementări funcționale ale tool-urilor, DOAR pentru demo.

`tools/implementations.py` e scheletul de homework (NotImplementedError).
Ca demo-ul MCP să aibă ce executa, definim aici aceleași tools, complet,
folosind EXACT același sistem: @register_tool + params Pydantic.

Nu schimbăm nimic în registry/wrapper — doar populăm registry-ul cu tools
care chiar rulează.
"""
import pandas as pd

from tools.registry import register_tool
from tools.params import JoinDataParams, FilterDataParams


@register_tool
def join_data(params: JoinDataParams) -> pd.DataFrame:
    """Combină două DataFrames pe o cheie comună (inner/left/right/outer join)."""
    left_df, right_df = params.input_dfs[0], params.input_dfs[1]
    return pd.merge(
        left_df, right_df,
        left_on=params.left_key, right_on=params.right_key,
        how=params.how,
    )


@register_tool
def filter_data(params: FilterDataParams) -> pd.DataFrame:
    
    
    """Filtrează un DataFrame după o condiție (==, !=, >, <, >=, <=, contains)."""
    df = params.input_dfs[0]
    col = df[params.column]
    op = params.operator
    val = params.value

    if op == "==":
        mask = col.astype(str) == val
    elif op == "!=":
        mask = col.astype(str) != val
    elif op == ">":
        mask = pd.to_numeric(col, errors="coerce") > float(val)
    elif op == "<":
        mask = pd.to_numeric(col, errors="coerce") < float(val)
    elif op == ">=":
        mask = pd.to_numeric(col, errors="coerce") >= float(val)
    elif op == "<=":
        mask = pd.to_numeric(col, errors="coerce") <= float(val)
    elif op == "contains":
        mask = col.astype(str).str.contains(val, case=False, na=False)
    else:
        raise ValueError(f"Operator nesuportat: {op}")

    return df[mask]
