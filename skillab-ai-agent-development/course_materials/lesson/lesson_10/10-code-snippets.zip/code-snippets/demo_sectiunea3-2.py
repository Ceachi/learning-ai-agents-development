
from __future__ import annotations

import asyncio
import json
import os

import anthropic
from fastmcp import Client

from mcp_server import mcp   # serverul nostru FastMCP (wrapper peste registry)

MODEL = os.getenv("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")


def mcp_tools_to_anthropic(tools) -> list[dict]:
    """tools/list (MCP) -> formatul de tools al API-ului Anthropic."""
    return [
        {
            "name": t.name,
            "description": t.description,
            "input_schema": t.inputSchema,
        }
        for t in tools
    ]


async def main() -> None:
    client = anthropic.Anthropic()

    # Un singur client FastMCP, conectat in-process la serverul nostru.
    async with Client(mcp) as mcp_client:

        # 1. tools/list de la serverul TĂU
        tools = await mcp_client.list_tools()
        anthropic_tools = mcp_tools_to_anthropic(tools)
        print("Tools expuse de server:", [t.name for t in tools])

        # 2. Întrebarea utilizatorului
        user_msg = (
            "Din tabelul 'facturi', arată-mi doar facturile cu suma peste 1000. "
            "Folosește tool-urile disponibile."
        )
        print(f"\n[USER]: {user_msg}\n")
        messages = [{"role": "user", "content": user_msg}]

        # Bucla agentică: Claude decide -> executăm -> repetăm
        while True:
            resp = client.messages.create(
                model=MODEL,
                max_tokens=1024,
                tools=anthropic_tools,
                messages=messages,
            )

            tool_uses = [b for b in resp.content if b.type == "tool_use"]

            if not tool_uses:
                final = "".join(b.text for b in resp.content if b.type == "text")
                print(f"[CLAUDE]: {final}")
                break

            messages.append({"role": "assistant", "content": resp.content})

            # 3 & 4. Executăm fiecare tool prin serverul MCP
            tool_results = []
            for tu in tool_uses:
                print(f"[tool call] {tu.name}({json.dumps(tu.input, ensure_ascii=False)})")
                result = await mcp_client.call_tool(tu.name, tu.input)
                output = result.content[0].text
                print(f"   -> server: {output.splitlines()[0]} ...")
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": tu.id,
                    "content": output,
                })

            # 5. Rezultatele înapoi la Claude
            messages.append({"role": "user", "content": tool_results})


if __name__ == "__main__":
    asyncio.run(main())
