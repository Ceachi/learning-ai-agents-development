"""
sectiunea3_slide3.py — Handler pentru tool

Pattern-ul unui handler: extrage args (cu defaults) → execută → returnează
listă de Content. Aici e versiunea didactică, cu un singur tool.

(În demo-ul secțiunii handler-ul nu mai are if-uri per tool: rutează direct
prin ToolWrapper.call() — vezi mcp_adapter.py. Acesta arată forma de bază.)
"""
import mcp.types as types
from mcp.server.lowlevel import Server

server = Server("document-analyst")


@server.call_tool()
async def handle_tool_call(name: str, arguments: dict) -> list[types.TextContent]:
    if name == "search_documents":
        # Extrage parametrii — required direct, opționalii cu .get(default)
        query = arguments["query"]
        doc_type = arguments.get("doc_type")
        limit = arguments.get("limit", 10)

        # Execută logica (aici simulat)
        results = await search_db(query, doc_type, limit)

        # Returnează rezultat structurat ca TextContent
        return [types.TextContent(type="text", text=f"Găsite {len(results)} documente")]

    raise ValueError(f"Tool necunoscut: {name}")


async def search_db(query: str, doc_type: str | None, limit: int) -> list:
    """Stub de căutare — în realitate ai interoga un index/DB."""
    return [{"id": 1}, {"id": 2}]
