"""
sectiunea2_slide10.py — Arhitectura în Python

Structura minimă a unui server MCP. 3 părți: server · handlers · run loop.
Acesta CHIAR rulează ca server MCP pe stdio (îl interoghezi din demo /
MCP Inspector). Versiunea narată complet e în demo_sectiunea2.py.
"""

import asyncio

import mcp.types as types
from mcp.server.lowlevel import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

# 1. SERVER
server = Server("document-analyst")


# 2. HANDLERS — declară ce expune serverul
@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="search_documents",
            description="Caută documente.",
            inputSchema={
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        )
    ]


@server.call_tool()
async def call_tool(name: str, args: dict) -> list[types.TextContent]:                                    
    return [types.TextContent(type="text", text=f"ran {name}")]


# 3. RUN — pornește loop-ul stdio
async def main() -> None:
    async with stdio_server() as (read, write):
        await server.run(
            read,
            write,
            InitializationOptions(
                server_name="document-analyst",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
