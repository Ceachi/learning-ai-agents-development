from __future__ import annotations

import asyncio
import sys

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


def banner(label: str) -> None:
    print(f"\n{'═' * 64}\n  {label}\n{'═' * 64}")


async def main() -> None:
    # Lansează adaptorul MCP (care expune registry-ul tău) ca server stdio.
    params = StdioServerParameters(command=sys.executable, args=["mcp_adapter.py"])

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # ── tools/list — registry-ul tău devine catalog MCP (Slide 2,4,6) ──
            banner("tools/list  —  tool-urile TALE, ca tools MCP")
            tools = (await session.list_tools()).tools
            for t in tools:
                req = t.inputSchema.get("required", [])
                print(f"   • {t.name} — {t.description}")
                print(f"     required: {req}")

            # ── tools/call — filter_data prin ToolWrapper.call() (Slide 3,4) ──
            banner("tools/call  filter_data(facturi, suma > 1000)")
            res = await session.call_tool("filter_data", {
                "df_names": ["facturi"],
                "column": "suma",
                "operator": ">",
                "value": "1000",
            })
            print(res.content[0].text)

            # ── tools/call — join_data, alt tool, același mecanism (Slide 9) ──
            banner("tools/call  join_data(clienti × facturi pe client_id)")
            res = await session.call_tool("join_data", {
                "df_names": ["clienti", "facturi"],
                "left_key": "client_id",
                "right_key": "client_id",
                "how": "inner",
            })
            print(res.content[0].text)

            # ── error — value greșit pentru un Literal → validare Pydantic (Slide 7) ──
            banner("tools/call  cu 'how' invalid  →  validare Pydantic → JSON-RPC error")
            res = await session.call_tool("join_data", {
                "df_names": ["clienti", "facturi"],
                "left_key": "client_id",
                "right_key": "client_id",
                "how": "diagonal",   # nu e în Literal["inner","left","right","outer"]
            })
            print(f"   isError: {res.isError}")
            print(f"   mesaj  : {res.content[0].text[:200]}")

    banner("done")


if __name__ == "__main__":
    asyncio.run(main())
