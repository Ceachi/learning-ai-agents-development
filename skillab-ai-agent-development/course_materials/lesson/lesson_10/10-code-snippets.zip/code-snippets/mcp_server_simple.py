from fastmcp import FastMCP

# Creăm serverul MCP
mcp = FastMCP("demo-server")


# ── Tool 1: Salută un utilizator ─────────────────────────────────────────
@mcp.tool()
def saluta(nume: str) -> str:
    """Salută un utilizator pe nume."""
    return f"Salut, {nume}! 👋"


# ── Tool 2: Calculează suma unei liste ───────────────────────────────────
@mcp.tool()
def calculeaza_suma(numere: list[int]) -> int:
    """Calculează"""
    
    return sum(numere)


@mcp_tool()
def nl2sql(nl_query) -> str:
    state = agent.invoke()
    
    return state[sql]
# ── Tool 3: Analizează text ──────────────────────────────────────────────
@mcp.tool()
def analizeaza_text(text: str, include_spatii: bool = False) -> dict:
    """
    Analizează un text și returnează statistici.

    Args:
        text: Textul de analizat
        include_spatii: Dacă True, include spațiile în numărul de caractere
    """
    caractere = len(text) if include_spatii else len(text.replace(" ", ""))
    cuvinte = len(text.split())
    propozitii = text.count(".") + text.count("!") + text.count("?")

    return {
        "caractere": caractere,
        "cuvinte": cuvinte,
        "propozitii": propozitii,
        "include_spatii": include_spatii
    }


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "stdio":
        # Pentru Claude Desktop / Claude Code (fără auth, comunicare locală)
        mcp.run()
    else:
        # Pentru HTTP
        print("🚀 Server MCP pornit pe http://127.0.0.1:8000")
        print("📋 Tools disponibile: saluta, calculeaza_suma, analizeaza_text")
        print("⚠️  Fără autentificare (upgrade fastmcp pentru http_middleware)")

        mcp.run(
            transport="http",
            host="127.0.0.1",
            port=8000
        )
