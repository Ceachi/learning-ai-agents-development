# Secțiunea 3 — server MCP + Claude

Tool-urile tale (din `TOOL_REGISTRY`) ajung tool-uri MCP. Nu rescrii nimic.
Pui un wrapper deasupra. Gata.

## Fișiere

| Fișier | Ce face |
|--------|---------|
| `mcp_server.py` | serverul. citește `TOOL_REGISTRY`, scoate tool-urile pe MCP |
| `demo_sectiunea3.py` | Claude cheamă serverul singur (bucla agentică) |
| `demo_tools.py` | tool-urile efective (join, filter) pt demo |
| `sample_data.py` | 2 tabele: `clienti`, `facturi` |
| `tools/` | sistemul tău vechi (registry, wrapper, params, schemas) |
| `mcp.json` | config pt Claude |

## Pune pachetele

```bash
pip install fastmcp pandas makefun pydantic python-dotenv anthropic
```

Verifică:

```bash
python -c "import fastmcp, pandas, makefun, pydantic; print('ok')"
```

Dacă scrie `ok`, mergi mai departe. Dacă nu, lipsește un pachet. Instalează-l.

## STDIO vs HTTP — alege

Două feluri în care Claude vorbește cu serverul. Atât.

**STDIO** = Claude pornește serverul. Tu nu pornești nimic.
Problema: Claude pornește serverul din alt loc, cu alt python. De aici toate
erorile (`failed`, `No module named tools`). Bătaie de cap.

**HTTP** = tu pornești serverul. Stă pe localhost. Claude se conectează la el.
Ca în producție. Nimic nu depinde de python-ul lui Claude. Recomandat.

Mai jos: HTTP. (Pt stdio: `python mcp_server.py stdio` și `fastmcp install`.)

## HTTP — pas cu pas

### 1. Pornește serverul

```bash
cd /Users/francu.richard/Projects/SkillLab/course/lectures/10-mcp/code-snippets
python mcp_server.py
```

Vezi banner FastMCP + `Uvicorn running on http://127.0.0.1:8000`.
**Lasă terminalul deschis.** Serverul moare dacă închizi terminalul.

### 2. Alt terminal. Spune-i lui Claude unde e

Dacă ai băgat înainte un server stdio care dădea `failed`, scoate-l:

```bash
claude mcp remove document-analyst
```

Adaugă-l pe HTTP:

```bash
claude mcp add --transport http document-analyst http://127.0.0.1:8000/mcp
```

### 3. Verifică

```bash
claude mcp list
```

Vrei să vezi `document-analyst ✓ connected`.
Repornește sesiunea Claude dacă era pornită.

### 4. Întreabă-l pe Claude

> Din tabelul `facturi`, arată facturile cu suma peste 1000.

Claude alege singur `filter_data`, serverul îl rulează, Claude îți dă rezultatul.
Vezi request-ul venind în log-ul serverului.

## Demo într-o singură comandă (fără Claude Code)

Vrei doar să vezi bucla, fără config. Server pornit în același proces:

```bash
export ANTHROPIC_API_KEY=sk-...
python demo_sectiunea3.py
```

Claude ia lista de tool-uri, decide, serverul rulează, Claude răspunde.

## Când zice `failed` sau nu se conectează

Mergi pe listă, în ordine. Nu sări.

1. **Pornește serverul cu mâna întâi.** `python mcp_server.py`.
   - Banner + Uvicorn = bun. Treci mai departe.
   - Traceback = citește-l. Lipsește un pachet sau folderul `tools/`.

2. **Lipsește un pachet?** `No module named fastmcp` (sau pandas/makefun).

   ```bash
   python -m pip install fastmcp pandas makefun pydantic python-dotenv
   ```

3. **`No module named tools`?** Ai serverul vechi. Versiunea nouă are
   `sys.path.insert` sus de tot. Verifică:

   ```bash
   head -20 mcp_server.py | grep sys.path.insert
   ```

   Nu apare nimic = n-ai versiunea nouă. Pune-o.

4. **Lipsește folderul `tools/`?**

   ```bash
   ls tools/
   ```

   Nu vezi `registry.py wrapper.py params.py schemas.py` = serverul n-are ce
   importa. Copiază `tools/` lângă `mcp_server.py`.

5. **Server pornit dar Claude tot `failed`?** Serverul a murit între timp, sau
   alt program e pe portul 8000. Pornește-l din nou. Verifică să fie viu:

   ```bash
   curl -s http://127.0.0.1:8000/mcp | head -c 50
   ```

   Răspunde ceva = e viu. Nimic = e mort, pornește-l.

## De reținut

- HTTP: serverul trebuie pornit **înainte** ca Claude să-l folosească.
- Închizi terminalul cu serverul → Claude zice `failed`. Nu e stricat. E mort.
  Pornește-l iar.
- La curs: pornește serverul, arată că e viu, apoi arată Claude folosindu-l.
  Studenții văd request-urile venind în log. Asta e tot showul.

## De ce FastMCP

`@mcp.tool()` / `add_tool()` îți scrie singur JSON Schema din semnătură +
docstring și ascunde tot JSON-RPC-ul. Tu doar citești `TOOL_REGISTRY` și
înregistrezi tool-urile. Ca `to_langchain_tools()`, doar că pe MCP.
