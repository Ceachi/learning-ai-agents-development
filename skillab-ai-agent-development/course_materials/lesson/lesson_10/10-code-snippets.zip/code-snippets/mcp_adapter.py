"""
mcp_adapter.py — expune registry-ul TĂU de tools ca server MCP.

Ideea centrală a lecției: NU rescrii tool-urile pentru MCP. Ai deja un
sistem (registry + params Pydantic + ToolWrapper). MCP e doar încă un
"transport", exact cum ToolWrapper.to_langchain_tools() e transportul
LangChain. Aici adăugăm transportul MCP — un adaptor subțire.

Ce face adaptorul, mapat pe slide-urile Secțiunii 3:
  • tools/list  (Slide 2,4,6) ← TOOL_REGISTRY enabled, params Pydantic → JSON Schema
  • tools/call  (Slide 3,4)   → rutează prin ToolWrapper.call() (lookup+enabled+validare)
  • TextContent (Slide 5)     ← rezultatul tool-ului, serializat
  • error       (Slide 7)     ← excepțiile devin JSON-RPC error automat
"""

from __future__ import annotations

import asyncio

import pandas as pd
import mcp.types as types
from mcp.server.lowlevel import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

from tools.registry import TOOL_REGISTRY
from tools.wrapper import ToolWrapper

# Importăm tool-urile ca să se înregistreze în TOOL_REGISTRY (side-effect).
import demo_tools  # noqa: F401


# ── DataFrame store ──────────────────────────────────────────────────────
# Tool-urile tale cer `input_dfs` (DataFrames), dar LLM-ul nu trimite tabele
# prin JSON — trimite NUME. Clientul lucrează cu referințe ("clienti",
# "comenzi"); adaptorul rezolvă numele la DataFrame-ul real și îl injectează.
# Așa câmpul input_dfs rămâne ascuns LLM-ului, exact ca în _tool_to_info().
DATAFRAMES: dict[str, pd.DataFrame] = {}


def register_dataframe(name: str, df: pd.DataFrame) -> None:
    DATAFRAMES[name] = df


# ── Pydantic params model → JSON Schema MCP (Slide 2 & 6) ────────────────
def _params_to_input_schema(params_model) -> dict:
    """
    Construim inputSchema-ul (Slide 2: type/properties/required) iterând prin
    câmpurile modelului — exact ca ToolWrapper._tool_to_info().

    De ce nu model_json_schema() direct: input_dfs e list[pd.DataFrame], iar
    Pydantic nu poate genera JSON Schema pentru DataFrame. Îl sărim oricum
    (nu e user-facing), deci construim schema doar din câmpurile rămase.
    """
    props: dict = {}
    required: list[str] = []

    for field_name, field_info in params_model.model_fields.items():
        if field_name == "input_dfs":            # pasat programatic, nu de LLM
            continue

        ann = field_info.annotation
        prop: dict = {}

        # Literal[...] → enum (Slide 6). Altfel, tip JSON Schema simplu.
        if hasattr(ann, "__origin__") and getattr(ann, "__args__", None):
            from typing import Literal, get_origin, get_args
            if get_origin(ann) is Literal:
                prop = {"type": "string", "enum": list(get_args(ann))}
            else:
                prop = {"type": "string"}
        else:
            json_type = {
                "str": "string", "int": "integer", "float": "number",
                "bool": "boolean",
            }.get(getattr(ann, "__name__", ""), "string")
            prop = {"type": json_type}

        if field_info.description:
            prop["description"] = field_info.description
        props[field_name] = prop

        if field_info.is_required():
            required.append(field_name)

    # input_dfs înlocuit cu df_names: LLM-ul dă numele tabelelor din store.
    props["df_names"] = {
        "type": "array",
        "items": {"type": "string"},
        "description": f"Numele tabelelor de procesat. Disponibile: {list(DATAFRAMES)}",
    }
    required = ["df_names"] + required

    return {"type": "object", "properties": props, "required": required}


# ── 1. SERVER ────────────────────────────────────────────────────────────
server = Server("document-analyst-tools")


# ── 2a. tools/list — registry-ul TĂU devine catalog MCP (Slide 4) ────────
@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name=name,
            description=tool["description"],          # docstring-ul tău (Slide 10: descrieri clare)
            inputSchema=_params_to_input_schema(tool["params_model"]),
        )
        for name, tool in TOOL_REGISTRY.items()
        if tool["enabled"]                            # respectă enabled (ca .catalog())
    ]


# ── 2b. tools/call — rutează prin ToolWrapper.call() (Slide 3 & 7) ───────
@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    # Rezolvă numele de tabele → DataFrames și injectează-le ca input_dfs.
    df_names = arguments.pop("df_names", [])
    missing = [n for n in df_names if n not in DATAFRAMES]
    if missing:
        # Eroare descriptivă cu context (Slide 7 & 10), devine JSON-RPC error.
        raise ValueError(f"Tabele inexistente: {missing}. Disponibile: {list(DATAFRAMES)}")

    args = {**arguments, "input_dfs": [DATAFRAMES[n] for n in df_names]}

    # ToolWrapper.call() face deja: lookup + enabled-check + validare Pydantic
    # + execuție. Nu reimplementăm nimic — doar împachetăm rezultatul.
    result = ToolWrapper.call(name, args)

    # Serializăm rezultatul în TextContent (Slide 5). DataFrame → tabel lizibil.
    if isinstance(result, pd.DataFrame):
        text = f"{len(result)} rânduri:\n{result.to_string(index=False)}"
    else:
        text = str(result)
    return [types.TextContent(type="text", text=text)]


# ── 3. RUN ───────────────────────────────────────────────────────────────
async def main() -> None:
    # Populează store-ul cu date demo când serverul pornește.
    from sample_data import load_sample_dataframes
    for name, df in load_sample_dataframes().items():
        register_dataframe(name, df)

    async with stdio_server() as (read, write):
        await server.run(
            read,
            write,
            InitializationOptions(
                server_name="document-analyst-tools",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
