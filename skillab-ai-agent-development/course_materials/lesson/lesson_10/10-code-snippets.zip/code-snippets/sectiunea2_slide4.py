"""
sectiunea2_slide4.py — Protocol: JSON-RPC 2.0

Cele 3 tipuri de mesaje MCP. Sunt mesaje pe sârmă (JSON), nu logică Python —
le reprezentăm ca dict ca să se vadă structura exactă pe slide.

Regula de aur:  id prezent → request  ·  id absent → notification.
"""

# REQUEST — client → server. Are `id` → așteaptă răspuns.
REQUEST = {
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
        "name": "search_documents",
        "arguments": {"query": "factură 2024"},
    },
}

# RESPONSE — server → client. Același `id` → corelație cu request-ul.
RESPONSE = {
    "jsonrpc": "2.0",
    "id": 1,
    "result": {
        "content": [{"type": "text", "text": "Găsite 3 docs..."}],
    },
}

# NOTIFICATION — fără `id` → fire-and-forget, nu se așteaptă răspuns.
NOTIFICATION = {
    "jsonrpc": "2.0",
    "method": "notifications/resources/updated",
    "params": {"uri": "document://list"},
}


if __name__ == "__main__":
    print("REQUEST are id?     ", "id" in REQUEST)          # True  → request
    print("NOTIFICATION are id?", "id" in NOTIFICATION)     # False → notification
    print("RESPONSE id == REQUEST id?", RESPONSE["id"] == REQUEST["id"])  # corelație
