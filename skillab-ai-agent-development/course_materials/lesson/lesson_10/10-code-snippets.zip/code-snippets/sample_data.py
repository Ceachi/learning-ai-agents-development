
"""
sample_data.py — date demo. Două tabele mici ca tool-urile să aibă pe ce lucra.
"""
import pandas as pd


def load_sample_dataframes() -> dict[str, pd.DataFrame]:
    clienti = pd.DataFrame({
        "client_id": [1, 2, 3],
        "nume": ["Alpha SRL", "Beta SA", "Gamma SRL"],
        "oras": ["Iași", "Cluj", "Iași"],
    })
    facturi = pd.DataFrame({
        "client_id": [1, 1, 2, 3],
        "numar": ["F-001", "F-002", "F-003", "F-004"],
        "suma": [1500, 2300, 800, 4200],
    })
    return {"clienti": clienti, "facturi": facturi}
