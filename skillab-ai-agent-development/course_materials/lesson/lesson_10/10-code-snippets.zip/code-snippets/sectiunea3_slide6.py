"""
sectiunea3_slide6.py — Validare parametri cu JSON Schema

MCP rulează schema validation AUTOMAT, înainte de handler. Schema invalidă →
handler-ul nu rulează → primești automat -32602 Invalid params.
Nu mai scrii cod manual de validare.
"""

input_schema = {
    "type": "object",
    "properties": {
        "amount": {
            "type": "number",
            "minimum": 0,
            "maximum": 1_000_000,         # range numeric
        },
        "currency": {
            "type": "string",
            "enum": ["RON", "EUR", "USD"],  # listă de valori permise
        },
        "date": {
            "type": "string",
            "format": "date",             # date · email · uri · uuid · regex
        },
    },
    "required": ["amount", "currency"],
}

# Constrângeri suportate de JSON Schema:
#   type     → string · number · integer · boolean · object · array
#   enum     → ["RON", "EUR", "USD"]
#   min/max  → 0 ≤ amount ≤ 1.000.000
#   format   → date · email · uri · uuid · pattern


if __name__ == "__main__":
    import json
    print(json.dumps(input_schema, indent=2))
