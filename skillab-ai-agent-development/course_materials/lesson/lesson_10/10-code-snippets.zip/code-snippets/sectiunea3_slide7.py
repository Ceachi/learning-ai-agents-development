"""
sectiunea3_slide7.py — Error handling pentru tools

Distincția cheie:
  • rezultat GOL  → nu e eroare. return TextContent cu mesaj.
  • eroare REALĂ  → raise McpError cu codul corect.

Coduri: -32000 server/infrastructură · -32602 validare params.
"""
import mcp.types as types
from mcp.shared.exceptions import McpError


class DatabaseError(Exception): ...
class ValidationError(Exception): ...


async def handle_tool_call(name, arguments):
    try:
        if name == "search_documents":
            results = await search_db(arguments["query"])
            if not results:
                # Rezultat gol = SUCCES cu mesaj, NU eroare.
                return [types.TextContent(type="text", text="Nu am găsit documente.")]
            return [types.TextContent(type="text", text=f"{len(results)} găsite")]

    except DatabaseError as e:        # infrastructură → server error
        raise McpError(types.ErrorData(code=-32000, message=str(e)))
    except ValidationError as e:      # validare → invalid params
        raise McpError(types.ErrorData(code=-32602, message=str(e)))


async def search_db(query: str) -> list:
    return []
