"""
sectiunea3_slide2.py — Definirea unui tool

Un tool MCP = name + description + inputSchema (JSON Schema).
Atât are nevoie LLM-ul ca să știe CUM să apeleze tool-ul.
"""
import mcp.types as types

tool = types.Tool(
    name="search_documents",
    description="Caută documente după query și filtre",
    inputSchema={
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Textul de căutat",
            },
            "doc_type": {
                "type": "string",
                "enum": ["invoice", "contract", "receipt"],
            },
            "limit": {"type": "integer", "default": 10},
        },
        "required": ["query"],
    },
)


if __name__ == "__main__":
    print("name       :", tool.name)
    print("required   :", tool.inputSchema["required"])
    print("properties :", list(tool.inputSchema["properties"]))
