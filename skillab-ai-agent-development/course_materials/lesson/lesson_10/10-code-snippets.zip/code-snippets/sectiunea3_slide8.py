"""
sectiunea3_slide8.py — Primul tool complet: calculator

Cele 3 ingrediente puse cap la cap, sub 30 de linii:
  1. list_tools  2. call_tool  3. run

⚠ eval() e DOAR pentru demo — NICIODATĂ pe input real (execută cod arbitrar).
"""
import asyncio

import mcp.types as types
from mcp.server.lowlevel import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

server = Server("calculator-server")


# 1. Definește lista de tools
@server.list_tools()
async def list_tools():
    return [types.Tool(
        name="calculate",
        description="Execută calcule matematice",
        inputSchema={
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
        },
    )]


# 2. Implementează handler
@server.call_tool()
async def call_tool(name, arguments):
    if name == "calculate":
        result = eval(arguments["expression"])   # demo only!
        return [types.TextContent(type="text", text=str(result))]                                    
    raise ValueError(f"Tool necunoscut: {name}")


# 3. Rulează server
async def main():
    async with stdio_server() as (read, write):
        await server.run(
            read, write,
            InitializationOptions(
                server_name="calculator-server",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )


if __name__ == "__main__":
    asyncio.run(main())
