from langchain_core.prompts import ChatPromptTemplate

# 3 exemple cu același format → modelul învață pattern-ul
exemple = """
Input: "Livrarea a întârziat 2 săptămâni"
Output: NEGATIV

Input: "Produs ok, nimic special"
Output: NEUTRU

Input: "Suport excelent, recomand!"
Output: POZITIV
"""

prompt = ChatPromptTemplate.from_messages([
    ("system", f"Clasifică sentimentul. Exemple:\n{exemple}"),
    ("user", "Input: {text}\nOutput:")
])

raspuns = model.invoke(prompt.format_messages(
    text="Comandă livrată rapid, ambalaj rupt"
))
print(raspuns.content)
