# Variabilă la nivel de modul = cache pentru instanță
_instance: PromptRegistry | None = None

def get_prompt_registry() -> PromptRegistry:
    global _instance

    # Prima apelare: creează instanța
    if _instance is None:
        _instance = PromptRegistry(folder="prompts/")

    # Apelările următoare: returnează aceeași instanță
    return _instance
