# === Setup Langfuse (bash) ===
# # 1. Clonează repo-ul oficial Langfuse
# git clone https://github.com/langfuse/langfuse.git
# cd langfuse
#
# # 2. Pornește tot stack-ul (Postgres, ClickHouse, Redis, backend, UI)
# docker compose up -d
#
# # 3. UI disponibil pe http://localhost:3000
# #    Cont local → Settings → API Keys → generează cheile
# ==============================

import os
from dotenv import load_dotenv
from langfuse.langchain import CallbackHandler
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

# Handler-ul citește LANGFUSE_* din .env automat
handler = CallbackHandler()

# Gemini cu free tier (aistudio.google.com/apikey)
llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2,
)

# Pasezi handler-ul la invoke → trace în Langfuse
raspuns = llm.invoke(
    "Explică în 3 fraze ce e Chain of Thought.",
    config={"callbacks": [handler]}
)

print(raspuns.content)
