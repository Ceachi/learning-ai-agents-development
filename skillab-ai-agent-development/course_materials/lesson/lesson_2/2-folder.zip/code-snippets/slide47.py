
def react_loop(llm, mesaje: list, max_iterations: int = 5) -> str:
    # Loop Think → Act → Observe
    for _ in range(max_iterations):
        raspuns = llm.invoke(mesaje)
        mesaje.append(raspuns)

        # Dacă LLM-ul nu mai cere tool-uri → răspuns final
        if not raspuns.tool_calls:
            return raspuns.content

        # Altfel, execută toate tool-urile cerute (Act)
        for tool_call in raspuns.tool_calls:
            rezultat = execute_tool(tool_call)
            # Observe: trimitem rezultatul înapoi la LLM
            mesaje.append({
                "role": "tool",
                "tool_call_id": tool_call["id"],
                "content": str(rezultat)
            })

    raise RuntimeError("Max iterations atins fără răspuns final")


def execute_tool(tool_call: dict) -> str:
    name = tool_call["name"]
    args = tool_call["args"]

    # 1. Caută tool-ul în registry
    if name not in TOOL_REGISTRY:
        return f"Eroare: tool '{name}' nu există."

    # 2. Execuție sigură — prinde erorile, nu lăsa loop-ul să cadă
    try:
        return TOOL_REGISTRY[name](**args)
    except Exception as e:
        return f"Eroare la execuția '{name}': {e}"
