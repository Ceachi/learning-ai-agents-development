# Fără Factory
# Codul apelant trebuie să știe detaliile fiecărui provider
if provider == "openai":
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
elif provider == "anthropic":
    llm = ChatAnthropic(model="claude-sonnet-4-5-20250929",
                        temperature=0.2)
elif provider == "google":
    llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash",
                                 temperature=0.2)
else:
    raise ValueError(f"Provider necunoscut: {provider}")


# Cu Factory
class LLMFactory:
    @staticmethod
    def create(provider: str, **kwargs):
        # Logica de instanțiere centralizată într-un singur loc
        if provider == "openai":
            return ChatOpenAI(model="gpt-4o-mini", **kwargs)
        elif provider == "anthropic":
            return ChatAnthropic(
                model="claude-sonnet-4-5-20250929", **kwargs)
        elif provider == "google":
            return ChatGoogleGenerativeAI(
                model="gemini-2.5-flash", **kwargs)
        else:
            raise ValueError(f"Provider necunoscut: {provider}")

# Codul apelant nu mai cunoaște detaliile
llm = LLMFactory.create("anthropic", temperature=0.2)
