_shutdown = False

def _handle_shutdown(signum, frame):
    global _shutdown
    if _shutdown:
        # Al doilea Ctrl+C → exit imediat
        raise SystemExit(1)
    _shutdown = True
    print("\nTermin iterația curentă... (Ctrl+C din nou pentru force)")

signal.signal(signal.SIGINT, _handle_shutdown)

def react_loop_safe(llm, mesaje: list, max_iterations: int = 10) -> str:
    for i in range(max_iterations):
        # Verifică shutdown înainte de fiecare iterație
        if _shutdown:
            return "Întrerupt — răspuns parțial."

        .
        .
        .

    return "Max iterații atins."
