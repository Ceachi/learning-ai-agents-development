def register_tool(func):
    sig = inspect.signature(func)
    params = list(sig.parameters.values())

    # Validare 1: un singur param de tip BaseModel
    if len(params) != 1 or not issubclass(
        params[0].annotation, BaseModel
    ):
        raise TypeError(
            f"{func.__name__}: param unic de tip BaseModel obligatoriu"
        )

    # Validare 2: docstring obligatoriu (devine description pentru LLM)
    docstring = (func.__doc__ or "").strip()
    if not docstring:
        raise ValueError(
            f"{func.__name__}: docstring obligatoriu — devine "
            f"description vizibil pentru LLM."
        )
    if len(docstring) < 15:
        raise ValueError(
            f"{func.__name__}: docstring prea scurt ({len(docstring)} "
            f"caractere). LLM-ul are nevoie de min 15 ca să decidă."
        )

    TOOL_REGISTRY[func.__name__] = {
        "func": func,
        "params_model": params[0].annotation,
        "description": docstring,  # ← asta primește LLM-ul
    }
    return func


@register_tool
def calculator(params: CalculatorParams) -> str:
    """Evaluează o expresie matematică simplă."""
    ...

# ✗ Eșuează la import
@register_tool
def bad_tool(params: SomeParams) -> str:
    # Niciun docstring
    return "..."
# ValueError: bad_tool: docstring obligatoriu — devine description...

# ✗ Eșuează la import
@register_tool
def too_short(params: SomeParams) -> str:
    """Face ceva."""  # 11 caractere
    ...
# ValueError: too_short: docstring prea scurt (11 caractere)...
