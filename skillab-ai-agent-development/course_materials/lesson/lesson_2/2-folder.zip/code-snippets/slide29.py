from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

class PromptReloadHandler(FileSystemEventHandler):
    def __init__(self, registry: PromptRegistry):
        self.registry = registry

    def on_modified(self, event):
        # Reîncarcă doar când se modifică un fișier .yaml
        if event.src_path.endswith(".yaml"):
            print(f"Detectată modificare: {event.src_path}")
            self.registry.reload()

# Pornire file watcher pe folderul prompts/
registry = get_prompt_registry()
observer = Observer()
observer.schedule(PromptReloadHandler(registry),
                  path="prompts/",
                  recursive=True)
observer.start()

# Acum orice salvare a unui YAML → reload automat
