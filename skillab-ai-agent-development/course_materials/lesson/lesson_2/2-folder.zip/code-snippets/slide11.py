# Fără CoT
prompt = ChatPromptTemplate.from_messages([
    ("system", "Ești asistent contabil. Răspunde scurt."),
    ("user",
     "Factură: 100 RON + 250 RON, TVA 19%. "
     "Care e totalul?")
])

# Cu CoT
prompt = ChatPromptTemplate.from_messages([
    ("system", "Ești asistent contabil."),
    ("user",
     "Factură: 100 RON + 250 RON, TVA 19%. "
     "Gândește pas cu pas: "
     "1) subtotal, 2) TVA, 3) total.")
])
