import asyncio

# LLM Request (JSON) — exemplu de tool_calls multiple cerute simultan de LLM
llm_request = """
{
  "role": "assistant",
  "content": null,
  "tool_calls": [
    {
      "id": "call_001",
      "function": {
        "name": "web_search",
        "arguments": "{\\"query\\": \\"vremea Iași\\"}"
      }
    },
    {
      "id": "call_002",
      "function": {
        "name": "web_search",
        "arguments": "{\\"query\\": \\"vremea Cluj\\"}"
      }
    }
  ]
}
"""

# Execuție (Python)
async def execute_all_tools(tool_calls: list) -> list:
    # Lansăm toate tool-urile simultan, nu așteptăm pe rând
    tasks = [execute_tool_async(tc) for tc in tool_calls]
    return await asyncio.gather(*tasks)

async def execute_tool_async(tool_call: dict) -> dict:
    name = tool_call["name"]
    args = tool_call["args"]
    # Rulăm tool-ul sincron într-un thread separat
    rezultat = await asyncio.to_thread(TOOL_REGISTRY[name], **args)
    return {"tool_call_id": tool_call["id"], "content": str(rezultat)}

# Folosire în loop-ul ReAct:
rezultate = asyncio.run(execute_all_tools(raspuns.tool_calls))
