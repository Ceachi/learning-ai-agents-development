# Acces Global: get_prompt_registry()
from functools import lru_cache

@lru_cache(maxsize=1)
def get_prompt_registry() -> PromptRegistry:
    # O singură încărcare YAML, reutilizată în tot codul
    return PromptRegistry(folder="prompts/")

# Utilizare end-to-end
prompt = registry.render(
    "ask_ai_system",
    rol="expert juridic",
    domeniu="dreptul muncii",
    max_cuvinte=150
)
