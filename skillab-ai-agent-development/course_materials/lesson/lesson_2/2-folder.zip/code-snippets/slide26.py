from dataclasses import dataclass

@dataclass(frozen=True)
class PromptTemplate:
    # Reprezentarea internă a unui fișier YAML de prompt
    name: str
    version: str
    prompt: str
    description: str = ""
