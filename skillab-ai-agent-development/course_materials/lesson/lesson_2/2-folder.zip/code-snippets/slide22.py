
def analizeaza_review(text_review: str) -> str:
    # Prompt hardcodat — îngropat în funcție
    prompt = f"""Ești un analist de feedback clienți.
    Analizează review-ul de mai jos și extrage:
    - sentiment (pozitiv/negativ/neutru)
    - tema principală
    - sugestie de acțiune

    Review: {text_review}
    """
    return model.invoke(prompt).content

def rezuma_review(text_review: str) -> str:
    # Același rol, copy-paste, ușor diferit → divergență
    prompt = f"""Ești un analist de feedback clienți.
    Rezumă pe scurt review-ul: {text_review}
    """
    return model.invoke(prompt).content
