import json
from google import genai
from pydantic import ValidationError

client = genai.Client()

invoice = None
for attempt in range(3):
    try:
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=text,
            config={
                "response_mime_type": "application/json",
                "response_schema": Invoice,
            },
        )
        invoice = response.parsed
        break  # validarea a trecut → ieșim din loop
    except ValidationError as e:
        print(f"Încercare {attempt + 1} eșuată: {e}")
    except Exception as e:
        print(f"Eroare generală: {e}")
        break  # erori de rețea/API → nu mai retry-uim

if invoice:
    with open(f"{invoice.numar}.json", "w", encoding="utf-8") as f:
        json.dump(invoice.model_dump(), f, indent=2, ensure_ascii=False)
else:
    print("Toate retry-urile au eșuat")
