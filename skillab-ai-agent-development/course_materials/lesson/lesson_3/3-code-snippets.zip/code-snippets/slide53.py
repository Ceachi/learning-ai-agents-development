from pydantic import BaseModel, Field

# ─── Logică pură: extracția în sine (fără decorator) ──────
def extract_invoice_data(file_path: str) -> Invoice:
    """Funcția de business — apelată și din pipeline, și din tool."""
    pipeline = ExtractionPipeline()
    return pipeline.process(file_path, Invoice)

# ─── Wrapper 1: pas în pipeline batch ─────────────────────
def batch_step(files: list[str]) -> list[Invoice]:
    return [extract_invoice_data(f) for f in files]

# ─── Wrapper 2: tool pentru agent ─────────────────────────
class ExtractInvoiceParams(BaseModel):
    file_path: str = Field(description="Calea către factură", min_length=1)

@register_tool
def extract_invoice(params: ExtractInvoiceParams) -> dict:
    """Extrage date structurate dintr-o factură."""
    result = extract_invoice_data(params.file_path)
    return result.model_dump()
