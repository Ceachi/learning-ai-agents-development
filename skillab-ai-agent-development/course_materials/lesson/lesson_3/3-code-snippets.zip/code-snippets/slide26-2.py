from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter                                         

# 1. Încarcă factura
loader = PyPDFLoader("factura_001.pdf")
documents = loader.load()

# 2. Configurează splitter pentru text dens (facturi)
splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,      # facturi: info densă
    chunk_overlap=50,    # 10% overlap
)

# 3. Sparge documentele în chunks
chunks = splitter.split_documents(documents)

print(f"Pagini: {len(documents)}")
print(f"Chunks: {len(chunks)}")
print("--- Chunk 1 ---")
print(chunks[0].page_content)
