from pathlib import Path
from langchain_community.document_loaders import (
    PyPDFLoader, Docx2txtLoader, TextLoader, CSVLoader,
)

# Registry: extensie → loader potrivit
LOADER_REGISTRY = {
    "pdf":  PyPDFLoader,
    "docx": Docx2txtLoader,
    "txt":  TextLoader,                                              
    "csv":  CSVLoader,
}

def load_document(path: str):
    ext = Path(path).suffix.lstrip(".").lower()
    loader_cls = LOADER_REGISTRY[ext]
    return loader_cls(path).load()

# Un singur entry point pentru orice format
docs = load_document("factura.pdf")
print(len(docs), docs[0].metadata)
