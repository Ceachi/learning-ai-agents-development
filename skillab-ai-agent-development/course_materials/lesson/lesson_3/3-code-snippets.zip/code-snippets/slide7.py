from langchain_community.document_loaders import PyPDFLoader

# Încarcă PDF-ul și parsează conținutul
loader = PyPDFLoader("factura.pdf")
documents = loader.load()

# Fiecare pagină devine un Document
doc = documents[0]

print(doc.page_content)   # textul paginii
print(doc.metadata)       # {'source': 'factura.pdf', 'page': 0}
