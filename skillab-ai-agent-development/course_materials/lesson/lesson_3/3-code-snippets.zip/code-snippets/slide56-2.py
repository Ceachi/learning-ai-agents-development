from pydantic import BaseModel, Field

class ExtractInvoiceParams(BaseModel):
    file_path: str = Field(description="Cale către factură", min_length=1)

class ExtractContractParams(BaseModel):
    file_path: str = Field(description="Cale către contract", min_length=1)

@register_tool
def extract_invoice_tool(params: ExtractInvoiceParams) -> dict:
    """Extrage date din FACTURI: numar, data, client, total, produse.
    Folosește pentru facturi, invoices, documente financiare."""
    pipeline = ExtractionPipeline()
    return pipeline.process(params.file_path, Invoice).model_dump()

@register_tool
def extract_contract_tool(params: ExtractContractParams) -> dict:
    """Extrage date din CONTRACTE: prestator, beneficiar, valoare, durată.
    Folosește pentru contracte de prestări servicii,
    acorduri comerciale, convenții."""
    pipeline = ExtractionPipeline()
    return pipeline.process(params.file_path, Contract).model_dump()

# Agentul alege tool-ul potrivit pe baza docstring-urilor
tools = [extract_invoice_tool, extract_contract_tool]
