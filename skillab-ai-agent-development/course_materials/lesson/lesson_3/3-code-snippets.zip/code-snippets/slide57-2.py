from langchain_core.messages import SystemMessage, HumanMessage
from backend.config import get_langfuse_handler

# 1. Tools — convertite din registry-ul propriu
tools = ToolWrapper.to_langchain_tools()
llm_with_tools = llm.bind_tools(tools)

# 2. System prompt — randat cu tools active
base_prompt = """Ești un asistent AI care procesează documente.
Poți extrage date din facturi și contracte.
Când userul cere procesarea unui document, folosește tool-ul potrivit."""
prompt = render_prompt_with_tools(base_prompt)

# 3. Observabilitate — callback LangFuse opțional
langfuse = get_langfuse_handler()
callbacks = [langfuse] if langfuse else []

# 4. Invoke
messages = [
    SystemMessage(content=prompt),
    HumanMessage(content="Extrage datele din sample_docs/factura_001.pdf"),
]
response = llm_with_tools.invoke(messages, config={"callbacks": callbacks})
