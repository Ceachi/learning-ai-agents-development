from google import genai
from langchain_community.document_loaders import PyPDFLoader

client = genai.Client()

def extract_invoice_simple(file_path: str) -> Invoice:
    # 1. Load
    docs = PyPDFLoader(file_path).load()

    # 2. Combine pages (dacă e multi-page)
    full_text = "\n\n".join(doc.page_content for doc in docs)

    # 3. Extract direct (fără chunking)
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=full_text,
        config={
            "response_mime_type": "application/json",
            "response_schema": Invoice,
        },
    )
    invoice: Invoice = response.parsed

    # 4. Save
    save_json(invoice, "extracted_data/")
    return invoice
