from pydantic import BaseModel, Field
from typing import List

class Product(BaseModel):
    """Produs din factură."""
    denumire:    str
    cantitate:   int
    pret_unitar: float
    total:       float

class Invoice(BaseModel):
    """Factură completă."""
    numar:  str
    data:   str
    client: str
    # Listă imbricată — LLM-ul populează automat structura
    produse: List[Product] = Field(default=[])
    total_general: float
