from typing import Type
from google import genai
from pydantic import BaseModel
from langchain_text_splitters import RecursiveCharacterTextSplitter

class ExtractionPipeline:
    """Pipeline complet de extracție — sigur de folosit în multiprocessing."""

    def __init__(self, model: str = "gemini-2.0-flash"):
        self.model = model
        self.splitter = RecursiveCharacterTextSplitter(
            chunk_size=2000, chunk_overlap=200,
        )
        self._client: genai.Client | None = None   # lazy

    @property
    def client(self) -> genai.Client:
        # Inițializat per proces — clientul nu e pickle-able
        if self._client is None:
            self._client = genai.Client()
        return self._client

    def process(self, file_path: str, schema: Type[BaseModel]):
        # 1. Load
        docs = load_document(file_path)
        # 2. Chunk dacă e necesar
        if self._should_chunk(docs):
            chunks = self.splitter.split_documents(docs)
            text = "\n".join(c.page_content for c in chunks[:3])
        else:
            text = "\n".join(d.page_content for d in docs)
        # 3. Extract
        responses = []
        for chunk in chunks:
            responses += [self.client.models.generate_content(
                model=self.model,
                contents=chunk,
                config={
                    "response_mime_type": "application/json",
                    "response_schema": schema,
                },
            )
            ]
        return respones
