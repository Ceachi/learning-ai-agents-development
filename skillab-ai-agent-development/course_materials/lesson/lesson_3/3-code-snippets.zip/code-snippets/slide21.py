from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200,
    # Ordine: paragrafe → linii → cuvinte → caractere
    separators=["\n\n", "\n", " ", ""],
)

contract = (
    "Art. 1 - Obiectul\n\nPrestatorul se obligă...\n\n"
    "Art. 2 - Durata\n\nContractul intră în vigoare...\n\n"
    "Art. 3 - Plata\n\nBeneficiarul achită..."
)

# Split la \n\n → 1 chunk per articol (semantic!)
chunks = splitter.split_text(contract)

for i, c in enumerate(chunks, 1):
    print(f"--- Chunk {i} ---\n{c}\n")
