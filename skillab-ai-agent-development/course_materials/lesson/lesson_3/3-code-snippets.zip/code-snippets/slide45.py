from google import genai
from langchain_community.document_loaders import Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

client = genai.Client()

def extract_contract_chunked(file_path: str) -> Contract:
    # 1. Load
    docs = Docx2txtLoader(file_path).load()

    # 2. Chunk (document mare)
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=2000, chunk_overlap=200,
    )
    chunks = splitter.split_documents(docs)

    # 3. Combine primele chunks (info cheie e la început)
    text = "\n\n".join(c.page_content for c in chunks[:3])

    # 4. Extract dintr-un singur call
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=text,
        config={
            "response_mime_type": "application/json",
            "response_schema": Contract,
        },
    )
    return response.parsed
