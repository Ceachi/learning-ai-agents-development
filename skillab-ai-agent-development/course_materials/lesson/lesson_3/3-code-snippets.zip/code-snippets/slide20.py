from langchain_text_splitters import RecursiveCharacterTextSplitter

splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,      # caractere per chunk (sweet spot: 500–2000)
    chunk_overlap=200,    # 20% overlap — context la granițe
)

# documents = lista de Document obținută de la un loader
chunks = splitter.split_documents(documents)

print(f"Chunks generate: {len(chunks)}")
