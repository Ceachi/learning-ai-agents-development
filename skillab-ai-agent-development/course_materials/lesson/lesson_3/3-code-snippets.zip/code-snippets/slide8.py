from langchain_community.document_loaders import (
    PyPDFLoader, CSVLoader, TextLoader,
)
from langchain_core.documents import Document

# Loadere diferite pentru formate diferite
loaders = [
    PyPDFLoader("factura.pdf"),
    CSVLoader("export.csv"),
    TextLoader("termeni.txt"),
]

# Indiferent de format, .load() returnează List[Document]
for loader in loaders:
    docs: list[Document] = loader.load()
    print(docs[0].page_content)   # același tip
    print(docs[0].metadata)       # aceeași structură


from langchain_community.document_loaders import (
    PyPDFLoader,       # PDF
    Docx2txtLoader,    # Word
    TextLoader,        # TXT
    CSVLoader          # CSV
)


# ❌ 200+ linii manual parsing
# ❌ Encoding bugs (cp1250 vs UTF-8)
# ❌ Crash pe PDF-uri corupte
