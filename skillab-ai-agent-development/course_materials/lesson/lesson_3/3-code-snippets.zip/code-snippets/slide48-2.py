import json
from pathlib import Path
from queue import Queue
from threading import Thread
from pydantic import BaseModel

STOP = None   # sentinel propagat între workeri

def save_json(data: BaseModel, doc_type: str):
    out = Path("extracted_data") / doc_type
    out.mkdir(parents=True, exist_ok=True)
    filename = f"{data.numar.replace('/', '_')}.json"
    with open(out / filename, "w", encoding="utf-8") as f:
        json.dump(data.model_dump(), f, indent=2, ensure_ascii=False)

def run_save_pipeline(files_to_process, num_workers: int = 5):
    """Pornește workeri, procesează fișiere, oprește curat la final."""
    queue: Queue = Queue(maxsize=100)   # queue local, nu global

    def worker(worker_id: int):
        while True:
            item = queue.get()
            if item is STOP:
                queue.put(STOP)         # propagă oprirea în cascadă
                break
            data, doc_type = item
            try:
                save_json(data, doc_type)
                log_to_db(data, doc_type)
                notify(data, doc_type)
            except Exception as e:
                print(f"Worker {worker_id} error: {e}")

    workers = [Thread(target=worker, args=(i,)) for i in range(num_workers)]
    for w in workers: w.start()

    # Producer
    for file_path, doc_type in files_to_process:
        result = extract_document(file_path, doc_type)
        queue.put((result, doc_type))

    # Semnal de final — un singur STOP, se propagă singur
    queue.put(STOP)
    for w in workers: w.join()
