from langchain_core.documents import Document

def should_chunk(document: Document, max_size: int = 4000) -> bool:
    """Decide dacă documentul trebuie chunk-uit."""
    return len(document.page_content) > max_size

# Regula:
# - Factură (~2,000 chars)   → procesează direct
# - Contract (~8,000 chars)  → chunk
# - Raport (50,000+ chars)   → chunk
