from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.prompts import ChatPromptTemplate

# ─── Traditional (mecanic) ──────────────────────────────
splitter = RecursiveCharacterTextSplitter(chunk_size=1000)
chunks = splitter.split_documents(docs)
# → Chunks la 1000 caractere
# → Fără summaries

# ─── LLM-based (semantic) ───────────────────────────────
prompt = ChatPromptTemplate.from_messages([
    ("system", """Împarte textul în chunks semantice.
    Pentru fiecare chunk, generează un summary.
    Returnează JSON: {{chunks: [{{text, summary}}]}}"""),
    ("user", "{document}"),
])
result = llm.invoke(prompt.format_messages(document=doc))
# → Chunks semantice + summaries
