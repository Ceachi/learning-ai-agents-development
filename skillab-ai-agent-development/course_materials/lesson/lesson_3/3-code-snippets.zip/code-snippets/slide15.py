from pathlib import Path
from langchain_community.document_loaders import (
    PyPDFLoader, Docx2txtLoader, TextLoader, CSVLoader,
)

LOADER_REGISTRY = {
    "pdf": PyPDFLoader, "docx": Docx2txtLoader,
    "txt": TextLoader, "csv": CSVLoader,
}

def load_document(path: str):
    ext = Path(path).suffix.lstrip(".").lower()
    if ext not in LOADER_REGISTRY:
        raise ValueError(f"Tip nesuportat: .{ext}")
    return LOADER_REGISTRY[ext](path).load()

try:
    docs = load_document("factura.xlsx")
except FileNotFoundError:
    print("Fisier inexistent")
except ValueError as e:
    print(e)                      # Tip nesuportat: .xlsx
except UnicodeDecodeError:
    print("Encoding gresit")
