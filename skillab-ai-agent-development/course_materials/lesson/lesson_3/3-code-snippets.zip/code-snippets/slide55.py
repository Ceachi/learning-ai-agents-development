from pydantic import BaseModel, Field

class ExtractInvoiceParams(BaseModel):
    """Parametri pentru extracție factură."""
    file_path: str = Field(
        description="Calea relativă (ex: sample_docs/factura_001.pdf)",
        min_length=1,
    )

@register_tool
def extract_invoice_tool(params: ExtractInvoiceParams) -> dict:
    """Extrage date dintr-o factură (PDF, DOCX, TXT).

    Folosește acest tool când userul cere extracția de date
    din facturi, invoices sau documente financiare.

    Returns: dict cu numar, data, client, furnizor, total, produse
    """
    try:
        # Reutilizăm funcția pură definită în slide 53
        invoice = extract_invoice_data(params.file_path)
        return invoice.model_dump()
    except FileNotFoundError:
        return {"error": f"Fișier inexistent: {params.file_path}"}
    except Exception as e:
        return {"error": f"Extracție eșuată: {str(e)}"}
