# Ce avem după loading + chunking: text nestructurat
text = """
FACTURĂ NR. 2024-001
Data: 15.02.2024
Client: SC ClientCorp SA
Total: 9,520 RON
"""

# Ce vrem: JSON structurat, consistent
expected = {
    "numar":  "2024-001",
    "data":   "2024-02-15",
    "client": "SC ClientCorp SA",
    "total":  9520.0,
}

# Problema: LLM-ul returnează text liber, nu JSON consistent.
# Soluția: Structured Output cu Pydantic (slide-urile următoare)
