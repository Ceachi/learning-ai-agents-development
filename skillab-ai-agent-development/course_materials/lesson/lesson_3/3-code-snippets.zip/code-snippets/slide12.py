from langchain_community.document_loaders import Docx2txtLoader

loader = Docx2txtLoader("contract_001.docx")
documents = loader.load()

# 1 Document pentru tot fișierul (nu împarte pe pagini)
print(f"Documents: {len(documents)}")   # 1

doc = documents[0]
print(doc.metadata)            # {'source': 'contract_001.docx'}
print(doc.page_content[:200])  # primele 200 caractere
