from pydantic import BaseModel, Field

class ExtractInvoiceParams(BaseModel):
    """Parametri pentru tool-ul extract_invoice."""
    file_path: str = Field(
        description="Calea către fișier (PDF, DOCX, TXT)",
        min_length=1,
    )

@register_tool
def extract_invoice(params: ExtractInvoiceParams) -> dict:
    """Extrage date structurate dintr-o factură (numar, data, client, total, produse).
    Folosește când userul cere parsare/extracție dintr-un document factură."""
    try:
        pipeline = ExtractionPipeline()
        result = pipeline.process(params.file_path, Invoice)
        return result.model_dump()
    except FileNotFoundError:
        return {"error": f"Fișier inexistent: {params.file_path}"}
    except Exception as e:
        return {"error": f"Extracție eșuată: {str(e)}"}
