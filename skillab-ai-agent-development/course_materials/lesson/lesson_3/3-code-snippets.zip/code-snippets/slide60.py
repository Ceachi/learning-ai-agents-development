from pydantic import BaseModel, Field, ValidationError

class ExtractInvoiceParams(BaseModel):
    file_path: str = Field(description="Calea către factură", min_length=1)

@register_tool
def extract_invoice_tool(params: ExtractInvoiceParams) -> dict:
    """Extrage date dintr-o factură."""
    try:
        invoice = extract_invoice_data(params.file_path)
        return {
            "success": True,
            "data":    invoice.model_dump(),
            "message": f"Factură {invoice.numar} procesată",
        }
    except FileNotFoundError:
        return {"success": False, "error": "Fișierul nu a fost găsit"}
    except ValidationError as e:
        return {"success": False, "error": f"Validare eșuată: {e}"}
    except Exception as e:
        # Niciodată exception raw — agentul nu poate citi traceback
        return {"success": False, "error": f"Eroare procesare: {str(e)}"}
