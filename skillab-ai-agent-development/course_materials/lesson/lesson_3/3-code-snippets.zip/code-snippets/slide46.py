EXTRACTION_REGISTRY = {
    "factura": {
        "schema":     Invoice,
        "chunk_size": None,        # Nu chunk-ui facturi
        "prompt":     invoice_prompt,
    },
    "contract": {
        "schema":     Contract,
        "chunk_size": 2000,
        "prompt":     contract_prompt,
    },
}

def extract_document(file_path: str, doc_type: str):
    config = EXTRACTION_REGISTRY[doc_type]
    docs = load_document(file_path)

    # Chunk doar dacă e necesar
    if config["chunk_size"]:
        docs = chunk_documents(docs, config["chunk_size"])

    return extract_with_schema(docs, config["schema"])
