# 1. Document mic — direct la LLM, fără splitting
if len(document.page_content) < 2000:
    llm.invoke(document.page_content)

# 2. Model cu context mare (Claude 200K, Gemini 1M+)
#    Trimiți tot documentul odată (atenție la cost!)
full_text = "\n".join(d.page_content for d in documents)
llm.invoke(full_text)

# 3. Procesare per pagină — facturi 1–2 pagini
for page_doc in documents:
    extract(page_doc)

# Regula: chunking doar când documentul nu încape
# confortabil în context window.
