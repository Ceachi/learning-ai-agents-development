from typing import List, Type
from concurrent.futures import ProcessPoolExecutor, as_completed
from pydantic import BaseModel

# Helper la modul-level (cerință pentru pickle în multiprocessing)
def _process_one(file_path: str, schema: Type[BaseModel]):
    # Pipeline reinstanțiat per worker → client Gemini propriu
    pipeline = ExtractionPipeline()
    return pipeline.process(file_path, schema)

def batch_extract(files: List[str], schema: Type[BaseModel],
                  num_workers: int = 4):
    results = {"success": [], "errors": []}

    with ProcessPoolExecutor(max_workers=num_workers) as executor:
        # Submit toate fișierele, păstrăm maparea future → file_path
        future_to_file = {
            executor.submit(_process_one, f, schema): f for f in files
        }
        # Procesăm rezultatele pe măsură ce sunt gata
        for future in as_completed(future_to_file):
            file_path = future_to_file[future]
            try:
                data = future.result()
                results["success"].append({"file": file_path, "data": data})
            except Exception as e:
                results["errors"].append({"file": file_path, "error": str(e)})

    print(f"Success: {len(results['success'])}")
    print(f"Errors:  {len(results['errors'])}")
    return results
