import hashlib
from pathlib import Path
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

path = "facturi/factura_001.pdf"
documents = PyPDFLoader(path).load()
chunks = RecursiveCharacterTextSplitter(
    chunk_size=500, chunk_overlap=50,
).split_documents(documents)

# Hash unic per fișier — pentru deduplicare
file_hash = hashlib.md5(Path(path).read_bytes()).hexdigest()

for i, chunk in enumerate(chunks):
    chunk.metadata.update({
        # Filtrare în RAG
        "doc_type":   "factura",
        "client_id":  "ACME-123",
        "language":   "ro",
        "created_at": "2024-02-15",
        # Debugging
        "chunk_id":   i,
        # Citări (source & page vin deja de la loader)
        "title":      "Factură 2024-001",
        # Deduplicare
        "file_hash":  file_hash,
    })

print(chunks[0].metadata)
