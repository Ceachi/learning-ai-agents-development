from pydantic import BaseModel

class Invoice(BaseModel):
    numar:  str
    data:   str
    client: str
    total:  float

# Beneficii:
# - Type safety (validare automată a tipurilor)
# - Default values (câmpuri opționale cu fallback)
# - Field descriptions (documentație inline pentru LLM)
# - JSON ↔ Python (conversie automată cu model_dump())
