from langchain_community.document_loaders import TextLoader, CSVLoader

# TextLoader — encoding contează pentru diacritice
text_loader = TextLoader("termeni.txt", encoding="utf-8")
text_docs = text_loader.load()
print(f"Text: {len(text_docs)} Document")   # 1 — tot fișierul

# CSVLoader — 1 Document per rând
csv_loader = CSVLoader("facturi_export.csv")
csv_docs = csv_loader.load()
print(f"CSV:  {len(csv_docs)} Documents")   # ex: 50 rânduri

# Output per rând CSV:
# numar: 2024-001
# data: 2024-02-15
# suma: 6000 RON
print(csv_docs[0].page_content)
