from langchain_community.document_loaders import PyPDFLoader

loader = PyPDFLoader("facturi/factura_001.pdf")
documents = loader.load()

# 1 Document per pagină PDF
print(f"Pagini extrase: {len(documents)}")

# Iterăm prin fiecare pagină
for doc in documents:
    page_num = doc.metadata["page"]
    preview = doc.page_content[:80]
    print(f"\n--- Pagina {page_num} ---")
    print(preview)
