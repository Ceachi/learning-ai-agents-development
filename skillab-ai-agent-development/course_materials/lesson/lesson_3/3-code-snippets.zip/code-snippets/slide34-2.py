from google import genai
from pydantic import BaseModel

class Invoice(BaseModel):
    numar:  str
    total:  float

client = genai.Client()

# Forțăm output-ul să respecte schema Invoice
response = client.models.generate_content(
    model="gemini-2.0-flash",
    contents="Extrage datele din: FACTURĂ NR. 2024-001, Total: 9520 RON",
    config={
        "response_mime_type": "application/json",
        "response_schema": Invoice,
    },
)

invoice: Invoice = response.parsed
print(invoice.numar)    # "2024-001"
print(invoice.total)    # 9520.0
print(type(invoice))    # <class 'Invoice'>
