from pydantic import ValidationError

def extract_with_error_handling(file_path: str, doc_type: str):
    # 1. Load
    try:
        docs = load_document(file_path)
    except FileNotFoundError:
        return {"error": "Fișier inexistent"}
    except ValueError as e:
        return {"error": f"Tip fișier nesuportat: {e}"}

    # 2. Extract
    try:
        result = extract_with_schema(docs, doc_type)
    except ValidationError as e:
        return {"error": f"Validare eșuată: {e}"}
    except Exception as e:
        return {"error": f"Extracție eșuată: {e}"}

    save_json(result, output_dir)
    return {"success": True, "data": result}
