from google import genai

client = genai.Client()

# System prompt = context + rol pentru LLM
system_prompt = """Ești un expert în extragerea datelor din facturi.
Extrage cu atenție toate câmpurile cerute.
Dacă un câmp lipsește, lasă-l null."""

# User prompt cu placeholder — refolosit pentru orice factură
def extract_invoice(invoice_text: str) -> Invoice:
    response = client.models.generate_content(
        model="gemini-2.0-flash",
        contents=f"Extrage datele din această factură:\n\n{invoice_text}",
        config={
            "system_instruction": system_prompt,
            "response_mime_type": "application/json",
            "response_schema": Invoice,
        },
    )
    return response.parsed

result = extract_invoice(text)
