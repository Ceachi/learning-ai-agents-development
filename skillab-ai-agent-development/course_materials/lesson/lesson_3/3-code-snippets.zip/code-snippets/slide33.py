from pydantic import BaseModel, Field
from typing import List

class Invoice(BaseModel):
    """Schemă pentru extracție date factură."""

    numar:    str = Field(description="Numărul facturii (ex: 2024-001)")
    data:     str = Field(description="Data emiterii (format: YYYY-MM-DD)")
    client:   str = Field(description="Numele clientului")
    furnizor: str = Field(description="Numele furnizorului")
    total:  float = Field(description="Suma totală în RON")

    produse: List[str] = Field(
        default=[],                              # câmp opțional
        description="Lista produse/servicii",    # ghidează LLM-ul
    )
