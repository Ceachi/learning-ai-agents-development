import json
from google import genai
from pydantic import BaseModel

# 1. Definește schema
class Invoice(BaseModel):
    numar: str
    total: float

# 2. Configurează clientul Gemini
client = genai.Client()

# 3. Extrage din text
invoice_text = "FACTURĂ NR. 2024-001\nTotal: 9,520 RON"
response = client.models.generate_content(
    model="gemini-2.0-flash",
    contents=invoice_text,
    config={
        "response_mime_type": "application/json",
        "response_schema": Invoice,
    },
)
result: Invoice = response.parsed

# 4. Salvează JSON
with open("factura_001.json", "w", encoding="utf-8") as f:
    json.dump(result.model_dump(), f, indent=2, ensure_ascii=False)
