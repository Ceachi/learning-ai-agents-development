import spacy

nlp = spacy.load("ro_core_news_lg")

LABEL_MAP = {
    "PERSON": "PER",
    "PER": "PER",
    "ORG": "ORG",
    "LOC": "LOC",
    "GPE": "LOC",
    "DATE": "DATE",
}

def extract_entities_spacy(text: str) -> dict:
    """Extrage entități cu spaCy"""
    doc = nlp(text)

    entities = {"PER": [], "ORG": [], "LOC": [], "DATE": []}

    for ent in doc.ents:
        key = LABEL_MAP.get(ent.label_)
        if key:
            entities[key].append(ent.text)

    return entities

print(extract_entities_spacy("Ion Popescu lucreaza la Google"))