# Cum facem acum în agent (SCUMP)
async def detect_intent_llm(query: str, llm: LLMProvider) -> str:
    prompt = f"""Clasifică intent-ul query-ului în una din categorii:
- search: caută informații
- extract: extrage date din documente
- analyze: analizează și compară
- report: generează raport

Query: {query}
Răspunde doar cu categoria."""

    response = await llm.generate([Message(role="user", content=prompt)])
    return response.strip().lower()

# Cost: ~$0.02/call    │    Latență: ~500ms
# La 10.000 queries/zi = $200/zi doar pentru intent detection
