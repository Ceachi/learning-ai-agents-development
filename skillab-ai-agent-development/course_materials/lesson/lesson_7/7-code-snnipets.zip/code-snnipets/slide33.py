from sentence_transformers import SentenceTransformer

# Încarcă modelul local — o singură dată la startup
# Gratuit, offline, fără API
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')


def get_embedding(text: str) -> list[float]:
    """Generează embedding local"""
    embedding = model.encode(text)
    return embedding.tolist()


# Test
emb = get_embedding("facturile TechSoft din martie")
print(len(emb))  # 384 dimensiuni
