class EmbeddingService:
    """Serviciu de embeddings cu cache — singleton"""

    def __init__(self):
        self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
        self.cache = load_cache()
        self.stats = {"hits": 0, "misses": 0}

    def embed(self, text: str) -> list[float]:
        key = hashlib.md5(text.encode()).hexdigest()

        if key in self.cache:
            self.stats["hits"] += 1
            return self.cache[key]

        self.stats["misses"] += 1
        emb = self.model.encode(text).tolist()
        self.cache[key] = emb
        return emb


# Utilizare în retriever node
embedding_service = EmbeddingService()
query_emb = embedding_service.embed(state["query"])
