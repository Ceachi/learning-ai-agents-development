from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
import joblib

# Separăm textele și label-urile
texts = [t[0] for t in training_data]
labels = [t[1] for t in training_data]

# Creăm pipeline-ul
classifier = Pipeline([
    ('tfidf', TfidfVectorizer(ngram_range=(1, 2))),
    ('clf', LogisticRegression(max_iter=1000))
])

# Antrenăm
classifier.fit(texts, labels)

# Salvăm pentru producție
joblib.dump(classifier, 'intent_classifier.joblib')
