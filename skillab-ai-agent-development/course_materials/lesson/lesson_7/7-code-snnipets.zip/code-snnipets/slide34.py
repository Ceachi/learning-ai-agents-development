import hashlib
import json
from pathlib import Path

CACHE_FILE = Path("embedding_cache.json")


def load_cache() -> dict:
    if CACHE_FILE.exists():
        return json.loads(CACHE_FILE.read_text())
    return {}


def save_cache(cache: dict):
    CACHE_FILE.write_text(json.dumps(cache))


def get_embedding_cached(text: str) -> list[float]:
    """Embedding cu cache persistent"""
    cache = load_cache() 
    key = hashlib.md5(text.encode()).hexdigest()                                                

    if key in cache:
        return cache[key]  # Cache HIT

    # Cache MISS — calculăm
    embedding = get_embedding(text)
    cache[key] = embedding
    save_cache(cache)
    return embedding
