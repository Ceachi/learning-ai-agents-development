# Date de antrenament — poți genera cu LLM o singură dată
training_data = [
    # SEARCH
    ("găsește facturile din martie", "search"),
    ("caută contractele cu TechSoft", "search"),
    ("arată documentele din 2024", "search"),

    # EXTRACT
    ("extrage datele din factură", "extract"),
    ("scoate sumele din contract", "extract"),
    ("parsează PDF-ul atașat", "extract"),

    # ANALYZE
    ("compară vânzările Q1 vs Q2", "analyze"),
    ("analizează trendurile", "analyze"),

    # REPORT
    ("generează raport lunar", "report"),
    ("creează overview pentru Q1", "report"),
]

# 💡 TIP: Generează 50-100 exemple per clasă cu LLM,
# apoi antrenezi classifier-ul o singură dată.
