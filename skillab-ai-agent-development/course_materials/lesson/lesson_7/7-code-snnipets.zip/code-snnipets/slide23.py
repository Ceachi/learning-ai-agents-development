import json


# Cum facem acum (SCUMP)
async def extract_entities_llm(text: str, llm: LLMProvider) -> dict:
    prompt = f"""Extrage entitățile din text:
- persoane (PER)
- organizații (ORG)
- locații (LOC)
- date (DATE)
- sume de bani (MONEY)

Text: {text}
Răspunde în format JSON."""

    response = await llm.generate([Message(role="user", content=prompt)])
    return json.loads(response)

# Cost: ~$0.03/call    │    Latență: ~600ms
# La 50.000 extracții/zi = $1.500/zi
