def route_by_intent(state: AgentState) -> str:
    """Router node — folosește classifier în loc de LLM"""
    query = state["query"]
    intent, confidence = detect_intent(query)

    # Fallback la LLM pentru cazuri ambigue
    if confidence < 0.7:
        intent = detect_intent_llm(query)
        state["used_llm_fallback"] = True

    # Routing based on intent
    routing = {
        "search":  "retriever_node",
        "extract": "extractor_node",
        "analyze": "analyst_node",
        "report":  "report_node",
    }
    return routing.get(intent, "default_node")


# În graf
workflow.add_conditional_edges("start", route_by_intent)
