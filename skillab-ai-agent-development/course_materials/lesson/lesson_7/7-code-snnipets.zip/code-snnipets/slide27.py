def extract_all_entities(text: str) -> dict:
    """Combină spaCy + Regex pentru extracție completă"""

    # 1. spaCy pentru entități naturale
    spacy_entities = extract_entities_spacy(text)

    # 2. Regex pentru formate fixe
    regex_entities = extract_with_regex(text)

    # 3. Combinăm rezultatele
    return {
        "persons":       spacy_entities.get("PER", []),
        "organizations": spacy_entities.get("ORG", []),
        "locations":     spacy_entities.get("LOC", []),
        "invoice_ids":   regex_entities.get("invoice_id", []),
        "amounts":       regex_entities.get("amount", []),
        "dates":         regex_entities.get("date_ro", []),
        "emails":        regex_entities.get("email", []),
    }


# În agent — înlocuiește LLM call
entities = extract_all_entities(document_text)
