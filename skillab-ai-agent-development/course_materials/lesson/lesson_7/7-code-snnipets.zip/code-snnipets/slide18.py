import joblib

# Încărcăm o singură dată la startup
classifier = joblib.load('intent_classifier.joblib')


def detect_intent(query: str) -> tuple[str, float]:
    """Detectează intent-ul - înlocuiește LLM call"""
    intent = classifier.predict([query])[0]
    confidence = max(classifier.predict_proba([query])[0])
    return intent, confidence


# Utilizare în agent node
intent, conf = detect_intent("găsește facturile TechSoft")
# → ("search", 0.94)

if conf < 0.7:  # Fallback la LLM dacă nu e sigur
    intent = detect_intent_llm(query)
