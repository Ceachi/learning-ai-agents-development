import time


def benchmark(func, *args, iterations=100):
    """Măsoară latența medie"""
    times = []
    for _ in range(iterations):
        start = time.perf_counter()
        func(*args)
        times.append(time.perf_counter() - start)

    return {
        "avg_ms": sum(times) / len(times) * 1000,
        "min_ms": min(times) * 1000,
        "max_ms": max(times) * 1000,
    }


# Comparăm
llm_stats = benchmark(detect_intent_llm, query, iterations=20)
ml_stats  = benchmark(detect_intent_sklearn, query, iterations=100)                       

print(f"LLM: {llm_stats['avg_ms']:.0f}ms")  # ~500ms
print(f"ML:  {ml_stats['avg_ms']:.1f}ms")   # ~5ms
