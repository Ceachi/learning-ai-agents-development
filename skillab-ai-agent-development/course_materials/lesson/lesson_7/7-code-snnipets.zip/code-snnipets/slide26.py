import re
from datetime import datetime

# Patterns pentru entități cu format predictibil
PATTERNS = {
    "invoice_id": r"(?:factura|fact\.?|#)\s*(\d{4,10})",
    "amount":     r"(\d{1,3}(?:[.,]\d{3})*(?:[.,]\d{2})?)\s*(RON|EUR|USD|lei)",
    "email":      r"[\w.-]+@[\w.-]+\.\w+",
    "date_ro":    r"(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})",
}


def extract_with_regex(text: str) -> dict:
    """Extrage entități cu format fix"""
    results = {}
    for name, pattern in PATTERNS.items():
        matches = re.findall(pattern, text, re.IGNORECASE)
        if matches:
            results[name] = matches
    return results

text = "Factura #12345 pentru 1.500,00 RON din 15.03.2024"
print(extract_with_regex(text))
# ⇒ {"invoice_id": ["12345"], "amount": [("1.500,00", "RON")], "date_ro": [...]}
