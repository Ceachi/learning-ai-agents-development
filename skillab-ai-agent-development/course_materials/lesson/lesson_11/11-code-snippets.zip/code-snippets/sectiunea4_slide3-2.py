from sagemaker.async_inference import AsyncInferenceConfig

# 1. Configurăm comportamentul async
async_config = AsyncInferenceConfig(
    output_path="s3://my-bucket/async-output/",

    # Notificări SNS (opțional)
    notification_config={
        "SuccessTopic": "arn:aws:sns:eu-central-1:123:success",
        "ErrorTopic": "arn:aws:sns:eu-central-1:123:error",
    },
    max_concurrent_invocations_per_instance=4,
)

# 2. Deploy cu config-ul async (model = HuggingFaceModel cu TGI, ca la real-time)
predictor = model.deploy(
    instance_type="ml.g4dn.2xlarge",
    initial_instance_count=1,
    async_inference_config=async_config,
    endpoint_name="tinyllama-async",
)
