from sagemaker.huggingface import HuggingFaceModel, get_huggingface_llm_image_uri

ROLE_ARN = "<EXECUTION_ROLE_ARN>"  # local: ARN explicit, nu get_execution_role()

# Container TGI optimizat pentru LLM-uri
tgi_image = get_huggingface_llm_image_uri("huggingface", version="2.0.1")

model = HuggingFaceModel(
    role=ROLE_ARN,
    image_uri=tgi_image,
    env={
        "HF_MODEL_ID": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        "SM_NUM_GPUS": "1",
        "MAX_INPUT_LENGTH": "2048",
        "MAX_TOTAL_TOKENS": "4096",
    },
)

# deploy() creează Model + EndpointConfig + Endpoint (~5-10 min la primul deploy)
predictor = model.deploy(
    instance_type="ml.g4dn.2xlarge",
    initial_instance_count=1,
    endpoint_name="tinyllama-rt",
)
