# AWS Setup

## 1. Create IAM User

IAM → Users → Create user

- Name: `sagemaker-demo`
- Check "I want to create an IAM user"
- Next

Attach policies:
- `AmazonSageMakerFullAccess`
- `AmazonS3FullAccess`
- `CloudWatchLogsReadOnlyAccess`

Create user.

## 2. Create Access Key

Click on user → Security credentials → Create access key

- Select "Command Line Interface (CLI)"
- Check confirmation
- **Copy both keys now**

## 3. Create Execution Role

IAM → Roles → Create role

- Trusted entity: AWS service
- Use case: SageMaker
- Next → Next
- Role name: `SageMakerDemoRole`
- Create role

Click on role → Copy ARN

## 4. Configure Local

```bash
aws configure --profile sagemaker-demo
```

Paste keys. Region: `eu-central-1`

## 5. Setup .env

```bash
cp .env.example .env
```

Edit `.env`:
```
SAGEMAKER_ROLE_ARN=arn:aws:iam::123456789012:role/SageMakerDemoRole
AWS_PROFILE=sagemaker-demo
```

## 6. Check Quota

AWS Console → Service Quotas → SageMaker

Search: `ml.g4dn.2xlarge`

Need at least 1 for endpoint usage. If 0, request increase (24-48h).

## Done

```bash
python demo_sectiunea2.py
```
