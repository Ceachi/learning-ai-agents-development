"""
Demo Secțiunea 2 (partea 2) — Invoke + Cleanup pentru endpoint existent.

Presupune că ai rulat deja deploy-ul (demo_sectiunea2.py sau manual).
Util pentru demo live: pornești endpoint-ul înainte, apoi arăți doar invoke.

Flux: verifică endpoint → invoke cu boto3 → (opțional) cleanup
"""

import json
import os

import boto3
from dotenv import load_dotenv

load_dotenv()

# --- Config ---------------------------------------------------------------
REGION = os.getenv("AWS_REGION", "eu-central-1")
PROFILE = os.getenv("AWS_PROFILE")
ENDPOINT_NAME = os.getenv("ENDPOINT_NAME", "tinyllama-rt-demo")

boto_session = boto3.Session(region_name=REGION, profile_name=PROFILE)
sm = boto_session.client("sagemaker")
runtime = boto_session.client("sagemaker-runtime")


def check_endpoint():
    """Verifică dacă endpoint-ul există și e InService."""
    print(f"[check] verific endpoint {ENDPOINT_NAME}...")
    try:
        resp = sm.describe_endpoint(EndpointName=ENDPOINT_NAME)
        status = resp["EndpointStatus"]
        print(f"  status: {status}")
        if status != "InService":
            raise RuntimeError(f"Endpoint nu e InService, ci {status}")
        return True
    except sm.exceptions.ClientError as e:
        if "Could not find endpoint" in str(e):
            print("  endpoint nu există! Rulează întâi demo_sectiunea2.py")
            return False
        raise


def invoke(prompt: str):
    """Trimite un request la endpoint și afișează răspunsul."""
    print(f"\n[invoke] trimit: {prompt[:50]}...")
    resp = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=json.dumps({
            "inputs": prompt,
            "parameters": {"max_new_tokens": 128, "temperature": 0.7},
        }),
    )
    result = json.loads(resp["Body"].read())
    print(f"  răspuns: {result}")
    return result


def cleanup():
    """Șterge endpoint-ul pentru a opri costurile."""
    print(f"\n[cleanup] șterg endpoint {ENDPOINT_NAME}...")
    try:
        sm.delete_endpoint(EndpointName=ENDPOINT_NAME)
        print("  endpoint șters.")
    except Exception as e:
        print(f"  warn: {e}")

    # Șterge și config-ul asociat (are același nume by default)
    try:
        sm.delete_endpoint_config(EndpointConfigName=ENDPOINT_NAME)
        print("  config șters.")
    except Exception as e:
        print(f"  warn: {e}")

    print("  cleanup complet. Niciun cost rezidual.")


def main():
    if not check_endpoint():
        return

    # Demo: câteva invocări
    invoke("Explică pe scurt ce este machine learning:")
    invoke("Care e capitala României?")
    invoke("Scrie un haiku despre Python:")

    # Întreabă dacă vrei să închizi
    print("\n" + "=" * 50)
    answer = input("Vrei să închizi endpoint-ul? (y/n): ").strip().lower()
    if answer == "y":
        cleanup()
    else:
        print(f"OK, endpoint-ul rămâne pornit. Nu uita să-l închizi manual!")
        print(f"  aws sagemaker delete-endpoint --endpoint-name {ENDPOINT_NAME}")


if __name__ == "__main__":
    main()
