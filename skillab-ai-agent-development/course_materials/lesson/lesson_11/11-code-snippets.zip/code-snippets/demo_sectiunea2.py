"""
Demo Secțiunea 2 — Real-Time Inference cu HuggingFace pe SageMaker.

Flux: deploy model (distilgpt2 pe ml.g4dn.2xlarge) → invocare (Predictor + boto3)
      → autoscaling (opțional) → cleanup garantat.

Setup:
  1. Copiază .env.example → .env
  2. Completează SAGEMAKER_ROLE_ARN cu execution role-ul tău
  3. Rulează: python demo_sectiunea2.py

Cost: ml.g4dn.2xlarge ~$1/h cât e endpoint-ul pornit. Demo-ul face cleanup în
finally, deci nu rămân costuri chiar dacă pică ceva la mijloc.
"""

import json
import os

import boto3
import sagemaker
from dotenv import load_dotenv
from sagemaker.huggingface import HuggingFaceModel

load_dotenv()

# --- Config ---------------------------------------------------------------
REGION = os.getenv("AWS_REGION", "eu-central-1")
PROFILE = os.getenv("AWS_PROFILE")  # opțional
ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN")  # obligatoriu
ENDPOINT_NAME = "tinyllama-rt-demo"
INSTANCE_TYPE = os.getenv("INSTANCE_TYPE", "ml.g4dn.2xlarge")  # 1× T4 16GB
MODEL_ID = os.getenv("MODEL_ID", "distilgpt2")  # mic și rapid pentru demo
ENABLE_AUTOSCALING = os.getenv("ENABLE_AUTOSCALING", "false").lower() == "true"

boto_session = boto3.Session(region_name=REGION, profile_name=PROFILE)
sm_session = sagemaker.Session(boto_session=boto_session)


def deploy():
    # Standard HuggingFace container (not TGI)
    model = HuggingFaceModel(
        role=ROLE_ARN,
        transformers_version="4.37",
        pytorch_version="2.1",
        py_version="py310",
        env={
            "HF_MODEL_ID": MODEL_ID,
            "HF_TASK": "text-generation",
        },
        sagemaker_session=sm_session,
    )
    print(f"[deploy] pornesc endpoint {ENDPOINT_NAME} pe {INSTANCE_TYPE} (~5-10 min)...")
    predictor = model.deploy(
        instance_type=INSTANCE_TYPE,
        initial_instance_count=1,
        endpoint_name=ENDPOINT_NAME,
        container_startup_health_check_timeout=900,  # 15 min pentru download model
    )
    print("[deploy] gata, endpoint InService.")
    return predictor


def invoke_with_predictor(predictor):
    print("\n[invoke/predictor] interoghez prin SDK...")
    resp = predictor.predict({
        "inputs": "Explică pe scurt ce este machine learning:",
        "parameters": {"max_new_tokens": 128, "temperature": 0.7},
    })
    print("  răspuns:", resp)


def invoke_with_boto3():
    print("\n[invoke/boto3] interoghez prin sagemaker-runtime...")
    runtime = boto_session.client("sagemaker-runtime")
    resp = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        Body=json.dumps({
            "inputs": "Spune un fapt interesant despre Marte:",
            "parameters": {"max_new_tokens": 128},
        }),
    )
    print("  răspuns:", json.loads(resp["Body"].read()))


def setup_autoscaling():
    print("\n[autoscaling] înregistrez target + politică...")
    aas = boto_session.client("application-autoscaling")
    resource_id = f"endpoint/{ENDPOINT_NAME}/variant/AllTraffic"
    aas.register_scalable_target(
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        MinCapacity=1, MaxCapacity=2,   # quota g4dn.2xlarge = 2
    )
    aas.put_scaling_policy(
        PolicyName="invocations-scaling",
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        PolicyType="TargetTrackingScaling",
        TargetTrackingScalingPolicyConfiguration={
            "TargetValue": 100,
            "PredefinedMetricSpecification": {
                "PredefinedMetricType": "SageMakerVariantInvocationsPerInstance",
            },
            "ScaleInCooldown": 300, "ScaleOutCooldown": 60,
        },
    )
    print("  autoscaling configurat (Min=1, Max=2).")


def cleanup(predictor):
    print("\n[cleanup] șterg endpoint + config + model...")
    if predictor is not None:
        try:
            predictor.delete_endpoint()
            print("  endpoint șters.")
        except Exception as e:
            print(f"  warn (endpoint): {e}")
        try:
            predictor.delete_model()
            print("  model șters.")
        except Exception as e:
            print(f"  warn (model): {e}")
    else:
        # Fallback dacă predictor e None (deploy a picat)
        sm = boto_session.client("sagemaker")
        try:
            sm.delete_endpoint(EndpointName=ENDPOINT_NAME)
        except Exception as e:
            print(f"  warn: {e}")
    print("  cleanup complet. Niciun cost rezidual.")


def main():
    if not ROLE_ARN:
        raise ValueError("SAGEMAKER_ROLE_ARN lipsește din .env")

    predictor = None
    try:
        predictor = deploy()
        invoke_with_predictor(predictor)
        invoke_with_boto3()
        if ENABLE_AUTOSCALING:
            setup_autoscaling()
    except Exception as e:
        # Print failure reason before cleanup
        print(f"\n[ERROR] {e}")
        try:
            resp = boto_session.client("sagemaker").describe_endpoint(EndpointName=ENDPOINT_NAME)
            print(f"[DEBUG] Status: {resp.get('EndpointStatus')}")
            print(f"[DEBUG] Reason: {resp.get('FailureReason', 'N/A')}")
        except:
            pass
        raise
    finally:
        cleanup(predictor)


if __name__ == "__main__":
    main()
