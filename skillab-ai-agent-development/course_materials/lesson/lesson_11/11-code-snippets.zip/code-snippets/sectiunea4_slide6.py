import boto3

client = boto3.client("application-autoscaling", region_name="eu-central-1")
resource_id = "endpoint/tinyllama-async/variant/AllTraffic"

# 1. Înregistrăm endpoint-ul — MinCapacity=0 = SCALE TO ZERO
client.register_scalable_target(
    ServiceNamespace="sagemaker",
    ResourceId=resource_id,
    ScalableDimension="sagemaker:variant:DesiredInstanceCount",
    MinCapacity=0, MaxCapacity=2,   # quota g4dn.2xlarge endpoint usage = 2
)

# 2. Politica: scalează după lungimea cozii
client.put_scaling_policy(
    PolicyName="scale-to-zero-policy",
    ServiceNamespace="sagemaker",
    ResourceId=resource_id,
    ScalableDimension="sagemaker:variant:DesiredInstanceCount",
    PolicyType="TargetTrackingScaling",
    TargetTrackingScalingPolicyConfiguration={
        "TargetValue": 5,  # 5 requests în queue / instanță
        "CustomizedMetricSpecification": {
            "MetricName": "ApproximateBacklogSizePerInstance",
            "Namespace": "AWS/SageMaker",
        },
        "ScaleInCooldown": 600, "ScaleOutCooldown": 60,  # 10 min idle → scale down
    },
)
