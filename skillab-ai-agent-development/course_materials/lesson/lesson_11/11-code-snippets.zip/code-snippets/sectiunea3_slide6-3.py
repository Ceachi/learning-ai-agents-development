from sagemaker.huggingface import HuggingFaceModel

ROLE_ARN = "<EXECUTION_ROLE_ARN>"

model = HuggingFaceModel(
    role=ROLE_ARN,
    transformers_version="4.37", pytorch_version="2.1", py_version="py310",
    env={"HF_MODEL_ID": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
         "HF_TASK": "text-generation"},
)

transformer = model.transformer(
    instance_count=2,
    instance_type="ml.g4dn.2xlarge",
    output_path="s3://my-bucket/output/",

    # Spot configuration — economie ~70% vs on-demand
    use_spot_instances=True,
    max_retry_attempts=2,   # retry dacă e întrerupt
)

transformer.transform(
    data="s3://my-bucket/input/",
    content_type="application/json",
    wait=True,
)
