# IMPORTANT: ml.g4dn.2xlarge costă ~$1/h chiar dacă nu primește requests!

# Metoda 1 — cu Predictor (din deploy)
predictor.delete_endpoint()   # șterge endpoint + config
predictor.delete_model()

# Metoda 2 — cu boto3 (când nu mai ai obiectul predictor)
import boto3

sm = boto3.client("sagemaker", region_name="eu-central-1")

# Ordinea contează: endpoint → config → model
sm.delete_endpoint(EndpointName="tinyllama-rt")
sm.delete_endpoint_config(EndpointConfigName="tinyllama-rt")
sm.delete_model(ModelName="tinyllama-rt-model")
