

import json
import os
import time

import boto3
import sagemaker
from dotenv import load_dotenv
from sagemaker.async_inference import AsyncInferenceConfig
from sagemaker.huggingface import HuggingFaceModel

load_dotenv()

# --- Config ---------------------------------------------------------------
REGION = os.getenv("AWS_REGION", "eu-central-1")
PROFILE = os.getenv("AWS_PROFILE")
ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN")
ENDPOINT_NAME = "tinyllama-async-demo"
INSTANCE_TYPE = os.getenv("INSTANCE_TYPE", "ml.g4dn.2xlarge")
MODEL_ID = os.getenv("MODEL_ID", "distilgpt2")  # mic și rapid pentru demo
SUCCESS_TOPIC_ARN = os.getenv("SUCCESS_TOPIC_ARN", "")
ERROR_TOPIC_ARN = os.getenv("ERROR_TOPIC_ARN", "")
ENABLE_SCALE_TO_ZERO = os.getenv("ENABLE_SCALE_TO_ZERO", "false").lower() == "true"

boto_session = boto3.Session(region_name=REGION, profile_name=PROFILE)
sm_session = sagemaker.Session(boto_session=boto_session)
s3 = boto_session.client("s3")
sm = boto_session.client("sagemaker")

BUCKET = sm_session.default_bucket()
PREFIX = "lectia11-async-demo"


def deploy():
    # Standard HuggingFace container (same as section 2, not TGI)
    model = HuggingFaceModel(
        role=ROLE_ARN,
        transformers_version="4.37",
        pytorch_version="2.1",
        py_version="py310",
        env={
            "HF_MODEL_ID": MODEL_ID,
            "HF_TASK": "text-generation",
        },
        sagemaker_session=sm_session,
    )

    notification_config = None
    if SUCCESS_TOPIC_ARN or ERROR_TOPIC_ARN:
        notification_config = {}
        if SUCCESS_TOPIC_ARN:
            notification_config["SuccessTopic"] = SUCCESS_TOPIC_ARN
        if ERROR_TOPIC_ARN:
            notification_config["ErrorTopic"] = ERROR_TOPIC_ARN

    async_config = AsyncInferenceConfig(
        output_path=f"s3://{BUCKET}/{PREFIX}/output/",
        notification_config=notification_config,
        max_concurrent_invocations_per_instance=4,
    )

    print(f"[deploy] pornesc async endpoint {ENDPOINT_NAME} (~5-10 min)...")
    predictor = model.deploy(
        instance_type=INSTANCE_TYPE,
        initial_instance_count=1,
        async_inference_config=async_config,
        endpoint_name=ENDPOINT_NAME,
        container_startup_health_check_timeout=900,  # 15 min pentru download model
    )
    print("[deploy] gata, endpoint InService.")
    return predictor


def upload_input():
    key = f"{PREFIX}/input/req.json"
    body = json.dumps({
        "inputs": "Explică pe scurt ce este async inference în SageMaker:",
        "parameters": {"max_new_tokens": 128, "temperature": 0.7},
    })
    s3.put_object(Bucket=BUCKET, Key=key, Body=body.encode("utf-8"))
    input_loc = f"s3://{BUCKET}/{key}"
    print(f"[input] urcat: {input_loc}")
    return input_loc


def invoke_and_poll(input_loc):
    runtime = boto_session.client("sagemaker-runtime")
    print("[invoke] trimit request async (răspuns instant cu OutputLocation)...")
    response = runtime.invoke_endpoint_async(
        EndpointName=ENDPOINT_NAME,
        ContentType="application/json",
        InputLocation=input_loc,
    )
    output_loc = response["OutputLocation"]
    print(f"[invoke] OutputLocation: {output_loc}")

    bucket, key = output_loc.replace("s3://", "").split("/", 1)
    print("[poll] aștept rezultatul în S3...")
    for _ in range(60):  # max ~5 min
        try:
            obj = s3.get_object(Bucket=bucket, Key=key)
            print("[poll] gata. Răspuns:")
            print("  ", obj["Body"].read().decode("utf-8").strip()[:400])
            return
        except s3.exceptions.NoSuchKey:
            time.sleep(5)
    print("[poll] timeout — verifică și folderul de erori din async output.")


def setup_scale_to_zero():
    print("[scale-to-zero] înregistrez target MinCapacity=0...")
    aas = boto_session.client("application-autoscaling")
    resource_id = f"endpoint/{ENDPOINT_NAME}/variant/AllTraffic"
    aas.register_scalable_target(
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        MinCapacity=0, MaxCapacity=2,
    )
    aas.put_scaling_policy(
        PolicyName="scale-to-zero-policy",
        ServiceNamespace="sagemaker",
        ResourceId=resource_id,
        ScalableDimension="sagemaker:variant:DesiredInstanceCount",
        PolicyType="TargetTrackingScaling",
        TargetTrackingScalingPolicyConfiguration={
            "TargetValue": 5,
            "CustomizedMetricSpecification": {
                "MetricName": "ApproximateBacklogSizePerInstance",
                "Namespace": "AWS/SageMaker",
            },
            "ScaleInCooldown": 600, "ScaleOutCooldown": 60,
        },
    )
    print("[scale-to-zero] configurat (Min=0, Max=2).")


def cleanup():
    print("\n[cleanup] șterg endpoint + config + model + artefacte S3...")
    for fn, kwargs in [
        (sm.delete_endpoint, {"EndpointName": ENDPOINT_NAME}),
        (sm.delete_endpoint_config, {"EndpointConfigName": ENDPOINT_NAME}),
    ]:
        try:
            fn(**kwargs)
        except Exception as e:
            print(f"  warn: {e}")
    # ștergem și artefactele S3 ale demo-ului
    listing = s3.list_objects_v2(Bucket=BUCKET, Prefix=PREFIX)
    keys = [{"Key": o["Key"]} for o in listing.get("Contents", [])]
    if keys:
        s3.delete_objects(Bucket=BUCKET, Delete={"Objects": keys})
    print("  cleanup complet. Niciun cost rezidual.")


def main():
    if not ROLE_ARN:
        raise ValueError("SAGEMAKER_ROLE_ARN lipsește din .env")

    try:
        deploy()
        if ENABLE_SCALE_TO_ZERO:
            setup_scale_to_zero()
        input_loc = upload_input()
        invoke_and_poll(input_loc)
    finally:
        cleanup()


if __name__ == "__main__":
    main()
