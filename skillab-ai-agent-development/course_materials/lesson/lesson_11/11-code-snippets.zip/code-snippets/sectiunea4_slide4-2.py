import boto3, time

runtime = boto3.client("sagemaker-runtime", region_name="eu-central-1")
s3 = boto3.client("s3", region_name="eu-central-1")

# 1. Trimite — returnează imediat
response = runtime.invoke_endpoint_async(
    EndpointName="tinyllama-async",
    ContentType="application/json",
    InputLocation="s3://my-bucket/async-input/req.json",
)
output_loc = response["OutputLocation"]

# 2. Polling S3 pentru rezultat
bucket, key = output_loc.replace("s3://", "").split("/", 1)
while True:
    try:
        result = s3.get_object(Bucket=bucket, Key=key)
        break
    except s3.exceptions.NoSuchKey:
        time.sleep(5)
