

import json
import os
import time

import boto3
import sagemaker
from dotenv import load_dotenv
from sagemaker.huggingface import HuggingFaceModel

load_dotenv()

# --- Config ---------------------------------------------------------------
REGION = os.getenv("AWS_REGION", "eu-central-1")
PROFILE = os.getenv("AWS_PROFILE")
ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN")
MODEL_ID = os.getenv("MODEL_ID", "TinyLlama/TinyLlama-1.1B-Chat-v1.0")
INSTANCE_TYPE = os.getenv("INSTANCE_TYPE", "ml.g4dn.2xlarge")
USE_SPOT = os.getenv("USE_SPOT", "false").lower() == "true"
CLEANUP_S3 = True

boto_session = boto3.Session(region_name=REGION, profile_name=PROFILE)
sm_session = sagemaker.Session(boto_session=boto_session)
s3 = boto_session.client("s3")
sm = boto_session.client("sagemaker")

BUCKET = sm_session.default_bucket()        # bucket-ul default SageMaker
PREFIX = "lectia11-batch-demo"
INPUT_PREFIX = f"{PREFIX}/input"
OUTPUT_PREFIX = f"{PREFIX}/output"

# Câteva prompturi — fiecare devine un fișier = un request (SingleRecord)
PROMPTS = [
    "Explică pe scurt ce este machine learning:",
    "Spune un fapt interesant despre Marte:",
    "Scrie un haiku despre programare:",
]


def upload_inputs():
    print(f"[input] urc {len(PROMPTS)} fișiere în s3://{BUCKET}/{INPUT_PREFIX}/")
    for i, prompt in enumerate(PROMPTS, start=1):
        body = json.dumps({
            "inputs": prompt,
            "parameters": {"max_new_tokens": 128, "temperature": 0.7},
        })
        s3.put_object(
            Bucket=BUCKET,
            Key=f"{INPUT_PREFIX}/request_{i:03d}.json",
            Body=body.encode("utf-8"),
        )
    print("[input] gata.")


def run_batch():
    model = HuggingFaceModel(
        role=ROLE_ARN,
        transformers_version="4.37",
        pytorch_version="2.1",
        py_version="py310",
        env={"HF_MODEL_ID": MODEL_ID, "HF_TASK": "text-generation"},
        sagemaker_session=sm_session,
    )

    transformer_kwargs = dict(
        instance_count=1,
        instance_type=INSTANCE_TYPE,
        output_path=f"s3://{BUCKET}/{OUTPUT_PREFIX}/",
        strategy="SingleRecord",        # un fișier = un request
        max_payload=6,
        max_concurrent_transforms=4,
        accept="application/json",
    )
    if USE_SPOT:
        transformer_kwargs.update(use_spot_instances=True, max_retry_attempts=2)

    transformer = model.transformer(**transformer_kwargs)

    print(f"[batch] pornesc transform job pe {INSTANCE_TYPE} (download model + procesare)...")
    transformer.transform(
        data=f"s3://{BUCKET}/{INPUT_PREFIX}/",
        content_type="application/json",
        wait=False,                     # async: pornim și monitorizăm manual
    )
    return transformer


def monitor(transformer):
    job_name = transformer.latest_transform_job.name
    print(f"[monitor] job: {job_name}")
    while True:
        resp = sm.describe_transform_job(TransformJobName=job_name)
        status = resp["TransformJobStatus"]
        print(f"  status: {status}")
        if status in ("Completed", "Failed", "Stopped"):
            if status == "Failed":
                print("  motiv:", resp.get("FailureReason", "necunoscut"))
            return status
        time.sleep(30)


def download_outputs():
    print(f"[output] descarc rezultatele din s3://{BUCKET}/{OUTPUT_PREFIX}/")
    listing = s3.list_objects_v2(Bucket=BUCKET, Prefix=OUTPUT_PREFIX)
    for obj in listing.get("Contents", []):
        key = obj["Key"]
        body = s3.get_object(Bucket=BUCKET, Key=key)["Body"].read()
        print(f"\n  --- {key.split('/')[-1]} ---")
        print("  ", body.decode("utf-8").strip()[:300])


def cleanup_s3():
    print("\n[cleanup] șterg artefactele S3 ale demo-ului...")
    for prefix in (INPUT_PREFIX, OUTPUT_PREFIX):
        listing = s3.list_objects_v2(Bucket=BUCKET, Prefix=prefix)
        keys = [{"Key": o["Key"]} for o in listing.get("Contents", [])]
        if keys:
            s3.delete_objects(Bucket=BUCKET, Delete={"Objects": keys})
    print("  S3 curat. (Instanțele batch s-au oprit deja singure.)")


def main():
    if not ROLE_ARN:
        raise ValueError("SAGEMAKER_ROLE_ARN lipsește din .env")

    try:
        upload_inputs()
        transformer = run_batch()
        status = monitor(transformer)
        if status == "Completed":
            download_outputs()
    finally:
        if CLEANUP_S3:
            cleanup_s3()


if __name__ == "__main__":
    main()
