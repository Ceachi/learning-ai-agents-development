import boto3

sm = boto3.client("sagemaker", region_name="eu-central-1")

# Verificăm status-ul job-ului
job_name = transformer.latest_transform_job.name
response = sm.describe_transform_job(TransformJobName=job_name)
status = response["TransformJobStatus"]
# InProgress | Completed | Failed | Stopping | Stopped

# Sau așteaptă blocant până se termină
transformer.wait()

# După finalizare, descărcăm un rezultat
s3 = boto3.client("s3", region_name="eu-central-1")
s3.download_file(
    "my-bucket",
    "batch-output/request_001.json.out",
    "local_result.json",
)
