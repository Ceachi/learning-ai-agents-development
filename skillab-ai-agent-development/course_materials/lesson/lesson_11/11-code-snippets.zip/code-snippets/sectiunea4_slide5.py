import json

# Lambda handler pentru SNS notifications de la async endpoint
def lambda_handler(event, context):
    for record in event["Records"]:
        msg = json.loads(record["Sns"]["Message"])
        if msg["invocationStatus"] == "Completed":
            process_result(msg["responseParameters"]["outputLocation"])
        else:
            handle_error(msg["failureReason"])
