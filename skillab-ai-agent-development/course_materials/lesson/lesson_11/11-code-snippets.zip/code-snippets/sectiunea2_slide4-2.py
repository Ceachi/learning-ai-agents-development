# METODA 1 — Predictor (SDK), simplu pentru notebook-uri
response = predictor.predict({
    "inputs": "Explică pe scurt ce este machine learning:",
    "parameters": {"max_new_tokens": 256, "temperature": 0.7},
})
print(response)  # dict deja parsed

# METODA 2 — boto3, portabil (Lambda, ECS, oriunde)
import boto3, json

runtime = boto3.client("sagemaker-runtime", region_name="eu-central-1")
response = runtime.invoke_endpoint(
    EndpointName="tinyllama-rt",
    ContentType="application/json",
    Body=json.dumps({"inputs": "Explică ML:"}),
)
result = json.loads(response["Body"].read())  # parsing manual
print(result)
