# CONFIG vLLM
import sagemaker
from sagemaker.huggingface import HuggingFaceModel, get_huggingface_llm_image_uri

ROLE_ARN = "<EXECUTION_ROLE_ARN>"

# Notă: backend-urile reale azi sunt "huggingface" (TGI) și "lmi".
# vLLM se rulează în practică prin containerul LMI (engine=vLLM).
vllm_image_uri = get_huggingface_llm_image_uri("lmi")

model = HuggingFaceModel(
    role=ROLE_ARN,
    image_uri=vllm_image_uri,
    env={
        "HF_MODEL_ID": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        "OPTION_MAX_MODEL_LEN": "4096",
        "OPTION_DTYPE": "bf16",
        "OPTION_TENSOR_PARALLEL_DEGREE": "1",
    },
)
predictor = model.deploy(
    instance_type="ml.g4dn.2xlarge", initial_instance_count=1,
)

# INVOCARE — format OpenAI ChatCompletion
response = predictor.predict({
    "messages": [{"role": "user", "content": "Hello!"}],
    "max_tokens": 256,
    "temperature": 0.7,
})
print(response)  # {choices: [{message: ...}]} — la fel ca OpenAI
