import sagemaker
from sagemaker.huggingface import HuggingFaceModel, get_huggingface_llm_image_uri

ROLE_ARN = "<EXECUTION_ROLE_ARN>"

# 1. URI container TGI optimizat
tgi_image_uri = get_huggingface_llm_image_uri("huggingface", version="2.0.1")

# 2. Model cu env vars TGI
model = HuggingFaceModel(
    role=ROLE_ARN,
    image_uri=tgi_image_uri,
    env={
        "HF_MODEL_ID": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
        "SM_NUM_GPUS": "1",
        # Optimizări TGI:
        "MAX_INPUT_LENGTH": "2048",
        "MAX_TOTAL_TOKENS": "4096",
        "MAX_BATCH_TOTAL_TOKENS": "8192",
    },
)

predictor = model.deploy(
    instance_type="ml.g4dn.2xlarge", initial_instance_count=1,
)
