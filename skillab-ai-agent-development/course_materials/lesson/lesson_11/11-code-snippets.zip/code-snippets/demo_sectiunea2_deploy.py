"""
Demo Secțiunea 2 (partea 1) — Doar deploy, fără invoke sau cleanup.

Rulează ÎNAINTE de lecție (~5-10 min). Endpoint-ul rămâne pornit.
În timpul lecției folosești demo_sectiunea2_invoke.py pentru invoke + cleanup.
"""

import os

import boto3
import sagemaker
from dotenv import load_dotenv
from sagemaker.huggingface import HuggingFaceModel

load_dotenv()

# --- Config ---------------------------------------------------------------
REGION = os.getenv("AWS_REGION", "eu-central-1")
PROFILE = os.getenv("AWS_PROFILE")
ROLE_ARN = os.getenv("SAGEMAKER_ROLE_ARN")
ENDPOINT_NAME = os.getenv("ENDPOINT_NAME", "tinyllama-rt-demo")
INSTANCE_TYPE = os.getenv("INSTANCE_TYPE", "ml.g4dn.2xlarge")
MODEL_ID = os.getenv("MODEL_ID", "distilgpt2")

boto_session = boto3.Session(region_name=REGION, profile_name=PROFILE)
sm_session = sagemaker.Session(boto_session=boto_session)


def deploy():
    model = HuggingFaceModel(
        role=ROLE_ARN,
        transformers_version="4.37",
        pytorch_version="2.1",
        py_version="py310",
        env={
            "HF_MODEL_ID": MODEL_ID,
            "HF_TASK": "text-generation",
        },
        sagemaker_session=sm_session,
    )

    print(f"[deploy] pornesc endpoint {ENDPOINT_NAME} pe {INSTANCE_TYPE}...")
    print("  (durează ~5-10 min, poți închide terminalul)")

    model.deploy(
        instance_type=INSTANCE_TYPE,
        initial_instance_count=1,
        endpoint_name=ENDPOINT_NAME,
        container_startup_health_check_timeout=900,
        wait=True,  # așteaptă până e InService
    )

    print("\n[deploy] GATA! Endpoint InService.")
    print(f"  Endpoint: {ENDPOINT_NAME}")
    print(f"  Folosește demo_sectiunea2_invoke.py pentru invoke + cleanup.")


def main():
    if not ROLE_ARN:
        raise ValueError("SAGEMAKER_ROLE_ARN lipsește din .env")
    deploy()


if __name__ == "__main__":
    main()
