import boto3

client = boto3.client("application-autoscaling", region_name="eu-central-1")
resource_id = "endpoint/tinyllama-rt/variant/AllTraffic"

# 1. Limite Min/Max instanțe
client.register_scalable_target(
    ServiceNamespace="sagemaker",
    ResourceId=resource_id,
    ScalableDimension="sagemaker:variant:DesiredInstanceCount",
    MinCapacity=1, MaxCapacity=3,  # quota g4dn.2xlarge = 2, rămâi prudent
)

# 2. Politica: scalează după invocări/instanță/minut
client.put_scaling_policy(
    PolicyName="invocations-scaling",
    ServiceNamespace="sagemaker",
    ResourceId=resource_id,
    ScalableDimension="sagemaker:variant:DesiredInstanceCount",
    PolicyType="TargetTrackingScaling",
    TargetTrackingScalingPolicyConfiguration={
        "TargetValue": 100,  # 100 invocări/instanță/minut
        "PredefinedMetricSpecification": {
            "PredefinedMetricType": "SageMakerVariantInvocationsPerInstance",
        },
        "ScaleInCooldown": 300, "ScaleOutCooldown": 60,
    },
)
