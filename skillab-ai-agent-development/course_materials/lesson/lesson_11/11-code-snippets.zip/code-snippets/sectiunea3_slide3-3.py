from sagemaker.huggingface import HuggingFaceModel

ROLE_ARN = "<EXECUTION_ROLE_ARN>"  # local: ARN explicit, nu get_execution_role()

# Pasul 1 — definim modelul (FĂRĂ deploy!)
model = HuggingFaceModel(
    role=ROLE_ARN,
    transformers_version="4.37",
    pytorch_version="2.1",
    py_version="py310",
    env={"HF_MODEL_ID": "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
         "HF_TASK": "text-generation"},
)

# Pasul 2 — configurăm transformer-ul
transformer = model.transformer(
    instance_count=1, instance_type="ml.g4dn.2xlarge",
    output_path="s3://my-bucket/batch-output/",
    strategy="SingleRecord",          # un fișier = un request
    max_payload=6, max_concurrent_transforms=4,
    accept="application/json",
)

# Pasul 3 — start job (async, nu blochează)
transformer.transform(
    data="s3://my-bucket/batch-input/",
    content_type="application/json", wait=False,
)
