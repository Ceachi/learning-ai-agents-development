"""
Demo 5: RAG pe Date Numerice - Metrici Medicale
===============================================
Arată cum să faci similarity search pe date numerice cu Repository Pattern.

CONCEPTE demonstrate:
1. Vectori SEPARAȚI pe grupuri semantice (cardio, metabolic, demografic)
2. Fiecare grup e o coloană Vector în PostgreSQL
3. Similarity search pe UN grup sau COMPUS cu weights
4. Repository pattern pentru toate operațiile

Setup:
  docker compose up -d
  pip install -r requirements.txt

Rulare: python 05_rag_numeric_medical.py
"""

from sqlalchemy import text

from database import engine, Base, transaction
from models_medical import Patient
from repositories_medical import PatientRepository, PatientInput, SimilarityWeights, SearchResult


# =============================================================================
# DATE DEMO - Pacienți cu diagnostice
# =============================================================================

PATIENTS_DATA = [
    PatientInput(
        external_id="P001",
        tensiune_sys=135, tensiune_dia=85, puls=78,
        glucoza=95, colesterol=190, trigliceride=120,
        varsta=45, bmi=24,
        diagnostic="Valori în limite normale. Stil de viață sănătos, control anual.",
    ),
    PatientInput(
        external_id="P002",
        tensiune_sys=165, tensiune_dia=100, puls=88,
        glucoza=110, colesterol=245, trigliceride=180,
        varsta=58, bmi=29,
        diagnostic="Hipertensiune stadiul 1, dislipidemie. Recomand dietă, exerciții, revisit 3 luni.",
    ),
    PatientInput(
        external_id="P003",
        tensiune_sys=180, tensiune_dia=110, puls=95,
        glucoza=250, colesterol=290, trigliceride=350,
        varsta=62, bmi=32,
        diagnostic="Hipertensiune stadiul 2, diabet tip 2, sindrom metabolic. Tratament medicamentos URGENT.",
    ), # 

    
    PatientInput(
        external_id="P004",
        tensiune_sys=120, tensiune_dia=75, puls=65,
        glucoza=88, colesterol=170, trigliceride=90,
        varsta=32, bmi=22,
        diagnostic="Excelent! Valori optime. Continuă stilul de viață actual.",
    ),
    PatientInput(
        external_id="P005",
        tensiune_sys=145, tensiune_dia=92, puls=82,
        glucoza=180, colesterol=220, trigliceride=200,
        varsta=55, bmi=27,
        diagnostic="Prediabet, hipertensiune ușoară. Intervenție stil de viață, monitorizare glucoză.",
    ),
    PatientInput(
        external_id="P006",
        tensiune_sys=125, tensiune_dia=80, puls=70,
        glucoza=310, colesterol=195, trigliceride=160,
        varsta=48, bmi=26,
        diagnostic="Diabet tip 2 confirmat (glucoză ridicată), tensiune OK. Focus pe controlul glicemic.",
    ),
]


def setup_database() -> None:
    """Creează extensia pgvector și tabelele."""
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    print("✓ Database setup complet")


def print_search_results(results: list[SearchResult], title: str) -> None:
    """Afișează rezultatele într-un format frumos."""
    print(f"\n{title}")
    print("-" * 80)
    for i, r in enumerate(results, 1):
        print(f"  {i}. [{r.score_total:.4f}] {r.patient.external_id}")
        print(f"     Scores: cardio={r.score_cardio:.3f}, metabolic={r.score_metabolic:.3f}, demo={r.score_demografic:.3f}")
        print(f"     {r.patient.metrics_display}")
        print(f"     Diagnostic: {r.patient.diagnostic[:70]}...")


def demo_comparatie_robustete(repo: PatientRepository):
    """Demo: Comparație vector unic vs grupat pentru robustețe."""
    print(f"\n{'='*80}")
    print("🔬 COMPARAȚIE: VECTOR UNIC vs VECTORI GRUPAȚI")
    print(f"{'='*80}")

    # Pacient cu CARDIO ridicat dar METABOLIC normal
    query = {
        "tensiune_sys": 170, "tensiune_dia": 105, "puls": 92,  # CARDIO ridicat!
        "glucoza": 90, "colesterol": 175, "trigliceride": 100,  # METABOLIC normal
        "varsta": 50, "bmi": 25,
    }

    print(f"\nQuery: Pacient cu CARDIO ridicat, METABOLIC normal")
    print(f"  Cardio: T={query['tensiune_sys']}/{query['tensiune_dia']}, P={query['puls']} ← RIDICAT")
    print(f"  Metabolic: G={query['glucoza']}, C={query['colesterol']}, Tg={query['trigliceride']} ← normal")
    print(f"  Demo: {query['varsta']} ani, BMI={query['bmi']}")
    print(f"\n  → Vrem să găsim pacienți cu CARDIO similar (hipertensivi)")

    # === VECTOR UNIC ===
    print(f"\n{'─'*40}")
    print("❌ VECTOR UNIC (8 dim, pondere egală)")
    print("   Problema: diferențele în metabolic pot 'îneca' similaritatea cardio")

    results_single = repo.search_single_vector(**query, top_k=3)

    for i, (p, score) in enumerate(results_single, 1):
        print(f"  {i}. [{score:.4f}] {p.external_id}: T={p.tensiune_sys:.0f}/{p.tensiune_dia:.0f}, G={p.glucoza:.0f}")

    # === VECTORI GRUPAȚI + COMPOSITE ===
    print(f"\n{'─'*40}")
    print("✅ VECTORI GRUPAȚI + search_composite(cardio=0.7)")
    print("   Avantaj: controlezi importanța fiecărui grup!")

    weights = SimilarityWeights.cardio_focus()  # cardio=0.7, metabolic=0.2, demo=0.1
    results_composite = repo.search_composite(**query, weights=weights, top_k=3)

    for i, r in enumerate(results_composite, 1):
        print(f"  {i}. [{r.score_total:.4f}] {r.patient.external_id}: "
              f"T={r.patient.tensiune_sys:.0f}/{r.patient.tensiune_dia:.0f}, G={r.patient.glucoza:.0f}")
        print(f"       breakdown: cardio={r.score_cardio:.3f}, metabolic={r.score_metabolic:.3f}")

    print(f"\n{'─'*40}")
    print("📊 CONCLUZIE:")
    print("   • Vector unic: rezultate imprevizibile când grupurile au valori diferite")
    print("   • Vectori grupați: poți ajusta weights pentru robustețe")
    print("   • Transparență: vezi exact CÂT contribuie fiecare grup la scor")


def demo_search_by_single_group(repo: PatientRepository):
    """Demo: Similarity search pe UN SINGUR grup."""
    print(f"\n{'='*80}")
    print("🔍 SEARCH PE UN SINGUR GRUP (opțional)")
    print(f"{'='*80}")

    # Pacient query cu tensiune ridicată
    print("\nQuery: Pacient cu tensiune ridicată (165/100, puls 88)")

    print("\n--- Search DOAR pe CARDIO ---")
    results = repo.search_by_cardio(
        tensiune_sys=165, tensiune_dia=100, puls=88,
        top_k=3
    )
    for i, (p, score) in enumerate(results, 1):
        print(f"  {i}. [{score:.4f}] {p.external_id}: T={p.tensiune_sys}/{p.tensiune_dia}, P={p.puls}")

    print("\n--- Search DOAR pe METABOLIC (glucoză=200, colesterol=250) ---")
    results = repo.search_by_metabolic(
        glucoza=200, colesterol=250, trigliceride=250,
        top_k=3
    )
    for i, (p, score) in enumerate(results, 1):
        print(f"  {i}. [{score:.4f}] {p.external_id}: G={p.glucoza}, C={p.colesterol}, Tg={p.trigliceride}")

    print("\n--- Search DOAR pe DEMOGRAFIC (55 ani, BMI 28) ---")
    results = repo.search_by_demografic(
        varsta=55, bmi=28,
        top_k=3
    )
    for i, (p, score) in enumerate(results, 1):
        print(f"  {i}. [{score:.4f}] {p.external_id}: {p.varsta:.0f} ani, BMI={p.bmi:.1f}")


def demo_search_composite_weights(repo: PatientRepository):
    """Demo: Similarity search COMPUS cu weights diferite."""
    print(f"\n{'='*80}")
    print("⚖️  SEARCH COMPUS CU WEIGHTS DIFERITE")
    print(f"{'='*80}")

    # Același pacient query
    query = {
        "tensiune_sys": 160, "tensiune_dia": 98, "puls": 85,
        "glucoza": 95, "colesterol": 185, "trigliceride": 130,
        "varsta": 56, "bmi": 27,
    }

    print(f"\nQuery pacient:")
    print(f"  Cardio: T={query['tensiune_sys']}/{query['tensiune_dia']}, P={query['puls']}")
    print(f"  Metabolic: G={query['glucoza']}, C={query['colesterol']}, Tg={query['trigliceride']}")
    print(f"  Demo: {query['varsta']} ani, BMI={query['bmi']}")
    print("\n  → CARDIO ridicat, METABOLIC normal")

    # Test cu CARDIO focus
    print("\n--- Weights: CARDIO=0.7, metabolic=0.2, demo=0.1 ---")
    weights_cardio = SimilarityWeights.cardio_focus()
    results = repo.search_composite(**query, weights=weights_cardio, top_k=3)
    print_search_results(results, "Focus pe CARDIO - găsește hipertensivi:")

    # Test cu METABOLIC focus
    print("\n--- Weights: cardio=0.2, METABOLIC=0.7, demo=0.1 ---")
    weights_metabolic = SimilarityWeights.metabolic_focus()
    results = repo.search_composite(**query, weights=weights_metabolic, top_k=3)
    print_search_results(results, "Focus pe METABOLIC - găsește metabolic sănătoși:")

    # Test BALANCED
    print("\n--- Weights: cardio=0.4, metabolic=0.4, demo=0.2 (BALANCED) ---")
    weights_balanced = SimilarityWeights.balanced()
    results = repo.search_composite(**query, weights=weights_balanced, top_k=3)
    print_search_results(results, "BALANCED - compromis între ambele:")


def demo_rag_complet(repo: PatientRepository):
    """Demo: RAG complet - search → retrieve diagnostics → context pentru LLM."""
    print(f"\n{'='*80}")
    print("🏥 RAG COMPLET: Search → Retrieve Diagnostics → LLM")
    print(f"{'='*80}")

    # Pacient nou pentru diagnostic
    query = {
        "tensiune_sys": 155, "tensiune_dia": 95, "puls": 85,
        "glucoza": 195, "colesterol": 235, "trigliceride": 210,
        "varsta": 54, "bmi": 28,
    }

    print(f"\nPacient nou pentru diagnostic:")
    print(f"  Cardio: T={query['tensiune_sys']}/{query['tensiune_dia']}, P={query['puls']}")
    print(f"  Metabolic: G={query['glucoza']}, C={query['colesterol']}, Tg={query['trigliceride']}")
    print(f"  Demo: {query['varsta']} ani, BMI={query['bmi']}")

    # Search cu weights balanced
    print(f"\n[1] RETRIEVE - Search cu weights balanced...")
    weights = SimilarityWeights.balanced()
    results = repo.search_composite(**query, weights=weights, top_k=3)

    # Build context
    context_parts = []
    for r in results:
        context_parts.append(
            f"Pacient similar (similaritate {r.score_total:.2f}):\n"
            f"  Metrici: T={r.patient.tensiune_sys}/{r.patient.tensiune_dia}, "
            f"G={r.patient.glucoza}, C={r.patient.colesterol}, "
            f"vârstă={r.patient.varsta:.0f}, BMI={r.patient.bmi:.1f}\n"
            f"  Breakdown: cardio={r.score_cardio:.2f}, metabolic={r.score_metabolic:.2f}, demo={r.score_demografic:.2f}\n"
            f"  Diagnostic: {r.patient.diagnostic}"
        )
        print(f"    [{r.score_total:.4f}] {r.patient.external_id}")

    context = "\n\n".join(context_parts)

    print(f"\n[2] CONTEXT pentru LLM:")
    print("-" * 40)
    print(context)
    print("-" * 40)

    # Prompt pentru LLM
    prompt = f"""Ești un medic. Analizează pacientul nou și oferă diagnostic.

PACIENT NOU:
- Tensiune: {query['tensiune_sys']}/{query['tensiune_dia']} mmHg
- Puls: {query['puls']} bpm
- Glucoză: {query['glucoza']} mg/dL
- Colesterol: {query['colesterol']} mg/dL
- Trigliceride: {query['trigliceride']} mg/dL
- Vârstă: {query['varsta']} ani
- BMI: {query['bmi']}

CAZURI SIMILARE DIN BAZA DE DATE:
{context}

Bazat pe pattern-urile din cazurile similare:
1. Oferă diagnostic pentru pacientul nou
2. Recomandă tratament sau stil de viață
3. Indică urgența (rutină / urgent / foarte urgent)

Răspunde în română, concis și profesionist."""

    print(f"\n[3] PROMPT pentru LLM (ar fi trimis la Ollama):")
    print("=" * 40)
    print(prompt[:700] + "...")


def main():
    print("=" * 80)
    print("DEMO: RAG Numeric Medical cu Repository Pattern")
    print("=" * 80)

    # Setup
    setup_database()

    # Populare cu pacienți
    print("\nPopulare bază de date...")
    with transaction() as db:
        repo = PatientRepository(db)
        patients = repo.create_batch(PATIENTS_DATA)
        print(f"✓ {len(patients)} pacienți inserați")

        for p in patients:
            print(f"  [{p.external_id}] {p.metrics_display}")

    # Demo-uri (tranzacții separate pentru read)
    with transaction() as db:
        repo = PatientRepository(db)
        demo_comparatie_robustete(repo)     # Vector unic vs grupat
        demo_search_by_single_group(repo)   # Search pe un singur grup (opțional)
        demo_search_composite_weights(repo) # Weights diferite
        demo_rag_complet(repo)

    # Sumar
    print(f"\n{'='*80}")
    print("SUMAR - CE AM DEMONSTRAT:")
    print(f"{'='*80}")
    print("""
    DE CE VECTORI GRUPAȚI?
    ┌─────────────────────────────────────────────────────────────┐
    │  ❌ embedding_all (8 dim) - vector unic                     │
    │     • Toate metricile au pondere EGALĂ în cosine similarity │
    │     • Diferențe mari în metabolic "înecă" similaritatea     │
    │       din cardio → rezultate imprevizibile                  │
    └─────────────────────────────────────────────────────────────┘
    vs
    ┌─────────────────────────────────────────────────────────────┐
    │  ✅ Vectori SEPARAȚI + search_composite()                   │
    │  ├── embedding_cardio     Vector(3)                        │
    │  ├── embedding_metabolic  Vector(3)                        │
    │  └── embedding_demografic Vector(2)                        │
    │                                                             │
    │  AVANTAJE:                                                  │
    │  • Controlezi importanța fiecărui grup (weights)           │
    │  • Transparență: vezi breakdown-ul scorurilor              │
    │  • Robustețe: ajustezi pentru use-case specific            │
    └─────────────────────────────────────────────────────────────┘

    WEIGHTS PRESETS:
    - SimilarityWeights.cardio_focus()    → cardio=0.7, metabolic=0.2
    - SimilarityWeights.metabolic_focus() → cardio=0.2, metabolic=0.7
    - SimilarityWeights.balanced()        → cardio=0.4, metabolic=0.4

    RAG FLOW:
    Query numeric → search_composite(weights) → retrieve diagnostics → LLM
    """)


if __name__ == "__main__":
    main()
