"""
Models pentru RAG Numeric Medical.

Demonstrează:
- Vectori SEPARAȚI pe grupuri semantice (cardio, metabolic, demografic)
- Fiecare grup e o coloană Vector separată în PostgreSQL
- Permite similarity search pe grupuri individuale sau compus
"""

from sqlalchemy import Column, Integer, Float, String, Text, DateTime, func
from pgvector.sqlalchemy import Vector

from database import Base


# =============================================================================
# CONSTANTE - Range-uri pentru normalizare
# =============================================================================

# Grup CARDIOVASCULAR
TENSIUNE_SYS_RANGE = (90, 200)    # mmHg
TENSIUNE_DIA_RANGE = (60, 120)    # mmHg
PULS_RANGE = (50, 120)            # bpm

# Grup METABOLIC
GLUCOZA_RANGE = (70, 400)         # mg/dL
COLESTEROL_RANGE = (100, 350)     # mg/dL
TRIGLICERIDE_RANGE = (50, 500)    # mg/dL

# Grup DEMOGRAFIC
VARSTA_RANGE = (18, 90)           # ani
BMI_RANGE = (15, 45)              # kg/m²

# Dimensiuni vectori
DIM_CARDIO = 3       # tensiune_sys, tensiune_dia, puls
DIM_METABOLIC = 3    # glucoza, colesterol, trigliceride
DIM_DEMOGRAFIC = 2   # varsta, bmi
DIM_ALL = 8          # toate metricile într-un singur vector (pentru demo problema)


# =============================================================================
# MODEL PACIENT
# =============================================================================

class Patient(Base):
    """
    Pacient cu metrici medicale stocate ca vectori separați pe grupuri.

    Fiecare grup semantic are propria coloană Vector:
    - embedding_cardio: metrici cardiovasculare normalizate
    - embedding_metabolic: metrici metabolice normalizate
    - embedding_demografic: date demografice normalizate

    Acest design permite:
    1. Similarity search pe UN SINGUR grup (ex: doar cardio)
    2. Similarity search COMPUS cu weights diferite
    3. Normalizare independentă per grup
    """
    __tablename__ = "patients"

    id = Column(Integer, primary_key=True, autoincrement=True)
    external_id = Column(String(50), unique=True, nullable=False)  # P001, P002, etc.

    # Valori RAW (pentru afișare/debugging)
    tensiune_sys = Column(Float, nullable=False)
    tensiune_dia = Column(Float, nullable=False)
    puls = Column(Float, nullable=False)
    glucoza = Column(Float, nullable=False)
    colesterol = Column(Float, nullable=False)
    trigliceride = Column(Float, nullable=False)
    varsta = Column(Float, nullable=False)
    bmi = Column(Float, nullable=False)

    # Diagnostic (textul pe care îl retrieve-uim în RAG)
    diagnostic = Column(Text, nullable=False)

    # Vectori SEPARAȚI pe grupuri (normalizați în [0, 1])
    embedding_cardio = Column(Vector(DIM_CARDIO), nullable=False)
    embedding_metabolic = Column(Vector(DIM_METABOLIC), nullable=False)
    embedding_demografic = Column(Vector(DIM_DEMOGRAFIC), nullable=False)

    # Vector UNIC cu toate metricile (pentru a demonstra problema!)
    embedding_all = Column(Vector(DIM_ALL), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self) -> str:
        return (
            f"<Patient {self.external_id}: "
            f"T={self.tensiune_sys}/{self.tensiune_dia}, "
            f"G={self.glucoza}, C={self.colesterol}>"
        )

    @property
    def metrics_display(self) -> str:
        """Format frumos pentru afișare."""
        return (
            f"Cardio: T={self.tensiune_sys:.0f}/{self.tensiune_dia:.0f}, P={self.puls:.0f} | "
            f"Metabolic: G={self.glucoza:.0f}, C={self.colesterol:.0f}, Tg={self.trigliceride:.0f} | "
            f"Demo: {self.varsta:.0f}ani, BMI={self.bmi:.1f}"
        )


# =============================================================================
# HELPER: Normalizare
# =============================================================================

def normalize_value(value: float, min_val: float, max_val: float) -> float:
    """Normalizează o valoare în intervalul [0, 1]."""
    return (value - min_val) / (max_val - min_val)


def create_cardio_vector(tensiune_sys: float, tensiune_dia: float, puls: float) -> list[float]:
    """Creează vector cardiovascular normalizat."""
    return [
        normalize_value(tensiune_sys, *TENSIUNE_SYS_RANGE),
        normalize_value(tensiune_dia, *TENSIUNE_DIA_RANGE),
        normalize_value(puls, *PULS_RANGE),
    ]


def create_metabolic_vector(glucoza: float, colesterol: float, trigliceride: float) -> list[float]:
    """Creează vector metabolic normalizat."""
    return [
        normalize_value(glucoza, *GLUCOZA_RANGE),
        normalize_value(colesterol, *COLESTEROL_RANGE),
        normalize_value(trigliceride, *TRIGLICERIDE_RANGE),
    ]


def create_demografic_vector(varsta: float, bmi: float) -> list[float]:
    """Creează vector demografic normalizat."""
    return [
        normalize_value(varsta, *VARSTA_RANGE),
        normalize_value(bmi, *BMI_RANGE),
    ]


def create_all_vector(
    tensiune_sys: float, tensiune_dia: float, puls: float,
    glucoza: float, colesterol: float, trigliceride: float,
    varsta: float, bmi: float,
) -> list[float]:
    """
    Creează vector UNIC cu toate metricile (8 dim).

    PROBLEMA: Toate metricile au aceeași pondere în cosine similarity!
    - Glucoza (important pentru diabet) contează la fel ca BMI
    - Nu poți face "focus pe cardio" sau "focus pe metabolic"
    """
    return [
        normalize_value(tensiune_sys, *TENSIUNE_SYS_RANGE),
        normalize_value(tensiune_dia, *TENSIUNE_DIA_RANGE),
        normalize_value(puls, *PULS_RANGE),
        normalize_value(glucoza, *GLUCOZA_RANGE),
        normalize_value(colesterol, *COLESTEROL_RANGE),
        normalize_value(trigliceride, *TRIGLICERIDE_RANGE),
        normalize_value(varsta, *VARSTA_RANGE),
        normalize_value(bmi, *BMI_RANGE),
    ]
