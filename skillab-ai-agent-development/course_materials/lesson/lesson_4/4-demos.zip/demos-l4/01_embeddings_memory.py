"""
Demo 1: Embeddings + Cosine Similarity în memorie
==================================================
Arată conceptul de bază: texte similare semantic → vectori apropiați

Rulare: python 01_embeddings_memory.py
"""

import numpy as np
from sentence_transformers import SentenceTransformer

# --- Date: Clauze de contract ---
CLAUZE = [
    "Rezilierea contractului se face cu preaviz de 30 de zile calendaristice.",
    
    "Părțile pot înceta colaborarea printr-o notificare scrisă cu 30 de zile înainte.",
    
    "Penalitățile pentru întârziere sunt de 0.1% pe zi din valoarea facturii.",
    
    "Plata se efectuează în termen de 14 zile de la emiterea facturii.",
    
    "Livrarea produselor se face în maxim 5 zile lucrătoare de la comandă.",
    
    "Garanția produselor este de 24 de luni de la data livrării.",
    
    "Forța majoră exonerează părțile de răspundere pentru neexecutare.",
    
    "Confidențialitatea informațiilor este obligatorie pe durata contractului.",
]


def cosine_distance(v1: np.ndarray, v2: np.ndarray) -> float:
    """Calculează similaritatea cosinus între doi vectori."""
    return float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))


def main():
    # 1. Încarcă modelul de embeddings
    print("Încărcare model...")
    model = SentenceTransformer("Qwen/Qwen3-4B")  # mic și rapid

    # 2. Creează embeddings pentru toate clauzele
    print(f"Generare embeddings pentru {len(CLAUZE)} clauze...")
    embeddings = model.encode(CLAUZE)
    print(f"  → Dimensiune vector: {embeddings.shape[1]}")

    # 3. Query semantic
    query = "Cum pot să termin contractul?"
    print(f"\n{'='*60}")
    print(f"Query: \"{query}\"")
    print(f"{'='*60}")

    # Embedding pentru query
    query_embedding = model.encode(query)

    # 4. Calculează similaritate cu fiecare clauză
    print("\nSimilarități:")
    results = []
    for i, (clauza, emb) in enumerate(zip(CLAUZE, embeddings)):
        sim = cosine_distance(query_embedding, emb)
        results.append((sim, clauza))
        print(f"  [{sim:.3f}] {clauza[:60]}...")

    # 5. Top 3 rezultate
    results.sort(reverse=True)
    print(f"\n{'='*60}")
    print("Top 3 clauze relevante:")
    print(f"{'='*60}")
    for i, (sim, clauza) in enumerate(results[:3], 1):
        print(f"\n{i}. [score: {sim:.3f}]")
        print(f"   {clauza}")

    # 6. BONUS: Arată că clauze semantice similare sunt aproape
    print(f"\n{'='*60}")
    print("BONUS: Similaritate între clauze (semantică)")
    print(f"{'='*60}")

    # Clauza 0 și 1 sunt despre reziliere - ar trebui să fie similare
    sim_reziliere = cosine_similarity(embeddings[0], embeddings[1])
    print(f"\nReziliere vs Încetare colaborare: {sim_reziliere:.3f}")
    print(f"  → '{CLAUZE[0][:40]}...'")
    print(f"  → '{CLAUZE[1][:40]}...'")

    # Clauza 0 vs 5 (reziliere vs garanție) - ar trebui să fie diferite
    sim_diferit = cosine_similarity(embeddings[0], embeddings[5])
    print(f"\nReziliere vs Garanție: {sim_diferit:.3f}")
    print(f"  → '{CLAUZE[0][:40]}...'")
    print(f"  → '{CLAUZE[5][:40]}...'")


if __name__ == "__main__":
    main()
