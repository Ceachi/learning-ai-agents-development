"""
Demo 4: Problema "Bag of Words" în Embeddings
==============================================
Arată cum un text COMPLET IRELEVANT poate primi score mare dacă
share-uiește cuvinte cu query-ul, chiar dacă sensul e total diferit.

Exemplu: Text despre VIN primește score mare pentru query despre LAPTOP
doar pentru că ambele conțin "garanție", "luni", "livrare".

Rulare: python 04_problema_text_lung.py
"""

import numpy as np
from sentence_transformers import SentenceTransformer


def cosine_similarity(v1: np.ndarray, v2: np.ndarray) -> float:
    return float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2)))


# =============================================================================
# TEXT IRELEVANT - despre VIN și AGRICULTURĂ
# Conține cuvinte comune: "dezvoltă", "luni", "garanție", "livrare", "termen",
#                         "zile", "plata", "rate", "proces", "durează"
# =============================================================================

TEXT_VIN = """
Procesul de producție a vinului premium

Mustul se dezvoltă în butoaie de stejar laptop timp de 18 luni pentru a obține
aroma dorită. Garanția calității este certificată prin eticheta DOC.

Livrarea termenul comenzilor se face în termen de 5 zile lucrătoare. Pentru comenzi
mari, termenul poate fi extins la 14 zile. Plata se acceptă și în rate.

Strugurii se recoltează în perioada optimă, iar procesul de fermentare
durează aproximativ care 30 de zile în condiții controlate de temperatură.
"""

# =============================================================================
# TEST CASES - query-uri despre ALTE DOMENII care folosesc aceleași cuvinte
# =============================================================================

TEST_CASES = [
    {
        "query": "Cât durează garanția pentru laptop?",
        "text_corect": "Laptopurile au garanție standard de 24 de luni de la achiziție.",
        "chunk_partial": "Magazinul oferă service autorizat pentru electronice.",
        "domeniu_query": "ELECTRONICE",
        "cuvinte_comune": ["garanție", "luni"],
    },
    {
        "query": "Care e termenul de livrare pentru mobilă?",
        "text_corect": "Mobila comandată se livrează în 10-15 zile lucrătoare.",
        "chunk_partial": "Cataloagele de mobilă sunt disponibile în showroom.",
        "domeniu_query": "MOBILĂ",
        "cuvinte_comune": ["termen", "livrare", "zile"],
    },
    {
        "query": "În câte luni se dezvoltă un proiect software?",
        "text_corect": "Un proiect software mediu se dezvoltă în 3-6 luni.",
        "chunk_partial": "Echipa de dezvoltare folosește metodologia Agile.",
        "domeniu_query": "SOFTWARE",
        "cuvinte_comune": ["dezvoltă", "luni"],
    },
    {
        "query": "Cum se face plata în rate pentru mașină?",
        "text_corect": "Plata în rate pentru mașini necesită avans 20% și dobândă fixă.",
        "chunk_partial": "Dealer-ul oferă test drive gratuit pentru toate modelele.",
        "domeniu_query": "AUTO",
        "cuvinte_comune": ["plata", "rate"],
    },
    {
        "query": "Cât durează procesul de aprobare a creditului?",
        "text_corect": "Procesul de aprobare a creditului durează 2-5 zile lucrătoare.",
        "chunk_partial": "Banca oferă credite cu dobândă variabilă sau fixă.",
        "domeniu_query": "BANKING",
        "cuvinte_comune": ["procesul", "durează", "zile"],
    },
]


def main():
    print("Încărcare model...")
    model = SentenceTransformer("all-MiniLM-L6-v2")

    # Embedding pentru textul despre vin
    emb_vin = model.encode(TEXT_VIN)

    print(f"\n{'='*80}")
    print("TEXT SURSĂ - despre VIN (va fi comparat cu queries despre alte domenii):")
    print(f"{'='*80}")
    print(TEXT_VIN.strip())

    probleme = 0

    for i, test in enumerate(TEST_CASES):
        query = test["query"]
        text_corect = test["text_corect"]
        chunk_partial = test["chunk_partial"]
        domeniu = test["domeniu_query"]
        cuvinte = test["cuvinte_comune"]

        query_emb = model.encode(query)
        emb_corect = model.encode(text_corect)
        emb_partial = model.encode(chunk_partial)

        # Scoruri
        score_vin = cosine_similarity(query_emb, emb_vin)
        score_corect = cosine_similarity(query_emb, emb_corect)
        score_partial = cosine_similarity(query_emb, emb_partial)

        # Sortare pentru ranking
        rezultate = [
            ("🍷 TEXT VIN (irelevant)", score_vin),
            ("✅ TEXT CORECT", score_corect),
            ("⚡ CHUNK PARȚIAL", score_partial),
        ]
        rezultate.sort(key=lambda x: x[1], reverse=True)

        print(f"\n{'='*80}")
        print(f"TEST {i+1}: Query despre {domeniu}")
        print(f"Cuvinte comune cu textul despre vin: {cuvinte}")
        print(f"{'='*80}")

        print(f"\nQuery: \"{query}\"")
        print(f"\nTexte comparate:")
        print(f"  ✅ CORECT:  \"{text_corect}\"")
        print(f"  ⚡ PARȚIAL: \"{chunk_partial}\"")
        print(f"  🍷 VIN:     (textul despre vin de mai sus)")

        print(f"\nRanking:")
        for rank, (nume, score) in enumerate(rezultate, 1):
            print(f"  {rank}. [{score:.4f}] {nume}")

        # Analiza problemei
        if score_vin > score_partial:
            probleme += 1
            print(f"\n  ⚠️  PROBLEMĂ: Textul despre VIN bate chunk-ul despre {domeniu}!")
            print(f"      În RAG cu top_k=2, ai primi vin în loc de info utilă.")

        if score_vin > 0.35:
            print(f"\n  📊 TEXT VIN = {score_vin:.2f} (ar putea trece un threshold rezonabil)")

    # === SUMAR ===
    print(f"\n{'='*80}")
    print(f"SUMAR: {probleme}/{len(TEST_CASES)} teste cu problemă")
    print(f"{'='*80}")
    print("""
    CE SE ÎNTÂMPLĂ:

    Textul despre VIN primește scoruri de 0.30-0.50 pentru queries despre:
    - Laptopuri (doar pentru că ambele zic "garanție" și "luni")
    - Mobilă (doar pentru că ambele zic "livrare" și "zile")
    - Software (doar pentru că ambele zic "dezvoltă")
    - etc.

    DE CE E PROBLEMĂ:

    În RAG cu multe documente:
    1. Textul despre vin INTRĂ în rezultate (trece threshold)
    2. OCUPĂ loc în context window
    3. LLM-ul primește informații despre VIN când user-ul întreabă de LAPTOPURI
    4. Răspuns confuz sau hallucination

    SOLUȚII:

    1. CHUNKING - texte mici au embedding-uri mai specifice
    2. RERANKING cu cross-encoder - verifică relevanța semantică reală
    3. HYBRID SEARCH - combină BM25 (exact match) cu embeddings
    4. METADATA FILTERING - filtrează pe domeniu/categorie înainte de search
    """)


if __name__ == "__main__":
    main()
