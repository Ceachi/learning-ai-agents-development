"""
Demo 3: RAG Complet (Retrieve + Generate)
=========================================
Pipeline end-to-end cu arhitectură corectă:
- Repository pattern
- Transaction context manager
- RAGService pentru embedding + search

Setup:
  docker compose up -d
  pip install -r requirements.txt
  Set OPENAI_API_KEY in .env

Rulare: python 03_rag_complet.py
"""

from sqlalchemy import text
from skillab import get_llm, LLMProvider

from database import engine, Base, transaction
from rag_service import RAGService

# --- Date: Clauze de contract ---
CLAUZE = [
    "Rezilierea contractului se face cu preaviz de 30 de zile calendaristice.",
    "Părțile pot înceta colaborarea printr-o notificare scrisă cu 30 de zile înainte.",
    "Penalitățile pentru întârziere sunt de 0.1% pe zi din valoarea facturii.",
    "Plata se efectuează în termen de 14 zile de la emiterea facturii.",
    "Livrarea produselor se face în maxim 5 zile lucrătoare de la comandă.",
    "Garanția produselor este de 24 de luni de la data livrării.",
    "Forța majoră exonerează părțile de răspundere pentru neexecutare.",
    "Confidențialitatea informațiilor este obligatorie pe durata contractului.",
]

SYSTEM_PROMPT = """Ești un asistent juridic. Răspunzi DOAR pe baza clauzelor de contract furnizate.

Reguli:
- Citează clauza relevantă în răspuns
- Dacă informația nu e în clauze, spune "Nu am această informație în contract"
- Răspuns concis, în română"""


def setup_database() -> None:
    """Creează extensia pgvector și tabelele."""
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)


def generate(llm: LLMProvider, context: str, question: str) -> str:
    """Generate: LLM răspunde pe baza contextului."""
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Clauze relevante:\n{context}\n\nÎntrebare: {question}"},
    ]
    return llm.generate_sync(messages)


def rag_pipeline(rag: RAGService, llm: LLMProvider, question: str) -> str:
    """Pipeline complet RAG: Retrieve → Generate."""
    print(f"\n{'='*60}")
    print(f"Întrebare: {question}")
    print(f"{'='*60}")

    # 1. RETRIEVE (folosește RAGService)
    print("\n[1] RETRIEVE - căutare în pgvector...")
    results = rag.search(question, top_k=20)
    
    results = reranking()
    results = results[:3]

    context_parts = []
    for clauza, score in results:
        print(f"    [{score:.3f}] {clauza.content[:50]}...")
        context_parts.append(f"- {clauza.content}")

    context = "\n".join(context_parts)

    # 2. GENERATE
    print("\n[2] GENERATE - trimit la LLM...")
    answer = generate(llm, context, question)

    print(f"\n[3] RĂSPUNS:")
    print(f"    {answer}")

    return answer


def main():
    # 1. Setup DB
    print("Setup database...")
    setup_database()

    # 2. Populare cu clauze
    print("Inserare clauze...")
    with transaction() as db:
        rag = RAGService(db)
        rag.add_clauze_batch(CLAUZE)
        print(f"✓ {len(CLAUZE)} clauze în DB")

    # 3. Inițializare LLM
    print("Conectare la OpenAI...")
    llm = get_llm("openai", temperature=0)
    print(f"✓ Using {llm.model}")

    # 4. Demo queries
    questions = [
        "Cum pot să reziliez contractul?",
        "Ce penalități am dacă nu plătesc la timp?",
        "Cât durează garanția?",
        "Care e termenul de livrare?",
    ]

    # Fiecare query în tranzacție separată (sau una singură, depinde de use case)
    with transaction() as db:
        rag = RAGService(db)
        for q in questions:
            rag_pipeline(rag, llm, q)


if __name__ == "__main__":
    main()
