"""
Repository pentru produse e-commerce cu CLIP embeddings.

Demonstrează:
- Search by image embedding
- Search by text embedding (CLIP magic!)
- Ambele folosesc același vector space
"""

from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image
from sqlalchemy import select
from sqlalchemy.orm import Session
from sentence_transformers import SentenceTransformer

from models_ecommerce import Product, CLIP_EMBEDDING_DIM


@dataclass
class ProductInput:
    """Date de intrare pentru un produs nou."""
    external_id: str
    name: str
    category: str
    price: float
    description: str
    reviews_summary: str
    image_file: str  # nume fișier în IMAGES_DIR


class CLIPService:
    """Serviciu pentru generare embeddings cu CLIP."""

    _model: SentenceTransformer | None = None  # singleton

    def __init__(self, model_name: str = "clip-ViT-B-32"):
        self.model_name = model_name

    @property
    def model(self) -> SentenceTransformer:
        """Lazy loading pentru model."""
        if CLIPService._model is None:
            print(f"Încărcare model CLIP ({self.model_name})...")
            CLIPService._model = SentenceTransformer(self.model_name)
        return CLIPService._model

    def embed_image(self, image: Image.Image) -> list[float]:
        """Generează embedding pentru o imagine."""
        embedding = self.model.encode(image)
        return embedding.tolist()

    def embed_text(self, text: str) -> list[float]:
        """Generează embedding pentru text (CLIP magic!)."""
        embedding = self.model.encode(text)
        return embedding.tolist()

    def embed_image_file(self, filepath: Path) -> list[float] | None:
        """Încarcă și embed-uiește o imagine de pe disk."""
        try:
            image = Image.open(filepath).convert("RGB")
            return self.embed_image(image)
        except Exception as e:
            print(f"  ⚠️ Nu am putut procesa: {filepath} ({e})")
            return None


class ProductRepository:
    """Repository pentru produse cu operații CRUD și similarity search."""

    def __init__(self, db: Session, clip: CLIPService, images_dir: Path) -> None:
        self.db = db
        self.clip = clip
        self.images_dir = images_dir

    # =========================================================================
    # CREATE
    # =========================================================================

    def create(self, data: ProductInput) -> Product | None:
        """Creează un produs cu embedding CLIP generat automat."""
        image_path = self.images_dir / data.image_file

        if not image_path.exists():
            print(f"  ⚠️ Imagine lipsă: {data.image_file}")
            return None

        embedding = self.clip.embed_image_file(image_path)
        if embedding is None:
            return None

        product = Product(
            external_id=data.external_id,
            name=data.name,
            category=data.category,
            price=data.price,
            description=data.description,
            reviews_summary=data.reviews_summary,
            image_file=data.image_file,
            embedding=embedding,
        )
        self.db.add(product)
        self.db.flush()
        return product

    def create_batch(self, products_data: list[ProductInput]) -> list[Product]:
        """Creează mai multe produse batch."""
        products = []
        for data in products_data:
            print(f"  [{data.external_id}] {data.name}...", end=" ")
            product = self.create(data)
            if product:
                products.append(product)
                print(f"✓ (dim={CLIP_EMBEDDING_DIM})")
            else:
                print("SKIP")
        return products

    # =========================================================================
    # READ
    # =========================================================================

    def get_by_id(self, product_id: int) -> Product | None:
        return self.db.get(Product, product_id)

    def get_by_external_id(self, external_id: str) -> Product | None:
        stmt = select(Product).where(Product.external_id == external_id)
        return self.db.execute(stmt).scalar_one_or_none()

    def get_all(self, limit: int = 100) -> list[Product]:
        stmt = select(Product).limit(limit)
        return list(self.db.execute(stmt).scalars())

    # =========================================================================
    # SIMILARITY SEARCH
    # =========================================================================

    def search_by_image(
        self,
        image: Image.Image,
        top_k: int = 5,
    ) -> list[tuple[Product, float]]:
        """Caută produse similare cu o imagine."""
        query_embedding = self.clip.embed_image(image)
        return self._search_by_embedding(query_embedding, top_k)

    def search_by_image_file(
        self,
        image_path: Path,
        top_k: int = 5,
    ) -> list[tuple[Product, float]]:
        """Caută produse similare cu o imagine de pe disk."""
        query_embedding = self.clip.embed_image_file(image_path)
        if query_embedding is None:
            return []
        return self._search_by_embedding(query_embedding, top_k)

    def search_by_text(
        self,
        text: str,
        top_k: int = 5,
    ) -> list[tuple[Product, float]]:
        """
        Caută produse folosind text.

        CLIP magic: textul și imaginile sunt în același spațiu vectorial,
        deci poți căuta imagini cu text!
        """
        query_embedding = self.clip.embed_text(text)
        return self._search_by_embedding(query_embedding, top_k)

    def search_similar_to_product(
        self,
        product_id: str,
        top_k: int = 5,
    ) -> list[tuple[Product, float]]:
        """Găsește produse similare cu un produs existent."""
        product = self.get_by_external_id(product_id)
        if product is None:
            return []

        # Folosește embedding-ul existent (nu recalculează)
        return self._search_by_embedding(
            list(product.embedding),
            top_k + 1  # +1 pentru că va include și produsul însuși
        )[1:]  # Exclude primul rezultat (self)

    def _search_by_embedding(
        self,
        query_embedding: list[float],
        top_k: int,
    ) -> list[tuple[Product, float]]:
        """Search intern cu embedding."""
        similarity = (
            1 - Product.embedding.cosine_distance(query_embedding)
        ).label("score")

        stmt = (
            select(Product, similarity)
            .order_by(Product.embedding.cosine_distance(query_embedding))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(product, float(score)) for product, score in rows]

    # =========================================================================
    # DELETE
    # =========================================================================

    def delete_all(self) -> int:
        """Șterge toate produsele (pentru reset în demo)."""
        result = self.db.execute(Product.__table__.delete())
        return result.rowcount
