"""
Models pentru RAG pe Imagini E-commerce.

Demonstrează:
- Stocare embedding CLIP (512 dim) în PostgreSQL cu pgvector
- Produs cu imagine, descriere, preț, reviews
"""

from sqlalchemy import Column, Integer, Float, String, Text, DateTime, func
from pgvector.sqlalchemy import Vector

from database import Base

# CLIP ViT-B-32 produce embeddings de 512 dimensiuni
CLIP_EMBEDDING_DIM = 512


class Product(Base):
    """
    Produs din catalog cu embedding CLIP pentru imagine.

    Embedding-ul imagine permite:
    - Search by image (găsește produse similare vizual)
    - Search by text (CLIP înțelege și text!)
    """
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, autoincrement=True)
    external_id = Column(String(50), unique=True, nullable=False)  # P001, P002, etc.

    # Info produs
    name = Column(String(255), nullable=False)
    category = Column(String(100), nullable=False)
    price = Column(Float, nullable=False)
    description = Column(Text, nullable=False)
    reviews_summary = Column(Text, nullable=False)

    # Path la imaginea locală
    image_file = Column(String(255), nullable=False)

    # Embedding CLIP (512 dim)
    embedding = Column(Vector(CLIP_EMBEDDING_DIM), nullable=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self) -> str:
        return f"<Product {self.external_id}: {self.name} - {self.price} RON>"

    @property
    def display_info(self) -> str:
        """Format pentru afișare."""
        return f"{self.name} | {self.category} | {self.price} RON"
