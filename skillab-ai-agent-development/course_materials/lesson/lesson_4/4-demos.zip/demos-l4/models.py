"""
SQLAlchemy models pentru demo RAG.
"""

from sqlalchemy import Column, Integer, Text, DateTime, func
from pgvector.sqlalchemy import Vector

from database import Base


class Clauza(Base):
    """O clauză de contract cu embedding pentru căutare semantică."""

    __tablename__ = "clauze"

    id = Column(Integer, primary_key=True, autoincrement=True)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(384), nullable=False)  # all-MiniLM-L6-v2 = 384 dim
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self) -> str:
        return f"<Clauza id={self.id} content='{self.content[:30]}...'>"
