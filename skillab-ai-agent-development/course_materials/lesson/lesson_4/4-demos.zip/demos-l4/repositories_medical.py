"""
Repository pentru pacienți cu similarity search pe vectori grupați.

Demonstrează:
1. Similarity search pe UN SINGUR grup (cardio, metabolic, demografic)
2. Similarity search COMPUS cu weights configurabile
3. Cum pgvector face search pe fiecare vector separat
"""

from dataclasses import dataclass
from sqlalchemy import select
from sqlalchemy.orm import Session

from models_medical import (
    Patient,
    create_cardio_vector,
    create_metabolic_vector,
    create_demografic_vector,
    create_all_vector,
)


@dataclass
class PatientInput:
    """Date de intrare pentru un pacient nou."""
    external_id: str
    tensiune_sys: float
    tensiune_dia: float
    puls: float
    glucoza: float
    colesterol: float
    trigliceride: float
    varsta: float
    bmi: float
    diagnostic: str


@dataclass
class SimilarityWeights:
    """Ponderi pentru similarity search compus."""
    cardio: float = 0.4
    metabolic: float = 0.4
    demografic: float = 0.2

    def __post_init__(self):
        total = self.cardio + self.metabolic + self.demografic
        if abs(total - 1.0) > 0.001:
            raise ValueError(f"Weights must sum to 1.0, got {total}")

    @classmethod
    def cardio_focus(cls) -> "SimilarityWeights":
        """Focus pe metrici cardiovasculare."""
        return cls(cardio=0.7, metabolic=0.2, demografic=0.1)

    @classmethod
    def metabolic_focus(cls) -> "SimilarityWeights":
        """Focus pe metrici metabolice."""
        return cls(cardio=0.2, metabolic=0.7, demografic=0.1)

    @classmethod
    def balanced(cls) -> "SimilarityWeights":
        """Balanced între toate grupurile."""
        return cls(cardio=0.4, metabolic=0.4, demografic=0.2)


@dataclass
class SearchResult:
    """Rezultat al similarity search cu breakdown pe grupuri."""
    patient: Patient
    score_total: float
    score_cardio: float
    score_metabolic: float
    score_demografic: float


class PatientRepository:
    """Repository pentru pacienți cu operații CRUD și similarity search."""

    def __init__(self, db: Session) -> None:
        self.db = db

    # =========================================================================
    # CREATE
    # =========================================================================

    def create(self, data: PatientInput) -> Patient:
        """Creează un pacient cu vectorii normalizați calculați automat."""
        patient = Patient(
            external_id=data.external_id,
            # Valori raw
            tensiune_sys=data.tensiune_sys,
            tensiune_dia=data.tensiune_dia,
            puls=data.puls,
            glucoza=data.glucoza,
            colesterol=data.colesterol,
            trigliceride=data.trigliceride,
            varsta=data.varsta,
            bmi=data.bmi,
            diagnostic=data.diagnostic,
            # Vectori SEPARAȚI (soluția bună)
            embedding_cardio=create_cardio_vector(
                data.tensiune_sys, data.tensiune_dia, data.puls
            ),
            embedding_metabolic=create_metabolic_vector(
                data.glucoza, data.colesterol, data.trigliceride
            ),
            embedding_demografic=create_demografic_vector(
                data.varsta, data.bmi
            ),
            # Vector UNIC (pentru demo problema)
            embedding_all=create_all_vector(
                data.tensiune_sys, data.tensiune_dia, data.puls,
                data.glucoza, data.colesterol, data.trigliceride,
                data.varsta, data.bmi,
            ),
        )
        self.db.add(patient)
        self.db.flush()
        return patient

    def create_batch(self, patients_data: list[PatientInput]) -> list[Patient]:
        """Creează mai mulți pacienți batch."""
        patients = [self.create(data) for data in patients_data]
        return patients

    # =========================================================================
    # READ
    # =========================================================================

    def get_by_id(self, patient_id: int) -> Patient | None:
        return self.db.get(Patient, patient_id)

    def get_by_external_id(self, external_id: str) -> Patient | None:
        stmt = select(Patient).where(Patient.external_id == external_id)
        return self.db.execute(stmt).scalar_one_or_none()

    def get_all(self, limit: int = 100) -> list[Patient]:
        stmt = select(Patient).limit(limit)
        return list(self.db.execute(stmt).scalars())

    # =========================================================================
    # SIMILARITY SEARCH - Pe UN SINGUR grup
    # =========================================================================

    def search_by_cardio(
        self,
        tensiune_sys: float,
        tensiune_dia: float,
        puls: float,
        top_k: int = 5,
    ) -> list[tuple[Patient, float]]:
        """Caută pacienți similari DOAR pe metrici cardiovasculare."""
        query_vec = create_cardio_vector(tensiune_sys, tensiune_dia, puls)

        similarity = (
            1 - Patient.embedding_cardio.cosine_distance(query_vec)
        ).label("score")

        stmt = (
            select(Patient, similarity)
            .order_by(Patient.embedding_cardio.cosine_distance(query_vec))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(patient, float(score)) for patient, score in rows]

    def search_by_metabolic(
        self,
        glucoza: float,
        colesterol: float,
        trigliceride: float,
        top_k: int = 5,
    ) -> list[tuple[Patient, float]]:
        """Caută pacienți similari DOAR pe metrici metabolice."""
        query_vec = create_metabolic_vector(glucoza, colesterol, trigliceride)

        similarity = (
            1 - Patient.embedding_metabolic.cosine_distance(query_vec)
        ).label("score")

        stmt = (
            select(Patient, similarity)
            .order_by(Patient.embedding_metabolic.cosine_distance(query_vec))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(patient, float(score)) for patient, score in rows]

    def search_by_demografic(
        self,
        varsta: float,
        bmi: float,
        top_k: int = 5,
    ) -> list[tuple[Patient, float]]:
        """Caută pacienți similari DOAR pe date demografice."""
        query_vec = create_demografic_vector(varsta, bmi)

        similarity = (
            1 - Patient.embedding_demografic.cosine_distance(query_vec)
        ).label("score")

        stmt = (
            select(Patient, similarity)
            .order_by(Patient.embedding_demografic.cosine_distance(query_vec))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(patient, float(score)) for patient, score in rows]

    # =========================================================================
    # SIMILARITY SEARCH - VECTOR UNIC (demo problema!)
    # =========================================================================

    def search_single_vector(
        self,
        tensiune_sys: float,
        tensiune_dia: float,
        puls: float,
        glucoza: float,
        colesterol: float,
        trigliceride: float,
        varsta: float,
        bmi: float,
        top_k: int = 5,
    ) -> list[tuple[Patient, float]]:
        """
        Search cu TOATE metricile într-un singur vector.

        PROBLEMA: Nu poți controla importanța fiecărui grup!
        - Toate cele 8 metrici au pondere egală
        - Nu poți face "focus pe cardio" sau "focus pe metabolic"
        - Diferențe mari în metabolic pot masca similarități în cardio
        """
        query_vec = create_all_vector(
            tensiune_sys, tensiune_dia, puls,
            glucoza, colesterol, trigliceride,
            varsta, bmi,
        )

        similarity = (
            1 - Patient.embedding_all.cosine_distance(query_vec)
        ).label("score")

        stmt = (
            select(Patient, similarity)
            .order_by(Patient.embedding_all.cosine_distance(query_vec))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(patient, float(score)) for patient, score in rows]

    # =========================================================================
    # SIMILARITY SEARCH - COMPUS (weighted)
    # =========================================================================

    def search_composite(
        self,
        tensiune_sys: float,
        tensiune_dia: float,
        puls: float,
        glucoza: float,
        colesterol: float,
        trigliceride: float,
        varsta: float,
        bmi: float,
        weights: SimilarityWeights,
        top_k: int = 5,
    ) -> list[SearchResult]:
        """
        Similarity search COMPUS cu breakdown pe grupuri.

        Calculează:
        - Similarity pentru fiecare grup separat
        - Score total = weighted sum

        Returnează SearchResult cu toate scorurile pentru transparență.
        """
        # Creează vectorii de query
        query_cardio = create_cardio_vector(tensiune_sys, tensiune_dia, puls)
        query_metabolic = create_metabolic_vector(glucoza, colesterol, trigliceride)
        query_demografic = create_demografic_vector(varsta, bmi)

        # Similarity pentru fiecare grup
        sim_cardio = (
            1 - Patient.embedding_cardio.cosine_distance(query_cardio)
        ).label("score_cardio")
        sim_metabolic = (
            1 - Patient.embedding_metabolic.cosine_distance(query_metabolic)
        ).label("score_metabolic")
        sim_demografic = (
            1 - Patient.embedding_demografic.cosine_distance(query_demografic)
        ).label("score_demografic")

        # Score compus (weighted sum) - calculat în SQL
        score_total = (
            weights.cardio * (1 - Patient.embedding_cardio.cosine_distance(query_cardio)) +
            weights.metabolic * (1 - Patient.embedding_metabolic.cosine_distance(query_metabolic)) +
            weights.demografic * (1 - Patient.embedding_demografic.cosine_distance(query_demografic))
        ).label("score_total")

        stmt = (
            select(Patient, score_total, sim_cardio, sim_metabolic, sim_demografic)
            .order_by(score_total.desc())
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [
            SearchResult(
                patient=patient,
                score_total=float(total),
                score_cardio=float(cardio),
                score_metabolic=float(metabolic),
                score_demografic=float(demo),
            )
            for patient, total, cardio, metabolic, demo in rows
        ]

    # =========================================================================
    # DELETE
    # =========================================================================

    def delete_all(self) -> int:
        """Șterge toți pacienții (pentru reset în demo)."""
        result = self.db.execute(Patient.__table__.delete())
        return result.rowcount
