"""
Demo 6: RAG pe Imagini - E-commerce Product Visual Search
=========================================================
Folosește CLIP pentru embedding imagini și text în același spațiu vectorial.

Use case:
- User uploadează poză cu produs
- Găsim produse vizual similare
- Retrieve: descrieri, prețuri, reviews
- LLM: recomandări bazate pe produse similare

Setup:
  docker compose up -d
  python download_images.py   # descarcă imaginile local (o singură dată)
  pip install -r requirements.txt

Rulare: python 06_rag_images_ecommerce.py
"""

from pathlib import Path

from PIL import Image
from sqlalchemy import text

from database import engine, Base, transaction
from models_ecommerce import Product
from repositories_ecommerce import ProductRepository, ProductInput, CLIPService

# Folder cu imagini locale
IMAGES_DIR = Path(__file__).parent / "images"


# =============================================================================
# CATALOG PRODUSE
# =============================================================================

PRODUCTS_DATA = [
    ProductInput(
        external_id="P001",
        name="Rochie roșie elegantă",
        category="rochii",
        price=299.99,
        description="Rochie lungă din satin roșu, perfectă pentru evenimente speciale. "
                    "Decolteu în V, talie marcată, fustă fluidă.",
        reviews_summary="4.8/5 - Clienții laudă calitatea materialului și croiala elegantă.",
        image_file="P001_rochie_rosie.jpg",
    ),
    ProductInput(
        external_id="P002",
        name="Rochie albastră casual",
        category="rochii",
        price=149.99,
        description="Rochie midi din bumbac albastru deschis, ideală pentru zi. "
                    "Mâneci scurte, croială lejeră, buzunare laterale.",
        reviews_summary="4.5/5 - Confortabilă și versatilă, perfectă pentru vară.",
        image_file="P002_rochie_albastra.jpg",
    ),
    ProductInput(
        external_id="P003",
        name="Geacă piele neagră",
        category="geci",
        price=499.99,
        description="Geacă biker din piele naturală neagră. Fermoare metalice, "
                    "căptușeală caldă, stil rock clasic.",
        reviews_summary="4.9/5 - Calitate excepțională, se mulează perfect pe corp.",
        image_file="P003_geaca_piele.jpg",
    ),
    ProductInput(
        external_id="P004",
        name="Blugi slim fit",
        category="pantaloni",
        price=179.99,
        description="Jeans slim fit din denim stretch albastru închis. "
                    "Talie medie, confortabili și eleganți.",
        reviews_summary="4.6/5 - Fit perfect, materialul rezistă la multe spălări.",
        image_file="P004_blugi.jpg",
    ),
    ProductInput(
        external_id="P005",
        name="Sneakers albi minimaliști",
        category="încălțăminte",
        price=249.99,
        description="Sneakers din piele albă, design minimalist scandinav. "
                    "Talpă confortabilă, se potrivesc cu orice outfit.",
        reviews_summary="4.7/5 - Eleganți și confortabili, ușor de întreținut.",
        image_file="P005_sneakers.jpg",
    ),
    ProductInput(
        external_id="P006",
        name="Rochie neagră cocktail",
        category="rochii",
        price=349.99,
        description="Little black dress din dantelă fină. Lungime până la genunchi, "
                    "mâneci trei sferturi, elegantă și sofisticată.",
        reviews_summary="4.8/5 - Un must-have, se potrivește la orice eveniment.",
        image_file="P006_rochie_neagra.jpg",
    ),
    ProductInput(
        external_id="P007",
        name="Palton camel lână",
        category="paltoane",
        price=599.99,
        description="Palton lung din lână camel, croială clasică. "
                    "Închidere cu nasturi, buzunare laterale, căptușit.",
        reviews_summary="4.9/5 - Investiție excelentă, calitate premium, foarte cald.",
        image_file="P007_palton.jpg",
    ),
    ProductInput(
        external_id="P008",
        name="Tricou alb basic",
        category="tricouri",
        price=49.99,
        description="Tricou basic din bumbac organic alb. Croială regular fit, "
                    "gât rotund, material moale și respirabil.",
        reviews_summary="4.4/5 - Simplu dar de calitate, perfect ca bază pentru layering.",
        image_file="P008_tricou.jpg",
    ),
]


def setup_database() -> None:
    """Creează extensia pgvector și tabelele."""
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    print("✓ Database setup complet")


def check_images() -> bool:
    """Verifică dacă imaginile sunt descărcate."""
    if not IMAGES_DIR.exists():
        return False
    required = [p.image_file for p in PRODUCTS_DATA]
    missing = [f for f in required if not (IMAGES_DIR / f).exists()]
    if missing:
        print(f"⚠️ Lipsesc {len(missing)} imagini. Rulează: python download_images.py")
        return False
    return True


def demo_search_by_text(repo: ProductRepository):
    """Demo: căutare cu text (CLIP magic!)."""
    print(f"\n{'='*80}")
    print("📝 SEARCH BY TEXT - CLIP înțelege și text!")
    print(f"{'='*80}")

    queries = [
        "red elegant dress for party",
        "black leather jacket rock style",
        "white minimalist sneakers",
        "warm winter coat",
    ]

    for query in queries:
        print(f"\nQuery: \"{query}\"")
        results = repo.search_by_text(query, top_k=2)

        for i, (p, sim) in enumerate(results, 1):
            print(f"  {i}. [{sim:.4f}] {p.name} - {p.price} RON")


def demo_search_by_image(repo: ProductRepository):
    """Demo: căutare cu o imagine nouă."""
    print(f"\n{'='*80}")
    print("🖼️  SEARCH BY IMAGE - Găsește produse similare vizual")
    print(f"{'='*80}")

    query_path = IMAGES_DIR / "query_rochie.jpg"
    print(f"\nQuery image: {query_path.name}")
    print("(Simulăm un user care uploadează o poză cu o rochie)")

    if not query_path.exists():
        print(f"⚠️ Lipsește {query_path}. Rulează: python download_images.py")
        return

    results = repo.search_by_image_file(query_path, top_k=3)

    print(f"\n📦 Top {len(results)} produse similare vizual:")
    for i, (p, sim) in enumerate(results, 1):
        print(f"\n  {i}. [{sim:.4f}] {p.name}")
        print(f"     Preț: {p.price} RON | Categorie: {p.category}")
        print(f"     {p.description[:80]}...")
        print(f"     Reviews: {p.reviews_summary}")


def demo_similar_products(repo: ProductRepository):
    """Demo: găsește produse similare cu un produs existent."""
    print(f"\n{'='*80}")
    print("🔄 PRODUSE SIMILARE - Recomandări 'Customers also viewed'")
    print(f"{'='*80}")

    product_id = "P001"  # Rochie roșie
    print(f"\nProdus: {product_id} (Rochie roșie elegantă)")
    print("Găsește produse similare vizual...\n")

    results = repo.search_similar_to_product(product_id, top_k=3)

    print("Produse similare:")
    for i, (p, sim) in enumerate(results, 1):
        print(f"  {i}. [{sim:.4f}] {p.name} - {p.price} RON")


def demo_rag_recommendation(repo: ProductRepository):
    """Demo: RAG complet - search → retrieve → context pentru LLM."""
    print(f"\n{'='*80}")
    print("🛒 RAG COMPLET: Visual Search → Retrieve Info → Recomandare LLM")
    print(f"{'='*80}")

    query_path = IMAGES_DIR / "query_rochie.jpg"
    print(f"\nUser uploadează: {query_path.name}")

    if not query_path.exists():
        print(f"⚠️ Lipsește imaginea. Rulează: python download_images.py")
        return

    # 1. RETRIEVE
    print(f"\n[1] RETRIEVE - Căutare vizuală în catalog...")
    results = repo.search_by_image_file(query_path, top_k=3)

    context_parts = []
    for p, sim in results:
        print(f"    [{sim:.4f}] {p.name}")
        context_parts.append(
            f"Produs similar (similaritate {sim:.2f}):\n"
            f"  Nume: {p.name}\n"
            f"  Categorie: {p.category}\n"
            f"  Preț: {p.price} RON\n"
            f"  Descriere: {p.description}\n"
            f"  Reviews: {p.reviews_summary}"
        )

    # 2. BUILD CONTEXT
    context = "\n\n".join(context_parts)
    print(f"\n[2] CONTEXT pentru LLM:")
    print("-" * 40)
    print(context[:600] + "..." if len(context) > 600 else context)
    print("-" * 40)

    # 3. PROMPT pentru LLM
    prompt = f"""Ești un consultant de modă pentru un magazin online.

Un client a uploadat o imagine cu un articol vestimentar pe care îl caută.
Am găsit următoarele produse similare în catalogul nostru:

{context}

Bazat pe aceste produse similare:
1. Recomandă cel mai potrivit produs pentru client
2. Explică de ce acest produs se potrivește
3. Sugerează și accesorii sau piese complementare
4. Menționează range-ul de preț și valoarea

Răspunde în română, într-un stil prietenos dar profesionist."""

    print(f"\n[3] PROMPT pentru LLM (ar fi trimis la Ollama):")
    print("=" * 40)
    print(prompt[:700] + "...")


def main():
    print("=" * 80)
    print("DEMO: RAG pe Imagini cu CLIP - E-commerce Visual Search")
    print("=" * 80)

    # Verifică imagini
    if not check_images():
        print("\nDescarcă imaginile întâi:")
        print("  python download_images.py")
        return

    # Setup DB
    setup_database()

    # Inițializare CLIP service
    clip = CLIPService()

    # Populare cu produse
    print("\nIndexare produse...")
    with transaction() as db:
        repo = ProductRepository(db, clip, IMAGES_DIR)
        products = repo.create_batch(PRODUCTS_DATA)
        print(f"\n✓ {len(products)} produse indexate în PostgreSQL")

    # Demo-uri
    with transaction() as db:
        repo = ProductRepository(db, clip, IMAGES_DIR)
        demo_search_by_text(repo)
        demo_search_by_image(repo)
        demo_similar_products(repo)
        demo_rag_recommendation(repo)

    # Sumar
    print(f"\n{'='*80}")
    print("SUMAR - CE AM DEMONSTRAT:")
    print(f"{'='*80}")
    print("""
    ARHITECTURA:
    ┌─────────────────────────────────────────────────────────────┐
    │  Product (model)                                            │
    │  ├── embedding  Vector(512)  - CLIP embedding               │
    │  ├── name, description, price, reviews...                   │
    │  └── image_file (path local)                                │
    └─────────────────────────────────────────────────────────────┘

    REPOSITORY METHODS:
    1. search_by_image()           - upload imagine → produse similare
    2. search_by_text()            - text query → produse (CLIP magic!)
    3. search_similar_to_product() - recomandări "customers also viewed"

    CLIP MAGIC:
    - Imagini și text în ACELAȘI spațiu vectorial (512 dim)
    - "red dress" (text) găsește poze cu rochii roșii
    - Poză cu rochie găsește alte rochii

    RAG FLOW:
    Upload imagine → CLIP embedding → pgvector search → retrieve info → LLM
    """)


if __name__ == "__main__":
    main()
