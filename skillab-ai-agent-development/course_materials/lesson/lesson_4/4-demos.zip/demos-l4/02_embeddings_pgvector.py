"""
Demo 2: Embeddings + pgvector cu Repository Pattern
====================================================
Același concept ca Demo 1, dar cu:
- PostgreSQL + pgvector
- SQLAlchemy ORM
- Repository pattern
- Transaction context manager

Setup:
  docker compose up -d
  pip install -r requirements.txt

Rulare: python 02_embeddings_pgvector.py
"""

from sqlalchemy import text

from database import engine, Base, transaction
from models import Clauza
from repositories import ClauzeRepository
from rag_service import RAGService

# --- Date: Clauze de contract ---
CLAUZE = [
    "Rezilierea contractului se face cu preaviz de 30 de zile calendaristice.",
    "Părțile pot înceta colaborarea printr-o notificare scrisă cu 30 de zile înainte.",
    "Penalitățile pentru întârziere sunt de 0.1% pe zi din valoarea facturii.",
    "Plata se efectuează în termen de 14 zile de la emiterea facturii.",
    "Livrarea produselor se face în maxim 5 zile lucrătoare de la comandă.",
    "Garanția produselor este de 24 de luni de la data livrării.",
    "Forța majoră exonerează părțile de răspundere pentru neexecutare.",
    "Confidențialitatea informațiilor este obligatorie pe durata contractului.",
]


def setup_database() -> None:
    """Creează extensia pgvector și tabelele."""
    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    print("✓ Extensie pgvector + tabel 'clauze' create")


def main():
    # 1. Setup DB
    setup_database()

    # 2. Inserare clauze cu Repository + Transaction
    with transaction() as db:
        rag = RAGService(db)
        clauze = rag.add_clauze_batch(CLAUZE)
        print(f"✓ {len(clauze)} clauze inserate în DB")

    # 3. Query semantic (nouă tranzacție)
    with transaction() as db:
        rag = RAGService(db)

        query = "Cum pot să termin contractul?"
        print(f"\n{'='*60}")
        print(f"Query: \"{query}\"")
        print(f"{'='*60}")

        results = rag.search(query, top_k=3)

        print(f"\nTop {len(results)} clauze relevante:")
        for i, (clauza, score) in enumerate(results, 1):
            print(f"\n{i}. [score: {score:.3f}]")
            print(f"   {clauza.content}")

    # 4. Alt query
    with transaction() as db:
        rag = RAGService(db)

        query2 = "Ce se întâmplă dacă plătesc cu întârziere?"
        print(f"\n{'='*60}")
        print(f"Query: \"{query2}\"")
        print(f"{'='*60}")

        results2 = rag.search(query2, top_k=3)
        for i, (clauza, score) in enumerate(results2, 1):
            print(f"\n{i}. [score: {score:.3f}]")
            print(f"   {clauza.content}")

    # 5. Arată SQL-ul pentru slide
    print(f"\n{'='*60}")
    print("SQL pgvector echivalent:")
    print(f"{'='*60}")
    print("""
    SELECT content, 1 - (embedding <=> query_vector) AS similarity
    FROM clauze
    ORDER BY embedding <=> query_vector
    LIMIT 3;

    -- Repository pattern ascunde SQL-ul raw
    -- dar folosește aceeași logică pgvector underneath
    """)


if __name__ == "__main__":
    main()
