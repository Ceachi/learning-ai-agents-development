"""
Repository pattern pentru Clauze cu pgvector.
"""

from sqlalchemy import select
from sqlalchemy.orm import Session

from models import Clauza


class ClauzeRepository:
    """Repository pentru operații CRUD + similarity search pe clauze."""

    def __init__(self, db: Session) -> None:
        self.db = db

    # CREATE
    def create(self, content: str, embedding: list[float]) -> Clauza:
        clauza = Clauza(content=content, embedding=embedding)
        self.db.add(clauza)
        self.db.flush()  # obține ID-ul, commit se face în transaction()
        return clauza

    def create_batch(self, items: list[dict]) -> list[Clauza]:
        """Inserare batch: [{content: str, embedding: list[float]}, ...]"""
        clauze = [Clauza(**item) for item in items]
        self.db.add_all(clauze)
        self.db.flush()
        return clauze

    # READ
    def get_all(self, limit: int = 100) -> list[Clauza]:
        return list(self.db.execute(select(Clauza).limit(limit)).scalars())

    def get_by_id(self, clauza_id: int) -> Clauza | None:
        return self.db.get(Clauza, clauza_id)

    # SEARCH (pgvector)
    def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 5,
    ) -> list[tuple[Clauza, float]]:
        """Caută clauze similare folosind cosine similarity."""
        # 1 - cosine_distance = similarity score [0, 1]
        similarity = (1 - Clauza.embedding.cosine_distance(query_embedding)).label(
            "score"
        )

        stmt = (
            select(Clauza, similarity)
            .order_by(Clauza.embedding.cosine_distance(query_embedding))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(clauza, float(score)) for clauza, score in rows]

    # DELETE
    def delete_all(self) -> int:
        """Șterge toate clauzele (pentru reset în demo)."""
        result = self.db.execute(Clauza.__table__.delete())
        return result.rowcount
