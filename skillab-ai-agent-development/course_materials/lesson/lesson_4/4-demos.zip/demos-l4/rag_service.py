"""
RAG Service: embedding + similarity search.
"""

from sentence_transformers import SentenceTransformer
from sqlalchemy.orm import Session

from repositories import ClauzeRepository
from models import Clauza

MODEL_NAME = "all-MiniLM-L6-v2"


class RAGService:
    """Serviciu RAG cu lazy loading pentru modelul de embeddings."""

    _model: SentenceTransformer | None = None  # singleton per proces

    def __init__(self, db: Session) -> None:
        self.repo = ClauzeRepository(db)

    @property
    def model(self) -> SentenceTransformer:
        """Lazy loading: modelul se încarcă o singură dată."""
        if RAGService._model is None:
            print(f"Încărcare model {MODEL_NAME}...")
            RAGService._model = SentenceTransformer(MODEL_NAME)
        return RAGService._model

    def embed(self, text: str) -> list[float]:
        """Generează embedding pentru un text."""
        return self.model.encode(text, convert_to_numpy=True).tolist()

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Generează embeddings pentru mai multe texte (batch)."""
        embeddings = self.model.encode(texts, convert_to_numpy=True)
        return [emb.tolist() for emb in embeddings]

    def add_clauza(self, content: str) -> Clauza:
        """Adaugă o clauză cu embedding generat automat."""
        embedding = self.embed(content)
        return self.repo.create(content, embedding)

    def add_clauze_batch(self, contents: list[str]) -> list[Clauza]:
        """Adaugă multiple clauze (batch optimizat)."""
        embeddings = self.embed_batch(contents)
        items = [
            {"content": content, "embedding": emb}
            for content, emb in zip(contents, embeddings)
        ]
        return self.repo.create_batch(items)

    def search(
        self,
        query: str,
        top_k: int = 5,
    ) -> list[tuple[Clauza, float]]:
        """Caută clauze relevante pentru query."""
        query_embedding = self.embed(query)
        return self.repo.similarity_search(query_embedding, top_k=top_k)

    def get_context(
        self,
        query: str,
        top_k: int = 3,
        threshold: float = 0.3,
    ) -> str:
        """Returnează context formatat pentru LLM."""
        results = self.search(query, top_k=top_k)
        relevant = [(c, s) for c, s in results if s >= threshold]

        if not relevant:
            return ""

        return "\n\n".join(
            f"[Clauza {c.id}, score={s:.2f}] {c.content}" for c, s in relevant
        )
