# skillab-py

Python utilities pentru AI Course.

## Install

```bash
pip install -e ".[all-llm]"
```

## LLM

```python
from skillab import get_llm

# Auto-detect provider
llm = get_llm()

# Explicit provider
llm = get_llm("anthropic")

# With LangChain wrapper
from skillab import wrap_langchain
lc_llm = wrap_langchain(llm)
response = lc_llm.invoke("Hello")
```

Providers: `anthropic`, `openai`, `google`, `local`

## Prompts

```python
from skillab.prompts import PromptRegistry

registry = PromptRegistry("./prompts")
prompt = registry.render("name", var=val)
```

## DB

```python
from skillab import init_db, get_session

init_db()
with get_session() as session:
    session.execute(...)
```

## Env

```
ANTHROPIC_API_KEY / OPENAI_API_KEY / GOOGLE_API_KEY
LLM_PROVIDER (optional)
DATABASE_URL
```
