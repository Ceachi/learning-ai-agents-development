"""
Tool implementations — funcțiile efective ale tool-urilor.

Fiecare tool este decorat cu @register_tool și primește un BaseModel ca parametru.
"""
import os
import re
import math
from datetime import datetime
from pathlib import Path

import httpx

from .registry import register_tool
from .params import (
    CalculatorParams,
    DateTimeParams,
    HttpGetParams,
    WeatherParams,
    ReadFileParams,
    ReadCsvParams,
    AggregateCsvParams,
    ListDataFilesParams,
)


@register_tool
def calculator(params: CalculatorParams) -> str:
    """Evaluează o expresie matematică și returnează rezultatul."""
    try:
        cleaned = params.expression.strip()

        # Validare: doar caractere permise
        if not re.match(r'^[\d\s\+\-\*\/\(\)\.\,\%\^a-z]+$', cleaned, re.IGNORECASE):
            return "Eroare: Expresie invalidă"

        # Transformări
        cleaned = cleaned.replace('^', '**')
        cleaned = cleaned.replace(',', '.')

        # Funcții matematice sigure
        safe_dict = {
            'sqrt': math.sqrt,
            'pow': pow,
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'log': math.log,
            'log10': math.log10,
            'abs': abs,
            'round': round,
            'floor': math.floor,
            'ceil': math.ceil,
            'pi': math.pi,
            'e': math.e,
        }

        result = eval(cleaned, {"__builtins__": {}}, safe_dict)

        # Formatare rezultat
        if isinstance(result, float):
            if result == int(result):
                return str(int(result))
            return f"{result:.6f}".rstrip('0').rstrip('.')
        return str(result)
    except Exception as e:
        return f"Eroare la calcul: {str(e)}"


@register_tool
def get_datetime(params: DateTimeParams) -> str:
    """Returnează data și ora curentă în format românesc."""
    now = datetime.now()

    days_ro = ["Luni", "Marți", "Miercuri", "Joi", "Vineri", "Sâmbătă", "Duminică"]
    months_ro = [
        "", "ianuarie", "februarie", "martie", "aprilie", "mai", "iunie",
        "iulie", "august", "septembrie", "octombrie", "noiembrie", "decembrie"
    ]

    day_name = days_ro[now.weekday()]
    month_name = months_ro[now.month]

    if params.format == "date":
        return f"{day_name}, {now.day} {month_name} {now.year}"
    elif params.format == "time":
        return f"{now.hour:02d}:{now.minute:02d}:{now.second:02d}"
    else:  # full
        return f"{day_name}, {now.day} {month_name} {now.year}, ora {now.hour:02d}:{now.minute:02d}"


@register_tool
def http_get(params: HttpGetParams) -> str:
    """Face un GET request la un URL și returnează conținutul."""
    try:
        # Validare URL
        if not params.url.startswith(('http://', 'https://')):
            return "Eroare: URL-ul trebuie să înceapă cu http:// sau https://"

        response = httpx.get(params.url, timeout=params.timeout, follow_redirects=True)

        # Status code
        status = f"Status: {response.status_code}"

        # Content type
        content_type = response.headers.get('content-type', 'unknown')

        # Truncate large responses
        content = response.text
        if len(content) > 2000:
            content = content[:2000] + "\n... (truncat)"

        return f"{status}\nContent-Type: {content_type}\n\n{content}"

    except httpx.TimeoutException:
        return f"Eroare: Timeout după {params.timeout} secunde"
    except httpx.RequestError as e:
        return f"Eroare la request: {str(e)}"
    except Exception as e:
        return f"Eroare: {str(e)}"


@register_tool
def weather(params: WeatherParams) -> str:
    """Returnează vremea curentă pentru un oraș folosind OpenWeatherMap API."""
    api_key = os.getenv("OPENWEATHERMAP_API_KEY")

    if not api_key:
        # Fallback la date simulate dacă nu avem API key
        simulated = {
            "bucurești": {"temp": 22, "desc": "parțial noros", "humidity": 65},
            "bucharest": {"temp": 22, "desc": "parțial noros", "humidity": 65},
            "cluj": {"temp": 18, "desc": "însorit", "humidity": 55},
            "timișoara": {"temp": 20, "desc": "senin", "humidity": 60},
            "iași": {"temp": 19, "desc": "noros", "humidity": 70},
            "london": {"temp": 15, "desc": "ploaie ușoară", "humidity": 80},
            "paris": {"temp": 18, "desc": "însorit", "humidity": 50},
            "new york": {"temp": 25, "desc": "senin", "humidity": 45},
        }

        city_lower = params.city.lower()
        if city_lower in simulated:
            data = simulated[city_lower]
            unit = "°C" if params.units == "metric" else "°F"
            temp = data["temp"] if params.units == "metric" else int(data["temp"] * 9/5 + 32)
            return (
                f"Vremea în {params.city}: {temp}{unit}, {data['desc']}, "
                f"umiditate {data['humidity']}% "
                f"(date simulate - setează OPENWEATHERMAP_API_KEY pentru date reale)"
            )

        return (
            f"Nu am date pentru orașul '{params.city}'. "
            f"Încearcă: București, Cluj, Timișoara, Iași, London, Paris, New York "
            f"(date simulate)"
        )

    # API real OpenWeatherMap
    try:
        url = "https://api.openweathermap.org/data/2.5/weather"
        response = httpx.get(url, params={
            "q": params.city,
            "appid": api_key,
            "units": params.units,
            "lang": "ro"
        }, timeout=10)

        if response.status_code == 404:
            return f"Orașul '{params.city}' nu a fost găsit."

        response.raise_for_status()
        data = response.json()

        temp = round(data["main"]["temp"])
        feels_like = round(data["main"]["feels_like"])
        description = data["weather"][0]["description"]
        humidity = data["main"]["humidity"]
        wind = round(data["wind"]["speed"] * 3.6)  # m/s to km/h

        unit = "°C" if params.units == "metric" else "°F"

        return (
            f"Vremea în {params.city}:\n"
            f"Temperatură: {temp}{unit} (se simte ca {feels_like}{unit})\n"
            f"Condiții: {description}\n"
            f"Umiditate: {humidity}%\n"
            f"Vânt: {wind} km/h"
        )
    except httpx.TimeoutException:
        return "Eroare: Timeout la conectarea cu API-ul meteo."
    except Exception as e:
        return f"Eroare la obținerea vremii: {str(e)}"


@register_tool
def read_file(params: ReadFileParams) -> str:
    """Citește conținutul unui fișier din sandbox."""
    try:
        # Securitate: normalizare cale și verificări
        path = Path(params.path)

        # Nu permitem căi absolute sau path traversal
        if path.is_absolute():
            return "Eroare: Nu sunt permise căi absolute. Folosește căi relative."

        # Verifică path traversal
        try:
            resolved = path.resolve()
            cwd = Path.cwd().resolve()
            if not str(resolved).startswith(str(cwd)):
                return "Eroare: Path traversal detectat. Rămâi în sandbox."
        except Exception:
            return "Eroare: Cale invalidă."

        # Verifică existența
        if not path.exists():
            return f"Eroare: Fișierul '{params.path}' nu există."

        if not path.is_file():
            return f"Eroare: '{params.path}' nu este un fișier."

        # Citește conținutul
        content = path.read_text(encoding='utf-8')

        # Limitează dimensiunea
        if len(content) > 10000:
            content = content[:10000] + "\n... (truncat la 10000 caractere)"

        return content

    except UnicodeDecodeError:
        return f"Eroare: Fișierul '{params.path}' nu poate fi citit ca text (posibil binar)."
    except PermissionError:
        return f"Eroare: Nu am permisiuni să citesc '{params.path}'."
    except Exception as e:
        return f"Eroare la citirea fișierului: {str(e)}"


def _validate_csv_path(path_str: str) -> Path | str:
    """Validează calea CSV și returnează Path sau mesaj de eroare."""
    path = Path(path_str)

    # Nu permitem căi absolute
    if path.is_absolute():
        return "Eroare: Nu sunt permise căi absolute. Folosește căi relative."

    # Verifică path traversal
    try:
        resolved = path.resolve()
        cwd = Path.cwd().resolve()
        if not str(resolved).startswith(str(cwd)):
            return "Eroare: Path traversal detectat. Rămâi în sandbox."
    except Exception:
        return "Eroare: Cale invalidă."

    # Verifică existența
    if not path.exists():
        return f"Eroare: Fișierul '{path_str}' nu există."

    if not path.is_file():
        return f"Eroare: '{path_str}' nu este un fișier."

    if not path_str.lower().endswith('.csv'):
        return f"Eroare: '{path_str}' nu este un fișier CSV."

    return path


@register_tool
def read_csv(params: ReadCsvParams) -> str:
    """Citește un fișier CSV și returnează schema coloanelor plus câteva rânduri exemplu."""
    import json

    try:
        import pandas as pd
    except ImportError:
        return "Eroare: pandas nu este instalat. Rulează: pip install pandas"

    # Validare cale
    result = _validate_csv_path(params.path)
    if isinstance(result, str):
        return result
    path = result

    try:
        df = pd.read_csv(path)

        # Schema coloane cu tipuri
        dtypes = {col: str(dtype) for col, dtype in df.dtypes.items()}

        # Identifică coloane numerice (pentru agregări)
        numeric_cols = df.select_dtypes(include=['int64', 'float64']).columns.tolist()

        # Sample rows
        sample = df.head(params.sample_rows).to_dict(orient='records')

        result = {
            "total_rows": len(df),
            "columns": df.columns.tolist(),
            "dtypes": dtypes,
            "numeric_columns": numeric_cols,
            "sample": sample
        }

        return json.dumps(result, ensure_ascii=False, indent=2, default=str)

    except pd.errors.EmptyDataError:
        return f"Eroare: Fișierul '{params.path}' este gol."
    except pd.errors.ParserError as e:
        return f"Eroare la parsarea CSV: {str(e)}"
    except Exception as e:
        return f"Eroare la citirea CSV: {str(e)}"


@register_tool
def aggregate_csv(params: AggregateCsvParams) -> str:
    """Agregă datele dintr-un CSV: grupează pe coloane și aplică funcții (sum, mean, count, min, max). NU știi ce coloane există în fișier - TREBUIE să folosești read_csv înainte pentru a afla schema exactă."""
    import json

    try:
        import pandas as pd
    except ImportError:
        return "Eroare: pandas nu este instalat. Rulează: pip install pandas"

    # Validare cale
    result = _validate_csv_path(params.path)
    if isinstance(result, str):
        return result
    path = result

    try:
        df = pd.read_csv(path)

        # Validare coloane group_by
        missing_group = [col for col in params.group_by if col not in df.columns]
        if missing_group:
            return f"Eroare: Coloanele pentru grupare nu există: {missing_group}. Coloane disponibile: {df.columns.tolist()}"

        # Validare coloane agregare
        agg_funcs = {'sum', 'mean', 'count', 'min', 'max'}
        for col, func in params.aggregations.items():
            if col not in df.columns:
                return f"Eroare: Coloana '{col}' nu există. Coloane disponibile: {df.columns.tolist()}"
            if func not in agg_funcs:
                return f"Eroare: Funcția '{func}' nu este validă. Folosește: {agg_funcs}"

        # Execută agregarea
        grouped = df.groupby(params.group_by, as_index=False).agg(params.aggregations)

        # Redenumește coloanele pentru claritate (ex: sales -> sales_sum)
        new_columns = {}
        for col, func in params.aggregations.items():
            new_columns[col] = f"{col}_{func}"
        grouped = grouped.rename(columns=new_columns)

        # Convertește la JSON
        result_data = grouped.to_dict(orient='records')

        return json.dumps(result_data, ensure_ascii=False, indent=2, default=str)

    except Exception as e:
        return f"Eroare la agregare: {str(e)}"


@register_tool
def list_data_files(params: ListDataFilesParams) -> str:
    """Listează fișierele CSV disponibile într-un folder pentru analiză."""
    import json

    folder = Path(params.folder)

    # Verifică path traversal
    if folder.is_absolute():
        return "Eroare: Nu sunt permise căi absolute."

    try:
        resolved = folder.resolve()
        cwd = Path.cwd().resolve()
        if not str(resolved).startswith(str(cwd)):
            return "Eroare: Path traversal detectat."
    except Exception:
        return "Eroare: Cale invalidă."

    if not folder.exists():
        return f"Eroare: Folderul '{params.folder}' nu există."

    if not folder.is_dir():
        return f"Eroare: '{params.folder}' nu este un folder."

    # Listează fișierele CSV
    csv_files = list(folder.glob("*.csv"))

    if not csv_files:
        return f"Nu am găsit fișiere CSV în '{params.folder}'."

    files_info = []
    for f in csv_files:
        stat = f.stat()
        files_info.append({
            "name": f.name,
            "path": str(f),
            "size_kb": round(stat.st_size / 1024, 1)
        })

    return json.dumps({
        "folder": params.folder,
        "csv_files": files_info,
        "count": len(files_info)
    }, ensure_ascii=False, indent=2)
