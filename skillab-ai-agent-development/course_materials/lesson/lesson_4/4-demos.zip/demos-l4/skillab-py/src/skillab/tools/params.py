"""
Pydantic models pentru parametrii tool-urilor.

Pattern din slide-ul 56: BaseModel cu Field descriptions pentru LLM.
"""
from pydantic import BaseModel, Field


class CalculatorParams(BaseModel):
    """Parametri pentru tool-ul calculator."""
    expression: str = Field(
        description="Expresia matematică de evaluat (ex: '2 + 3 * 4', 'sqrt(16)')",
        min_length=1
    )


class DateTimeParams(BaseModel):
    """Parametri pentru tool-ul get_datetime."""
    format: str = Field(
        default="full",
        description="Format: 'full' (complet), 'date' (doar data), 'time' (doar ora)"
    )


class HttpGetParams(BaseModel):
    """Parametri pentru tool-ul http_get."""
    url: str = Field(
        description="URL-ul către care se face request-ul GET",
        min_length=1
    )
    timeout: int = Field(
        default=10,
        description="Timeout în secunde pentru request",
        ge=1,
        le=60
    )


class WeatherParams(BaseModel):
    """Parametri pentru tool-ul weather."""
    city: str = Field(
        description="Numele orașului (ex: 'București', 'London')",
        min_length=2
    )
    units: str = Field(
        default="metric",
        description="Unități: 'metric' (Celsius), 'imperial' (Fahrenheit)"
    )


class ReadFileParams(BaseModel):
    """Parametri pentru tool-ul read_file."""
    path: str = Field(
        description="Calea către fișierul de citit (relativă la sandbox)",
        min_length=1
    )


class ReadCsvParams(BaseModel):
    """Parametri pentru tool-ul read_csv."""
    path: str = Field(
        description="Calea către fișierul CSV (relativă la sandbox)",
        min_length=1
    )
    sample_rows: int = Field(
        default=5,
        description="Numărul de rânduri exemplu de returnat",
        ge=1,
        le=20
    )


class AggregateCsvParams(BaseModel):
    """Parametri pentru tool-ul aggregate_csv."""
    path: str = Field(
        description="Calea către fișierul CSV (relativă la sandbox)",
        min_length=1
    )
    group_by: list[str] = Field(
        description="Lista de coloane pe care se face gruparea (ex: ['region', 'product'])"
    )
    aggregations: dict[str, str] = Field(
        description="Agregări de aplicat: {'coloana': 'sum|mean|count|min|max'} (ex: {'sales': 'sum', 'quantity': 'mean'})"
    )


class ListDataFilesParams(BaseModel):
    """Parametri pentru tool-ul list_data_files."""
    folder: str = Field(
        default="backend/data",
        description="Folderul în care să caut fișiere (default: backend/data)"
    )
