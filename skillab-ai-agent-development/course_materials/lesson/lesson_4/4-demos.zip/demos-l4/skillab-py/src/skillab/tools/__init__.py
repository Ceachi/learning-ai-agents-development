"""
Tools package — reusable tool implementations for LangChain agents.

Usage:
    from skillab.tools import ToolWrapper

    # Get LangChain tools for bind_tools()
    tools = ToolWrapper.to_langchain_tools()

    # Get tool catalog
    catalog = ToolWrapper.catalog()

    # Enable/disable tools
    ToolWrapper.set_enabled("calculator", False)

    # Execute a tool directly
    result = ToolWrapper.call("calculator", {"expression": "2 + 2"})
"""
from .registry import register_tool, TOOL_REGISTRY
from .wrapper import ToolWrapper
from .schemas import ToolInfo, ToolParameter, ToolWithStatus
from .params import (
    CalculatorParams,
    DateTimeParams,
    HttpGetParams,
    WeatherParams,
    ReadFileParams,
    ReadCsvParams,
    AggregateCsvParams,
    ListDataFilesParams,
)

# Import implementations to auto-register tools
from . import implementations  # noqa: F401

__all__ = [
    # Core
    "register_tool",
    "TOOL_REGISTRY",
    "ToolWrapper",
    # Schemas
    "ToolInfo",
    "ToolParameter",
    "ToolWithStatus",
    # Params
    "CalculatorParams",
    "DateTimeParams",
    "HttpGetParams",
    "WeatherParams",
    "ReadFileParams",
    "ReadCsvParams",
    "AggregateCsvParams",
    "ListDataFilesParams",
]
