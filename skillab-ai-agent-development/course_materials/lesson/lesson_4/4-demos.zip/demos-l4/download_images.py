"""
Script pentru descărcare imagini locale.
Rulează o singură dată: python download_images.py
"""

import requests
from pathlib import Path

IMAGES_DIR = Path(__file__).parent / "images"
IMAGES_DIR.mkdir(exist_ok=True)

IMAGES = {
    "P001_rochie_rosie.jpg": "https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400",
    "P002_rochie_albastra.jpg": "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=400",
    "P003_geaca_piele.jpg": "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400",
    "P004_blugi.jpg": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
    "P005_sneakers.jpg": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400",
    "P006_rochie_neagra.jpg": "https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=400",
    "P007_palton.jpg": "https://images.unsplash.com/photo-1539533018447-63fcce2678e3?w=400",
    "P008_tricou.jpg": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
    "query_rochie.jpg": "https://images.unsplash.com/photo-1612336307429-8a898d10e223?w=400",
}


def download_all():
    print(f"Descărcare imagini în {IMAGES_DIR}/\n")

    for filename, url in IMAGES.items():
        filepath = IMAGES_DIR / filename
        if filepath.exists():
            print(f"  ✓ {filename} (există deja)")
            continue

        print(f"  ↓ {filename}...", end=" ")
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()
            filepath.write_bytes(response.content)
            print(f"OK ({len(response.content) // 1024} KB)")
        except Exception as e:
            print(f"EROARE: {e}")

    print(f"\n✓ Done! Imaginile sunt în: {IMAGES_DIR}")


if __name__ == "__main__":
    download_all()
