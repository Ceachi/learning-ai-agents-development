from google import genai

client = genai.Client()

response = client.models.generate_content(
    model="gemini-2.0-flash",
    contents="Ce spune contractul despre reziliere?",
)

# ❌ LLM nu are contractul în context!
# → Hallucinates sau răspunde „nu știu”
print(response.text)
