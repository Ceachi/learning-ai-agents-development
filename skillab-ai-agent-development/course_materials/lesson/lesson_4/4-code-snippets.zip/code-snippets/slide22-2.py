from sqlalchemy.orm import Session
from sqlalchemy import func

from models import Document


class DocumentRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def filter_by_metadata(self, key: str, value: str) -> list[Document]:
        # operatorul ->> din PostgreSQL: extrage field din JSONB ca text
        return (
            self.db.query(Document)
            .filter(Document.doc_metadata[key].astext == value)
            .all()
        )

    def search(self, query: str, limit: int = 20) -> list[Document]:
        # tsquery construit cu același dicționar ca search_vector → stemming consistent
        ts_query = func.plainto_tsquery("romanian", query)
        return (
            self.db.query(Document)
            .filter(Document.search_vector.op("@@")(ts_query))
            .order_by(func.ts_rank(Document.search_vector, ts_query).desc())
            .limit(limit)
            .all()
        )
