from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")

clauses = [
    "Clauza 5.3: Rezilierea contractului se face cu preaviz de 30 de zile.",
    "Clauza 9.2: Litigiile se soluționează la instanțele din București.",
    "Clauza 7.1: Penalitățile pentru întârziere sunt de 0.1% pe zi.",
]

query = "Cum funcționează rezilierea?"
THRESHOLD = 0.4  # sub acest scor → considerăm irelevant pentru RAG

query_emb = model.encode(query, convert_to_tensor=True)
clause_embs = model.encode(clauses, convert_to_tensor=True)

scores = util.cos_sim(query_emb, clause_embs)[0]
ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)

print(f"Query: '{query}'")
for idx, score in ranked:
    flag = "✅" if score >= THRESHOLD else "  "
    print(f"Score: {score:.3f} {flag}  {clauses[idx]}")
