# ❌ Fără RAG — hallucination sau răspuns generic

question = "Ce spune contractul despre reziliere?"
response = client.models.generate_content(
    model="gemini-2.0-flash",
    contents=question,
)
# LLM nu are contractul → inventează sau zice „nu știu"


# ✅ Cu RAG — bazat pe documente reale

question = "Ce spune contractul despre reziliere?"

# 1. Caută chunks relevante în pgvector
results = rag.search(question, top_k=3)

# 2. Construiește contextul citabil
context = "\n\n".join(
    f"[{chunk.document.filename}] {chunk.content}"
    for chunk, _ in results
)

# 3. Prompt cu context + întrebare
prompt = f"""Context:
{context}

Întrebare: {question}
"""

response = client.models.generate_content(
    model="gemini-2.0-flash",
    contents=prompt,
)
# Răspuns bazat pe documente reale, cu citarea sursei
