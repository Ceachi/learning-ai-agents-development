import logging
from pathlib import Path

from langchain_community.document_loaders import (
    PyPDFLoader,
    Docx2txtLoader,
    TextLoader,
)

logger = logging.getLogger(__name__)


class ExtractorAgentV2:
    # ... __init__ și client (vezi slide 32)

    def load_document(self, path: str | Path) -> str | None:
        path = Path(path)
        try:
            match path.suffix.lower():
                case ".pdf":
                    loader = PyPDFLoader(str(path))
                case ".docx":
                    loader = Docx2txtLoader(str(path))
                case ".txt":
                    loader = TextLoader(str(path), autodetect_encoding=True)
                case _:
                    logger.warning("Unsupported format: %s", path.suffix)
                    return None

            docs = loader.load()
            return "\n\n".join(d.page_content for d in docs)  # combine pagini
        except Exception as e:
            logger.error("Failed to load %s: %s", path, e)
            return None
