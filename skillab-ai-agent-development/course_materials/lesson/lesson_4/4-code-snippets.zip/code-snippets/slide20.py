from typing import Any
from sqlalchemy.orm import Session

from models import Document


class DocumentRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def create(self, filename: str, content: str, metadata: dict[str, Any]) -> Document:
        doc = Document(filename=filename, content=content, doc_metadata=metadata)  # 1. creează obiect
        self.db.add(doc)        # 2. adaugă în session (nu în DB încă)
        self.db.commit()        # 3. scrie în DB
        self.db.refresh(doc)    # 4. citește ID-ul generat înapoi
        return doc

    def create_batch(self, documents: list[dict[str, Any]]) -> list[Document]:
        docs = [Document(**d) for d in documents]
        self.db.add_all(docs)   # un singur INSERT batch, mult mai rapid decât N add()
        self.db.commit()
        for doc in docs:
            self.db.refresh(doc)
        return docs
