import logging
from schemas import DocumentExtraction

logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """Extract structured metadata from the document below.

Filename: {filename}

Content:
{content}
"""


class ExtractorAgentV2:
    # ... __init__, client, load_document (vezi slide 32, 33)

    def extract_metadata(self, content: str, filename: str) -> DocumentExtraction | None:
        prompt = EXTRACTION_PROMPT.format(filename=filename, content=content[:4000])
        try:
            response = self.client.models.generate_content(
                model=self.model,
                contents=prompt,
                config={
                    "response_mime_type": "application/json",
                    "response_schema": DocumentExtraction,  # Gemini → Pydantic direct
                },
            )
            # SDK validează deja schema; .parsed returnează instanța Pydantic
            extraction: DocumentExtraction = response.parsed
            extraction.filename = filename       # asigurăm filename-ul real
            extraction.content = content         # full content, nu trunchierea
            return extraction
        except Exception as e:
            logger.error("LLM extraction failed for %s: %s", filename, e)
            return None
