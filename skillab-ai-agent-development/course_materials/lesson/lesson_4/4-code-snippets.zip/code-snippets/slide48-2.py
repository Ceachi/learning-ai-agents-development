import torch
from sentence_transformers import SentenceTransformer, util
from google import genai

model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")
client = genai.Client()


def rag_query(question: str, documents: list[str], top_k: int = 3) -> str:
    # 1. Question → vector
    q_emb = model.encode(question, convert_to_tensor=True)

    # 2. Similarity cu toate doc-urile (în prod: embeddings pre-calculate în pgvector)
    doc_embs = model.encode(documents, convert_to_tensor=True)
    scores = util.cos_sim(q_emb, doc_embs)[0]

    # 3. Top-K indecși, sortați descrescător
    top_idx = torch.argsort(scores, descending=True)[:top_k].tolist()

    # 4. Construiește contextul
    context = "\n\n".join(documents[i] for i in top_idx)

    # 5. Generează răspunsul cu context
    prompt = f"""Răspunde pe baza contextului. Dacă răspunsul nu e în context, spune-o explicit.

Context:
{context}

Întrebare: {question}
"""
    response = client.models.generate_content(model="gemini-2.0-flash", contents=prompt)
    return response.text
