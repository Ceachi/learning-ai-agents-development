# =============================================================
# 1. Folosește mereu Repository Pattern
# =============================================================

# ✅
with transaction() as db:
    repo = DocumentRepository(db)
    doc = repo.get_by_filename("a.pdf")

# ❌
db = SessionLocal()
doc = db.query(Document).filter(Document.filename == "a.pdf").first()


# =============================================================
# 2. Session Management — context manager
# =============================================================

# ✅
with transaction() as db:
    repo = DocumentRepository(db)
    # commit / rollback / close → automate

# ❌
db = SessionLocal()
# uiți db.close() → connection leak


# =============================================================
# 3. Pagination mereu cu total count
# =============================================================

# ✅
results, total = repo.get_all(skip=0, limit=20)
# returnezi (results, total) → UI știe câte pagini sunt

# ❌
docs = repo.get_all()
# fără total → UI nu poate calcula numărul de pagini
