-- =============================================================
-- 1. Verifică dacă query-ul folosește indexul
-- =============================================================

EXPLAIN ANALYZE
SELECT *
FROM document_chunks
ORDER BY embedding <=> '[0.12, 0.45, ...]'::vector
LIMIT 5;

-- Cu index:    Index Scan using ix_chunks_embedding_hnsw   →  ~2 ms
-- Fără index:  Seq Scan on document_chunks                 →  ~450 ms


-- =============================================================
-- 2. Dimensiunea indexului (planificare RAM)
-- =============================================================

SELECT
    indexrelname AS index_name,
    pg_size_pretty(pg_relation_size(indexrelid)) AS size
FROM pg_stat_user_indexes
WHERE relname = 'document_chunks';


-- =============================================================
-- 3. Timing manual în psql
-- =============================================================
-- \timing on
