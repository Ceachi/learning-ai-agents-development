from sentence_transformers import SentenceTransformer

# modelul recomandat pentru română (multilingual)
model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")

sentences = [
    "Contractul prevede o perioadă de reziliere de 30 de zile.",
    "Cum pot anula contractul?",
    "Câinele meu mănâncă pizza.",
]

embeddings = model.encode(sentences, convert_to_numpy=True)

print(embeddings.shape)  # (3, 384) — 3 propoziții, 384 dimensiuni
