# =============================================================
# Comenzi Alembic (shell)
# =============================================================
# alembic revision --autogenerate -m "add document_chunks table"
# alembic upgrade head
# psql ... -c "\d document_chunks"


# =============================================================
# alembic/versions/xxxx_add_document_chunks_table.py
# (după edit manual — vezi notele)
# =============================================================

from alembic import op
import sqlalchemy as sa
from pgvector.sqlalchemy import Vector


revision = "xxxx_add_document_chunks"
down_revision = "previous_revision_id"


def upgrade() -> None:
    # ⚠️ Adăugat MANUAL — autogenerate nu detectează CREATE EXTENSION
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    op.create_table(
        "document_chunks",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("document_id", sa.Integer, nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("chunk_index", sa.Integer, nullable=False),
        sa.Column("embedding", Vector(384), nullable=False),
        sa.ForeignKeyConstraint(
            ["document_id"], ["documents.id"], ondelete="CASCADE"
        ),
        sa.UniqueConstraint("document_id", "chunk_index", name="uq_doc_chunk_idx"),
    )
    op.create_index("ix_chunks_document_id", "document_chunks", ["document_id"])


def downgrade() -> None:
    op.drop_index("ix_chunks_document_id", table_name="document_chunks")
    op.drop_table("document_chunks")
    # extensia NU se șterge — poate fi folosită de alte tabele
