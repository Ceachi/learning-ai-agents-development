import logging
from pathlib import Path

from schemas import ExtractionResult

logger = logging.getLogger(__name__)


# =============================================================
# process_batch — continue-on-error
# =============================================================

class ExtractorAgentV2:
    # ... __init__, client, load_document, extract_metadata, process_document

    def process_batch(self, paths: list[str | Path]) -> list[ExtractionResult]:
        results: list[ExtractionResult] = []
        for path in paths:
            try:
                results.append(self.process_document(path))
            except Exception as e:
                # safety net — eroare neașteptată nu oprește batch-ul
                logger.exception("Unexpected error on %s", path)
                results.append(ExtractionResult(success=False, error=str(e)))
        return results


# =============================================================
# usage — separare succese / eșecuri, retry
# =============================================================

agent = ExtractorAgentV2()
results = agent.process_batch(["a.pdf", "b.docx", "c.txt"])

successful = [r for r in results if r.success]
failed = [r for r in results if not r.success]

logger.info("Batch done: %d ok, %d failed", len(successful), len(failed))
for r in failed:
    logger.error("Failed: %s", r.error)

# retry doar pe eșuate (necesită stocarea path-ului în ExtractionResult sau zip cu paths)
