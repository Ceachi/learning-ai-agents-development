from sentence_transformers import SentenceTransformer, util

model = SentenceTransformer("paraphrase-multilingual-MiniLM-L12-v2")

query = "pisica"
candidates = ["persian", "animal", "masina"]

# 1. Embedding-uri (un singur call, batch)
query_emb = model.encode(query, convert_to_tensor=True)
candidate_embs = model.encode(candidates, convert_to_tensor=True)

# 2. Cosine similarity: tensor de shape (1, len(candidates))
scores = util.cos_sim(query_emb, candidate_embs)[0]

# 3. Sortare descrescătoare după score, păstrăm indexul
ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)

# 4. Top-K
top_k = 3
for idx, score in ranked[:top_k]:
    print(f"[0] {query} → vs {candidates[idx]}: {score:.3f}")
