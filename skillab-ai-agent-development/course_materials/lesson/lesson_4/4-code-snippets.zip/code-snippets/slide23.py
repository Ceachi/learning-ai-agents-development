from typing import Any
from sqlalchemy.orm import Session
from sqlalchemy import update as sql_update, delete as sql_delete

from models import Document


class DocumentRepository:
    # câmpuri permise la update — protecție împotriva mass assignment
    _UPDATABLE = {"filename", "content", "doc_metadata"}

    def __init__(self, db: Session) -> None:
        self.db = db

    # UPDATE
    def update(self, doc_id: int, **fields: Any) -> Document | None:
        clean = {k: v for k, v in fields.items() if k in self._UPDATABLE}
        if not clean:
            return self.db.get(Document, doc_id)
        self.db.execute(sql_update(Document).where(Document.id == doc_id).values(**clean))
        self.db.commit()
        return self.db.get(Document, doc_id)

    def update_metadata(self, doc_id: int, metadata: dict[str, Any]) -> Document | None:
        # JSONB merge la nivel de DB (atomic) — operatorul || din PostgreSQL
        self.db.execute(
            sql_update(Document)
            .where(Document.id == doc_id)
            .values(doc_metadata=Document.doc_metadata.op("||")(metadata))
        )
        self.db.commit()
        return self.db.get(Document, doc_id)

    # DELETE
    def delete(self, doc_id: int) -> bool:
        result = self.db.execute(sql_delete(Document).where(Document.id == doc_id))
        self.db.commit()
        return result.rowcount > 0

    def delete_batch(self, doc_ids: list[int]) -> int:
        if not doc_ids:
            return 0
        result = self.db.execute(sql_delete(Document).where(Document.id.in_(doc_ids)))
        self.db.commit()
        return result.rowcount
