# ❌ Fără Repository — DB logic împrăștiat, duplicat

# agent.py
db = SessionLocal()
doc = db.query(Document).filter(Document.filename == "a.pdf").first()
db.close()

# search.py
db = SessionLocal()
docs = db.query(Document).all()
db.close()


# ✅ Cu Repository — un singur API, consistent

# agent.py
with transaction() as db:
    repo = DocumentRepository(db)
    doc = repo.get_by_filename("a.pdf")

# search.py
with transaction() as db:
    repo = DocumentRepository(db)
    docs = repo.get_all()
