from google import genai

from database import transaction
from rag_service import RAGService

client = genai.Client()


PROMPT_TEMPLATE = """Răspunde scurt, pe baza contextului. Citează sursa în paranteză.
Dacă răspunsul nu e în context, spune-o explicit.

Context:
{context}

Întrebare: {question}
"""


def ask(rag: RAGService, question: str) -> str:
    context = rag.get_context(question)
    if not context:
        return "Nu am găsit informații relevante în documente."

    prompt = PROMPT_TEMPLATE.format(context=context, question=question)
    response = client.models.generate_content(model="gemini-2.0-flash", contents=prompt)
    return response.text


# Usage
with transaction() as db:
    rag = RAGService(db)

    for q in [
        "Cum pot rezilia?",
        "Care sunt penalitățile?",
        "Cât costă?",
    ]:
        print(f"Q: {q}")
        print(f"A: {ask(rag, q)}\n")
