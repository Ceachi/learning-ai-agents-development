from sqlalchemy.orm import Session

from models import DocumentChunk   # vezi slide 53


class ChunkRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    # WRITE
    def create_chunk(
        self,
        document_id: int,
        content: str,
        chunk_index: int,
        embedding: list[float],
    ) -> DocumentChunk: ...

    def create_chunks_batch(self, chunks: list[dict]) -> list[DocumentChunk]: ...

    # READ
    def get_document_chunks(self, document_id: int) -> list[DocumentChunk]: ...
    def get_chunk_by_id(self, chunk_id: int) -> DocumentChunk | None: ...

    # SEARCH
    def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 5,
    ) -> list[tuple[DocumentChunk, float]]: ...

    def search_with_threshold(
        self,
        query_embedding: list[float],
        min_score: float = 0.4,
        top_k: int = 5,
    ) -> list[tuple[DocumentChunk, float]]: ...
