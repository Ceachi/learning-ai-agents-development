from pathlib import Path
from google import genai

from schemas import DocumentExtraction, ExtractionResult


class ExtractorAgentV2:
    def __init__(self, model: str = "gemini-2.0-flash") -> None:
        self.model = model
        self._client: genai.Client | None = None  # lazy

    @property
    def client(self) -> genai.Client:
        # init per proces — clientul nu e pickle-able
        if self._client is None:
            self._client = genai.Client()
        return self._client

    def load_document(self, path: str | Path) -> str | None:
        # existing din Lecția 3, recap pe slide 33 (cu error handling adăugat)
        ...

    def extract_metadata(self, content: str, filename: str) -> DocumentExtraction | None:
        # LLM call cu response_schema → Pydantic direct, fără parser intermediar
        ...

    def process_document(self, path: str | Path) -> ExtractionResult:
        # Load → Extract → Validate → Save (atomic, idempotent pe filename)
        ...

    def process_batch(self, paths: list[str | Path]) -> list[ExtractionResult]:
        # continue-on-error: o eroare pe un doc nu oprește batch-ul
        ...
