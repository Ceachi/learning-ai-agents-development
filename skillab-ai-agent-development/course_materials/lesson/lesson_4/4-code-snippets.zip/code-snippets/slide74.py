from pydantic import BaseModel
from google import genai

from rag_service import RAGService
from models import DocumentChunk


class AnswerResult(BaseModel):
    answer: str
    sources: list[dict]      # [{filename, chunk_index, score}, ...]
    confidence: float        # 0.0 - 1.0


class AnalystAgent:
    def __init__(self, rag: RAGService, model: str = "gemini-2.0-flash") -> None:
        self.rag = rag
        self.model = model
        self._client: genai.Client | None = None

    @property
    def client(self) -> genai.Client:
        if self._client is None:
            self._client = genai.Client()
        return self._client

    def answer_question(self, question: str, top_k: int = 5) -> AnswerResult:
        # Entry point principal: orchestrează toate etapele
        ...

    def _build_context(self, results: list[tuple[DocumentChunk, float]]) -> str:
        # chunks → context string cu relevance scores
        ...

    def _build_prompt(self, question: str, context: str) -> str:
        # prompt cu instrucțiuni: citează / „nu știu" / concis
        ...

    def _extract_sources(self, results: list[tuple[DocumentChunk, float]]) -> list[dict]:
        # chunks → metadata pentru citare
        ...

    def _calculate_confidence(self, results: list[tuple[DocumentChunk, float]]) -> float:
        # avg similarity score → 0.0 - 1.0
        ...
