from sqlalchemy import select
from sqlalchemy.orm import joinedload, Session

from models import DocumentChunk, Document


class ChunkRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def similarity_search(
        self,
        query_embedding: list[float],
        top_k: int = 5,
    ) -> list[tuple[DocumentChunk, float]]:
        # 1 - (emb <=> q)  →  cosine distance convertit în similaritate [0, 1]
        similarity = (1 - DocumentChunk.embedding.cosine_distance(query_embedding)).label("score")

        stmt = (
            select(DocumentChunk, similarity)
            .options(joinedload(DocumentChunk.document))   # eager load — evită N+1
            .order_by(DocumentChunk.embedding.cosine_distance(query_embedding))
            .limit(top_k)
        )

        rows = self.db.execute(stmt).all()
        return [(chunk, float(score)) for chunk, score in rows]
