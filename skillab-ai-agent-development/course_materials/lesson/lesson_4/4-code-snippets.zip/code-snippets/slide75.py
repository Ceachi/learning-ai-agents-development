from models import DocumentChunk


PROMPT_TEMPLATE = """Răspunde la întrebare BAZAT EXCLUSIV pe contextul de mai jos.

Reguli:
- Citează clauza/documentul folosit (ex: „conform contract.pdf, Clauza 5.3")
- Dacă răspunsul nu e în context, spune explicit: „Nu am informații despre asta în documente"
- Răspuns concis, fără padding

Context:
{context}

Întrebare: {question}
"""


class AnalystAgent:
    # ... __init__, client, answer_question (vezi slide 74)

    def _build_context(
        self,
        results: list[tuple[DocumentChunk, float]],
    ) -> str:
        # chunks → context string, cu score-uri inline pentru transparență
        parts = []
        for chunk, score in results:
            parts.append(
                f"[{chunk.document.filename} | chunk {chunk.chunk_index} | score {score:.2f}]\n"
                f"{chunk.content}"
            )
        return "\n\n".join(parts)

    def _build_prompt(self, question: str, context: str) -> str:
        return PROMPT_TEMPLATE.format(context=context, question=question)
