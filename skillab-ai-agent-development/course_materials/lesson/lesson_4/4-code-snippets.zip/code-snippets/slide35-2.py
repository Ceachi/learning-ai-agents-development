import logging
from pathlib import Path

from database import transaction
from repositories import DocumentRepository
from schemas import ExtractionResult

logger = logging.getLogger(__name__)


class ExtractorAgentV2:
    # ... __init__, client, load_document, extract_metadata (vezi slide 32, 33, 34)

    def process_document(self, path: str | Path) -> ExtractionResult:
        path = Path(path)

        # 1. Load
        content = self.load_document(path)
        if content is None:
            return ExtractionResult(success=False, error=f"load failed: {path.name}")

        # 2. Extract + Validate (Pydantic via response_schema)
        extraction = self.extract_metadata(content, filename=path.name)
        if extraction is None:
            return ExtractionResult(success=False, error=f"extract failed: {path.name}")

        # 3. Save — idempotent: dacă filename există deja, skip
        with transaction() as db:
            repo = DocumentRepository(db)
            existing = repo.get_by_filename(path.name)
            if existing is not None:
                logger.info("Skip duplicate: %s (id=%d)", path.name, existing.id)
                return ExtractionResult(success=True, document=extraction)

            doc = repo.create(**extraction.to_db_format())
            logger.info("Saved %s (id=%d)", path.name, doc.id)
            return ExtractionResult(success=True, document=extraction)
