from google import genai

client = genai.Client()


def rag_solution(question: str) -> str:
    # 1. Retrieve — caută documentele relevante (vector search, vezi slide-urile următoare)
    docs = retrieve_relevant_docs(question, top_k=3)

    # 2. Augment — adaugă contextul în prompt
    context = "\n\n".join(d.content for d in docs)
    prompt = f"""Răspunde pe baza contextului de mai jos. Dacă răspunsul nu e în context, spune-o explicit.

Context:
{context}

Întrebare: {question}
"""

    # 3. Generate — LLM-ul răspunde cu context
    response = client.models.generate_content(model="gemini-2.0-flash", contents=prompt)
    return response.text
