# ❌ Manual — error-prone

db = SessionLocal()
try:
    doc1 = repo.create(...)
    doc2 = repo.create(...)
    db.commit()
except Exception:
    db.rollback()    # ușor de uitat
    raise
finally:
    db.close()       # ușor de uitat


# ✅ Context Manager — commit / rollback / close automate

with transaction() as db:
    repo = DocumentRepository(db)
    doc1 = repo.create(...)
    doc2 = repo.create(...)
    # commit  → automat la ieșire fără excepție
    # rollback → automat dacă urcă o excepție
    # close   → garantat, întotdeauna
