# =============================================================
# exceptions.py — Custom Exceptions
# =============================================================

class DocumentError(Exception):
    """Bază pentru toate erorile din domeniul Document."""


class DocumentNotFoundError(DocumentError):
    def __init__(self, doc_id: int) -> None:
        super().__init__(f"Document with id={doc_id} not found")
        self.doc_id = doc_id


class DuplicateDocumentError(DocumentError):
    def __init__(self, filename: str) -> None:
        super().__init__(f"Document with filename='{filename}' already exists")
        self.filename = filename


class InvalidMetadataError(DocumentError):
    def __init__(self, reason: str) -> None:
        super().__init__(f"Invalid metadata: {reason}")
        self.reason = reason


# =============================================================
# usage — repository methods care ridică excepțiile
# =============================================================

class DocumentRepository:
    # ... __init__ și restul metodelor

    def get_by_id_safe(self, doc_id: int) -> Document:
        doc = self.db.get(Document, doc_id)
        if doc is None:
            raise DocumentNotFoundError(doc_id)
        return doc

    def create_safe(self, filename: str, content: str, metadata: dict) -> Document:
        if self.get_by_filename(filename) is not None:
            raise DuplicateDocumentError(filename)
        if not isinstance(metadata, dict):
            raise InvalidMetadataError("metadata must be a dict")
        return self.create(filename=filename, content=content, metadata=metadata)
