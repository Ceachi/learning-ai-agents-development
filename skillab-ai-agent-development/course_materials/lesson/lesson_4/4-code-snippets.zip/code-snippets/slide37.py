import os
from types import SimpleNamespace

import pytest

from extractor_agent_v2 import ExtractorAgentV2
from schemas import DocumentExtraction


# =============================================================
# Unit — test_extract_metadata (mock LLM)
# =============================================================

def test_extract_metadata(monkeypatch: pytest.MonkeyPatch) -> None:
    agent = ExtractorAgentV2()

    fake = DocumentExtraction(
        filename="x", content="x", doc_type="invoice", extra_metadata={"total": 100}
    )
    # mockuim doar API call-ul; restul logicii rulează real
    monkeypatch.setattr(
        agent.client.models, "generate_content",
        lambda **kw: SimpleNamespace(parsed=fake),
    )

    result = agent.extract_metadata(content="some invoice text", filename="invoice.pdf")

    assert result is not None
    assert result.filename == "invoice.pdf"          # suprascris din arg
    assert result.content == "some invoice text"     # full content, nu cel din mock
    assert result.doc_type == "invoice"


# =============================================================
# Unit — test_load_document (tmp_path + mock loader)
# =============================================================

def test_load_document(tmp_path, monkeypatch: pytest.MonkeyPatch) -> None:
    pdf_path = tmp_path / "doc.pdf"
    pdf_path.write_bytes(b"%PDF-fake")

    fake_pages = [SimpleNamespace(page_content="page 1"), SimpleNamespace(page_content="page 2")]
    monkeypatch.setattr(
        "extractor_agent_v2.PyPDFLoader",
        lambda path: SimpleNamespace(load=lambda: fake_pages),
    )

    result = ExtractorAgentV2().load_document(pdf_path)

    assert result == "page 1\n\npage 2"


# =============================================================
# Integration — test_process_document (necesită PostgreSQL real)
# =============================================================

@pytest.fixture
def db_available() -> None:
    if not os.getenv("DATABASE_URL"):
        pytest.skip("DATABASE_URL not set — integration test skipped")


def test_process_document(db_available, tmp_path) -> None:
    txt = tmp_path / "note.txt"
    txt.write_text("Hello world", encoding="utf-8")

    result = ExtractorAgentV2().process_document(txt)

    assert result.success
    assert result.document is not None
