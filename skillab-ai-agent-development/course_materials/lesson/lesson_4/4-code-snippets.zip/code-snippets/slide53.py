from sqlalchemy import Column, Integer, Text, ForeignKey, UniqueConstraint, Index
from sqlalchemy.orm import relationship
from pgvector.sqlalchemy import Vector

from database import Base
from models import Document   # vezi slide 13


class DocumentChunk(Base):
    __tablename__ = "document_chunks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    document_id = Column(
        Integer,
        ForeignKey("documents.id", ondelete="CASCADE"),
        nullable=False,
    )
    content = Column(Text, nullable=False)              # 500-1000 caractere
    chunk_index = Column(Integer, nullable=False)       # poziția în document: 0, 1, 2, ...
    embedding = Column(Vector(384), nullable=False)     # pgvector, 384 dim

    document = relationship("Document", back_populates="chunks")

    __table_args__ = (
        UniqueConstraint("document_id", "chunk_index", name="uq_doc_chunk_idx"),
        Index("ix_chunks_document_id", "document_id"),
    )


# Adăugare în models.py — slide 13:
# Document.chunks = relationship(
#     "DocumentChunk",
#     back_populates="document",
#     cascade="all, delete-orphan",
# )
